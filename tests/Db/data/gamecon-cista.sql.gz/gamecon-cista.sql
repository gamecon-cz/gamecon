-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Počítač: sql.gamecon:3306
-- Vytvořeno: Ned 30. čec 2023, 16:18
-- Verze serveru: 10.3.27-MariaDB-1:10.3.27+maria~focal
-- Verze PHP: 8.0.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Databáze: `gamecon`
--

-- --------------------------------------------------------

--
-- Struktura tabulky `akce_import`
--

CREATE TABLE `akce_import` (
  `id_akce_import` bigint(20) UNSIGNED NOT NULL,
  `id_uzivatele` int(11) NOT NULL,
  `google_sheet_id` varchar(128) COLLATE utf8_czech_ci NOT NULL,
  `cas` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `akce_instance`
--

CREATE TABLE `akce_instance` (
  `id_instance` int(11) NOT NULL,
  `id_hlavni_akce` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `akce_lokace`
--

CREATE TABLE `akce_lokace` (
  `id_lokace` int(11) NOT NULL,
  `nazev` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `dvere` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `poznamka` text COLLATE utf8_czech_ci NOT NULL,
  `poradi` int(11) NOT NULL,
  `rok` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `akce_lokace`
--

INSERT INTO `akce_lokace` (`id_lokace`, `nazev`, `dvere`, `poznamka`, `poradi`, `rok`) VALUES
(1, 'RPG 1 – bunkr', 'Budova C, suterén, bunkr C', 'Bunkr, dveře vzadu vpravo, repráky', 1, 0),
(2, 'RPG 2 - repráky', 'Budova C, dveře č. 1', 'Pokoj 3L, repráky', 2, 0),
(3, 'RPG 3 - repráky', 'Budova C, dveře č. 38', 'Pokoj 3L, repráky', 3, 0),
(4, 'RPG 4 – 2L pokoj', 'Budova C, dveře č. 2', 'Pokoj 2L', 4, 0),
(5, 'RPG 5 ', 'Budova C, dveře č. 37', 'Pokoj 3L', 5, 0),
(6, 'RPG 6', 'Budova C, dveře č. 36', 'Pokoj 3L', 6, 0),
(7, 'RPG 7', 'Budova C, dveře č. 35', 'Pokoj 3L', 7, 0),
(8, 'RPG 8', 'Budova C, dveře č. 34', 'Pokoj 3L', 8, 0),
(9, 'RPG 9', 'Budova C, dveře č. 33', 'Pokoj 3L', 9, 0),
(10, 'RPG 10', 'Budova C, dveře č. 32', 'Pokoj 3L', 10, 0),
(11, 'RPG 11', 'Budova C, dveře č. 22', 'Pokoj 3L', 11, 0),
(12, 'RPG 12', 'Budova C, dveře č. 21', 'Pokoj 3L', 12, 0),
(13, 'RPG 13', 'Budova C, dveře č. 20 ', 'Pokoj 3L', 13, 0),
(14, 'RPG 14', 'Budova C, dveře č. 19', 'Pokoj 3L', 14, 0),
(15, 'RPG 15', 'Budova C, dveře č. 18', 'Pokoj 3L', 15, 0),
(16, 'RPG 16', 'Budova C, dveře č. 17', 'Pokoj 3L', 16, 0),
(17, 'LKD 1 ', 'Budova C, dveře č. 100', 'Pokoj 3L', 19, 0),
(18, 'LKD 2', 'Budova C, dveře č. 135', 'Pokoj 3L', 20, 0),
(19, 'LKD 5', 'Budova C, dveře č. 133', 'Pokoj 3L', 23, 0),
(20, 'LKD 6', 'Budova C, dveře č. 132', 'Pokoj 3L', 24, 0),
(21, 'mDrD 1', 'Waldorf ', 'Třída Waldorf', 27, 0),
(22, 'mDrD 2', 'Waldorf ', 'Třída Waldorf', 28, 0),
(23, 'mDrD 3', 'Waldorf ', 'Třída Waldorf', 29, 0),
(24, 'mDrD 4', 'Waldorf ', 'Třída Waldorf', 30, 0),
(25, 'mDrD 5', 'Waldorf ', 'Třída Waldorf', 31, 0),
(26, 'mDrD 6', 'Waldorf ', 'Třída Waldorf', 32, 0),
(27, 'mDrD 7', 'Waldorf ', 'Třída Waldorf', 33, 0),
(28, 'mDrD 8', 'Waldorf ', 'Třída Waldorf', 34, 0),
(29, 'mDrD 9', 'Waldorf ', 'Třída Waldorf', 35, 0),
(30, 'mDrD 10', 'Waldorf ', 'Třída Waldorf', 36, 0),
(31, 'EPIC 1 - prosklená 0p', 'Budova C, dveře č. 11', 'Prosklená klubovna', 37, 0),
(32, 'EPIC 2 - pokoj 0p', 'Budova C, dveře č. 12', 'Pokoj 3L', 38, 0),
(33, 'EPIC 3 - tv místnost 0p', 'Budova C, dveře č. 13', 'TV místnost na C', 39, 0),
(34, 'EPIC 4 – pokoj 0p', 'Budova C, dveře č. 15', 'Pokoj 3L', 40, 0),
(35, 'EPIC 5 – pokoj 0p', 'Budova C, dveře č. 16', 'Pokoj 3L', 41, 0),
(36, 'WarG 1 - C1', 'Budova C, dveře č. 203', 'Velká klubovna na C', 69, 0),
(37, 'EPIC 7 – pokoj 1p', 'Budova C, dveře č. 120', 'Pokoj 3L', 43, 0),
(38, 'WarG 2 - C2', 'Budova C, dveře č. 303', 'Velká klubovna na C', 70, 0),
(39, 'Larp 1 - 1L pokoj 3p.', 'Budova C, dveře č. 308', 'Pokoj 1L', 49, 0),
(40, 'Larp 2 - dvojpokoj 3p.', 'Budova C, dveře č. 310+311', 'Dvojmístnost', 50, 0),
(41, 'Přednáškovka - Klub', 'Budova C, suterén, hudební klub', '', 75, 0),
(42, 'Larp 3 - bunkr B', 'Budova C, suterén, bunkr B', 'Dveře vzadu vlevo', 51, 0),
(43, 'Larp 4 - DDM sál', 'DDM, přízemí, velký sál', '', 52, 0),
(44, 'Larp 6 - DDM 42, malá', 'DDM, 1. patro, dveře č. 42', '', 54, 0),
(45, 'Larp 7 - DDM 36, třída', 'DDM, 1. patro, dveře č. 36', '', 55, 0),
(46, 'Larp 8 - DDM, hudebna', 'DDM, 2. patro, dveře č. 12', '', 56, 0),
(47, 'Larp 9 - Sborovna', 'Budova A, dveře č. 18', 'Sborovna na A', 57, 0),
(48, 'Larp 10 - knihovna', 'Budova B, suterén', 'Po schodech dolů vpravo, dveře vpravo', 58, 0),
(49, 'Larp 11 - W. družina', 'Waldorf, družina', 'Samostatná budova', 59, 0),
(50, 'Larp 12 - W. zahrada', '', 'Zahrada Waldorf družiny', 60, 0),
(51, 'Desk 5 - dlouhá, vlevo', 'KD, 1. patro vlevo', '', 65, 0),
(52, 'Záz 3 - sklad', 'Budova C, dveře č. 3', 'Velká klubovna na C', 84, 0),
(53, 'Bonus 2 - bunkr I', 'Budova C, suterén, bunkr I', 'Tři propojené kumbály, napravo', 71, 0),
(54, 'Záz 6 - Zahrada A', 'Budova A, zahrada', 'Nějaké stromy atp., 2022 - blokováno', 87, 0),
(55, 'Záz 7 - Zahrada B', 'Budova B, zahrada', 'Volnější prostor, blíž bráně, venkovní snídaně', 88, 0),
(56, 'Bonus 3 - zahrada C', 'Budova C, zahrada', 'Hřiště', 72, 0),
(57, 'Bonus 4 - venku na GC', '', '', 73, 0),
(58, 'Bonus 5 - mimo GC', '', '', 74, 0),
(59, 'Desk 7 - sál', 'KD, 1. patro, taneční sál', '', 67, 0),
(60, 'Desk 8 - pódium', 'KD, 1. patro, pódium v sále', '', 68, 0),
(61, 'Desk 2 - prosklený sál', 'KD, 1. patro, prosklený sál', 'Prosklený sál na konci chodby', 62, 0),
(62, 'Desk 3 - 2. malá, pravo', 'KD, 1. patro, druhá vpravo', '', 63, 0),
(63, 'LKD 8', 'Budova C, dveře č. 103', 'Klubovna', 26, 0),
(64, 'Záz 8 - Zahrada KD', 'Atrium za KD, vchod kolem infopultu', '', 89, 0),
(65, 'Prog 1 - Kino', '', '', 76, 0),
(66, 'Desk 1 - předsálí kina', 'KD, 1. patro, předsálí up', '', 61, 0),
(67, 'Prog 2 - předsálí down', 'KD, přízemí, předsálí', '', 77, 0),
(68, 'Prog 3 - Bunkr D+E', 'Budova C, suterén', 'Vstup přes bunkr C', 78, 0),
(69, 'Desk 4 - 1. malá, pravo', 'KD, 1. patro, první vpravo', '', 64, 0),
(70, 'RPG 17', 'Budova C, dveře č. 130', 'Pokoj 3L', 17, 0),
(71, 'RPG 18', 'Budova C, dveře č. 129', 'Pokoj 3L', 18, 0),
(72, 'Prog 6 - jídelna', 'Budova C mezipatro pod přízemím vzadu', '', 80, 0),
(73, 'Prog 7 - mimo GC', '', '', 81, 0),
(74, 'Záz 1 - infopult', 'KD, přízemí u šaten', '', 82, 0),
(75, 'Záz 2 - štáb', 'Budova C, přízemí, dveře 28', '', 83, 0),
(76, 'Záz x', 'Zrušeno', '', 90, 0),
(77, 'Záz 4 - snídárna', 'Budova B, dveře č. 27', 'Snídárna na B', 85, 0),
(78, 'Záz 5 - ostatní', '', '', 86, 0),
(79, 'F – KDD FH3', '', '', 111, 0),
(80, 'LKD 4', 'Budova C, dveře č. 102', 'Pokoj 3L', 22, 0),
(81, 'LKD 3', 'Budova C, dveře č. 134', 'Pokoj 3L', 21, 0),
(82, 'EPIC 9 – tv mistnost 1p', 'Budova C, dveře č. 111', 'TV místnost na C', 45, 0),
(83, 'EPIC 8 - prosklená 1p', 'Budova C, dveře č. 110', 'Prosklená klubovna', 44, 0),
(84, 'EPIC 6 – pokoj 1p', 'Budova C, dveře č. 121', 'Pokoj 3L', 42, 0),
(85, 'F – KDD D5-1', '', '', 109, 0),
(86, 'F - KDD Vstup', '', '', 92, 0),
(87, 'F - KDD L', '', '', 93, 0),
(88, 'F - KDD P bar', '', '', 94, 0),
(89, 'F - KDD D6 L1', '', '', 96, 0),
(90, 'F - KDD D6 L2', '', '', 97, 0),
(91, 'F - KDD D6 L3', '', '', 98, 0),
(92, 'F - KDD D6 L4', '', '', 99, 0),
(93, 'F - KDD D6 L5', '', '', 100, 0),
(94, 'F - KDD D6 P1', '', '', 101, 0),
(95, 'F - KDD D6 P2', '', '', 102, 0),
(96, 'F - KDD D6 P3', '', '', 103, 0),
(97, 'F - KDD D6 P4', '', '', 104, 0),
(98, 'F - KDD D6 L0', '', '', 95, 0),
(99, 'F – KDD D2-1', '', '', 105, 0),
(100, 'F – KDD D2-2', '', '', 106, 0),
(101, 'F – KDD D2-3', '', '', 107, 0),
(102, 'F – KDD D2-4', '', '', 108, 0),
(103, 'EPIC 10 – prosklená 2p', 'Budova C, dveře č. 210', 'Prosklená klubovna', 46, 0),
(114, 'LKD 7', 'Budova C, dveře č. 131', 'Pokoj 3L', 25, 0),
(115, 'Larp 5 - DDM knihovna', '', '', 53, 0),
(117, 'F – KDD D5-2', '', '', 110, 0),
(118, 'F – KDD F1', '', '', 112, 0),
(225, 'Desk 6 - foyer', 'prostor nad schody před bistrem', '', 66, 0),
(226, 'EPIC 11', '', '', 47, 0),
(227, 'EPIC 12', '', '', 48, 0),
(228, 'Prog 4 - Tělocvična C, NEPOUŽÍVAT', 'Budova C, u jídelny', 'Nově rekonstruovaná', 79, 0);

-- --------------------------------------------------------

--
-- Struktura tabulky `akce_organizatori`
--

CREATE TABLE `akce_organizatori` (
  `id_akce` int(11) NOT NULL,
  `id_uzivatele` int(11) NOT NULL COMMENT 'organizátor'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `akce_prihlaseni`
--

CREATE TABLE `akce_prihlaseni` (
  `id_akce` int(11) NOT NULL,
  `id_uzivatele` int(11) NOT NULL,
  `id_stavu_prihlaseni` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `akce_prihlaseni_log`
--

CREATE TABLE `akce_prihlaseni_log` (
  `id_log` bigint(20) UNSIGNED NOT NULL,
  `id_akce` int(11) NOT NULL,
  `id_uzivatele` int(11) NOT NULL,
  `kdy` timestamp NULL DEFAULT NULL,
  `typ` varchar(64) COLLATE utf8_czech_ci DEFAULT NULL,
  `id_zmenil` int(11) DEFAULT NULL,
  `zdroj_zmeny` varchar(128) COLLATE utf8_czech_ci DEFAULT NULL,
  `rocnik` int(10) UNSIGNED DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `akce_prihlaseni_spec`
--

CREATE TABLE `akce_prihlaseni_spec` (
  `id_akce` int(11) NOT NULL,
  `id_uzivatele` int(11) NOT NULL,
  `id_stavu_prihlaseni` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `akce_prihlaseni_stavy`
--

CREATE TABLE `akce_prihlaseni_stavy` (
  `id_stavu_prihlaseni` tinyint(4) NOT NULL,
  `nazev` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `platba_procent` float NOT NULL DEFAULT 100
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `akce_prihlaseni_stavy`
--

INSERT INTO `akce_prihlaseni_stavy` (`id_stavu_prihlaseni`, `nazev`, `platba_procent`) VALUES
(0, 'přihlášen', 100),
(1, 'dorazil', 100),
(2, 'dorazil (náhradník)', 100),
(3, 'nedorazil', 100),
(4, 'pozdě zrušil', 50),
(5, 'náhradník (watchlist)', 0);

-- --------------------------------------------------------

--
-- Struktura tabulky `akce_seznam`
--

CREATE TABLE `akce_seznam` (
  `id_akce` int(11) NOT NULL,
  `patri_pod` int(11) DEFAULT NULL,
  `nazev_akce` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `url_akce` varchar(64) COLLATE utf8_czech_ci DEFAULT NULL,
  `zacatek` datetime DEFAULT NULL,
  `konec` datetime DEFAULT NULL,
  `lokace` int(11) DEFAULT NULL,
  `kapacita` int(11) NOT NULL,
  `kapacita_f` int(11) NOT NULL,
  `kapacita_m` int(11) NOT NULL,
  `cena` int(11) NOT NULL,
  `bez_slevy` tinyint(1) NOT NULL COMMENT 'na aktivitu se neuplatňují slevy',
  `nedava_bonus` tinyint(1) NOT NULL COMMENT 'aktivita negeneruje organizátorovi bonus za vedení aktivity',
  `typ` int(11) NOT NULL,
  `dite` varchar(64) COLLATE utf8_czech_ci DEFAULT NULL COMMENT 'potomci oddělení čárkou',
  `rok` int(11) NOT NULL,
  `stav` int(11) NOT NULL DEFAULT 1,
  `teamova` tinyint(1) NOT NULL,
  `team_min` int(11) DEFAULT NULL COMMENT 'minimální velikost teamu',
  `team_max` int(11) DEFAULT NULL COMMENT 'maximální velikost teamu',
  `team_kapacita` int(11) DEFAULT NULL COMMENT 'max. počet týmů, pokud jde o další kolo týmové aktivity',
  `team_nazev` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL,
  `zamcel` int(11) DEFAULT NULL COMMENT 'případně kdo zamčel aktivitu pro svůj team',
  `zamcel_cas` datetime DEFAULT NULL COMMENT 'případně kdy zamčel aktivitu',
  `popis` int(11) NOT NULL,
  `popis_kratky` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `vybaveni` text COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `akce_sjednocene_tagy`
--

CREATE TABLE `akce_sjednocene_tagy` (
  `id_akce` int(11) NOT NULL,
  `id_tagu` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `akce_stav`
--

CREATE TABLE `akce_stav` (
  `id_stav` int(11) NOT NULL,
  `nazev` varchar(128) COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `akce_stav`
--

INSERT INTO `akce_stav` (`id_stav`, `nazev`) VALUES
(1, 'nová'),
(2, 'aktivovaná'),
(3, 'uzavřená'),
(4, 'systémová'),
(5, 'publikovaná'),
(6, 'připravená'),
(7, 'zamčená');

-- --------------------------------------------------------

--
-- Struktura tabulky `akce_stavy_log`
--

CREATE TABLE `akce_stavy_log` (
  `akce_stavy_log_id` bigint(20) UNSIGNED NOT NULL,
  `id_akce` int(11) NOT NULL,
  `id_stav` int(11) NOT NULL,
  `kdy` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `akce_typy`
--

CREATE TABLE `akce_typy` (
  `id_typu` int(11) NOT NULL,
  `typ_1p` varchar(32) COLLATE utf8_czech_ci NOT NULL,
  `typ_1pmn` varchar(32) COLLATE utf8_czech_ci NOT NULL,
  `url_typu_mn` varchar(32) COLLATE utf8_czech_ci NOT NULL,
  `stranka_o` int(11) NOT NULL COMMENT 'id stranky "O rpg na GC" apod.',
  `poradi` int(11) NOT NULL,
  `mail_neucast` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'poslat mail účastníkovi, pokud nedorazí',
  `popis_kratky` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `aktivni` tinyint(1) DEFAULT 1,
  `zobrazit_v_menu` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `akce_typy`
--

INSERT INTO `akce_typy` (`id_typu`, `typ_1p`, `typ_1pmn`, `url_typu_mn`, `stranka_o`, `poradi`, `mail_neucast`, `popis_kratky`, `aktivni`, `zobrazit_v_menu`) VALUES
(0, '(bez typu – organizační)', '(bez typu – organizační)', 'organizacni', 165, -1, 0, '', 1, 0),
(1, 'turnaj v deskovkách', 'turnaje v deskovkách', 'turnaje', 26, 2, 0, 'V oblíbených nebo nových deskovkách! Jako v každém správném turnaji, můžeš i tady vyhrát nějaké ceny! Třeba právě tu deskovku!', 1, 1),
(2, 'larp', 'larpy', 'larpy', 24, 5, 1, 'Staň se postavou dramatického nebo komediálního příběhu a prožij naplno každý okamžik, jako by svět okolo neexistoval.', 1, 1),
(3, 'přednáška', 'přednášky', 'prednasky', 28, 10, 0, 'Hraní je fajn, to jo, ale v poznání je moc! Přijď si poslechnout zajímavé speakery všeho druhu.', 1, 1),
(4, 'RPG', 'RPG', 'rpg', 17, 6, 1, 'K tomu, aby ses přenesl/a do jiného světa a zažil/a napínavé dobrodružství ti budou stačit jen kostky a vlastní představivost.', 1, 1),
(5, 'workshop', 'workshopy', 'workshopy', 41, -2, 0, '', 0, 0),
(6, 'wargaming', 'wargaming', 'wargaming', 69, 4, 1, 'Armády figurek na bitevním poli! Přijď si zahrát pořádnou řežbu zasazenou do tvého oblíbeného světa!', 1, 1),
(7, 'bonus', 'akční a bonusové aktivity', 'bonusy', 50, 9, 0, 'Nebaví tě pořád sedět u stolu? Tak pro tebe tu máme tyhle pohybovky a další zábavný program.', 1, 1),
(8, 'legendy klubu dobrodruhů', 'legendy klubu dobrodruhů', 'legendy', 116, 8, 1, 'Pára, magie a víly. O tom je svět Příběhů Impéria. Poskládejte společně s dalšími družinami dohromady příběh, o kterém napíšou v The Times!', 1, 1),
(9, 'mistrovství v DrD', 'mistrovství v DrD', 'drd', 14, 7, 0, 'Dračák už nejspíš znáš. Ale znáš taky Mistrovství v Dračáku? Dej dohromady družinu a vyhraj tenhle šampionát ve třech soutěžních kolech.', 1, 1),
(10, 'technická', 'organizační výpomoc', 'organizacni-vypomoc', 148, -1, 0, '', 1, 0),
(11, 'epic', 'epické deskovky', 'epic', 124, 3, 1, 'Chceš si zahrát nějakou velkou strategickou nebo atmosférickou hru? Tady si určitě vybereš!', 1, 1),
(12, 'doprovodný program', 'doprovodný program', 'doprovodny-program', 149, 11, 0, 'Přijde ti to všechno málo? Nevadí, kromě všeho ostatního tu máme i koncert a nějaké ty večírky. ', 1, 1),
(13, 'deskoherna', 'deskoherna', 'deskoherna', 152, 1, 0, 'Deskoherna je zcela zdarma a otevřená téměř celý den. Navíc tu najdeš organizátory a vydavatele, kteří ti hry vysvětlí.', 1, 1),
(102, 'brigádnická', 'brigádnické', 'brigadnicke', 165, -3, 0, 'Placená výpomoc Gameconu', 1, 0);

-- --------------------------------------------------------

--
-- Struktura tabulky `google_api_user_tokens`
--

CREATE TABLE `google_api_user_tokens` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `google_client_id` varchar(128) COLLATE utf8_czech_ci NOT NULL,
  `tokens` text COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `google_drive_dirs`
--

CREATE TABLE `google_drive_dirs` (
  `id` int(10) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `dir_id` varchar(128) COLLATE utf8_czech_ci NOT NULL,
  `original_name` varchar(64) COLLATE utf8_czech_ci NOT NULL,
  `tag` varchar(128) COLLATE utf8_czech_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `hromadne_akce_log`
--

CREATE TABLE `hromadne_akce_log` (
  `id_logu` bigint(20) UNSIGNED NOT NULL,
  `skupina` varchar(128) COLLATE utf8_czech_ci DEFAULT NULL,
  `akce` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL,
  `vysledek` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL,
  `provedl` int(11) DEFAULT NULL,
  `kdy` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `kategorie_sjednocenych_tagu`
--

CREATE TABLE `kategorie_sjednocenych_tagu` (
  `id` int(10) UNSIGNED NOT NULL,
  `nazev` varchar(128) COLLATE utf8_czech_ci NOT NULL,
  `id_hlavni_kategorie` int(10) UNSIGNED DEFAULT NULL,
  `poradi` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `kategorie_sjednocenych_tagu`
--

INSERT INTO `kategorie_sjednocenych_tagu` (`id`, `nazev`, `id_hlavni_kategorie`, `poradi`) VALUES
(8, 'omezení', NULL, 90),
(50, 'omezení Věk', 8, 95),
(1, 'Primary', NULL, 1),
(4, 'prostředí', NULL, 30),
(29, 'prostředí Akční', 4, 35),
(30, 'prostředí Deskovky', 4, 36),
(28, 'prostředí Larp', 4, 34),
(26, 'prostředí LKD', 4, 32),
(27, 'prostředí mDrD', 4, 33),
(32, 'prostředí Přednášky', 4, 38),
(25, 'prostředí RPG', 4, 31),
(31, 'prostředí WG', 4, 37),
(7, 'různé', NULL, 80),
(49, 'různé Partner', 7, 81),
(5, 'styl', NULL, 40),
(37, 'styl Akční', 5, 45),
(38, 'styl Deskovky', 5, 46),
(36, 'styl Larp', 5, 44),
(34, 'styl LKD', 5, 42),
(35, 'styl mDrD', 5, 43),
(40, 'styl Přednášky', 5, 48),
(33, 'styl RPG', 5, 41),
(39, 'styl WG', 5, 47),
(6, 'systém', NULL, 50),
(45, 'systém Akční', 6, 55),
(46, 'systém Deskovky', 6, 56),
(44, 'systém Larp', 6, 54),
(42, 'systém LKD', 6, 52),
(43, 'systém mDrD', 6, 53),
(48, 'systém Přednášky', 6, 58),
(41, 'systém RPG', 6, 51),
(47, 'systém WG', 6, 57),
(2, 'typ', NULL, 10),
(13, 'typ Akční', 2, 15),
(14, 'typ Deskovky', 2, 16),
(12, 'typ Larp', 2, 14),
(10, 'typ LKD', 2, 12),
(11, 'typ mDrD', 2, 13),
(16, 'typ Přednášky', 2, 18),
(9, 'typ RPG', 2, 11),
(15, 'typ WG', 2, 17),
(3, 'žánr', NULL, 20),
(21, 'žánr Akční', 3, 25),
(22, 'žánr Deskovky', 3, 26),
(20, 'žánr Larp', 3, 24),
(18, 'žánr LKD', 3, 22),
(19, 'žánr mDrD', 3, 23),
(24, 'žánr Přednášky', 3, 28),
(17, 'žánr RPG', 3, 21),
(23, 'žánr WG', 3, 27);

-- --------------------------------------------------------

--
-- Struktura tabulky `log_udalosti`
--

CREATE TABLE `log_udalosti` (
  `id_udalosti` bigint(20) UNSIGNED NOT NULL,
  `id_logujiciho` int(11) NOT NULL,
  `zprava` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL,
  `metadata` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL,
  `rok` int(10) UNSIGNED NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `medailonky`
--

CREATE TABLE `medailonky` (
  `id_uzivatele` int(11) NOT NULL,
  `o_sobe` mediumtext COLLATE utf8_czech_ci NOT NULL COMMENT 'markdown',
  `drd` mediumtext COLLATE utf8_czech_ci NOT NULL COMMENT 'markdown -- profil pro DrD'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `migrations`
--

CREATE TABLE `migrations` (
  `migration_id` bigint(20) UNSIGNED NOT NULL,
  `migration_code` varchar(128) COLLATE utf8_czech_ci NOT NULL,
  `applied_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `migrations`
--

INSERT INTO `migrations` (`migration_id`, `migration_code`, `applied_at`) VALUES
(1, '000', NULL),
(2, '001', NULL),
(3, '002', NULL),
(4, '003', NULL),
(5, '004', NULL),
(6, '005', NULL),
(7, '006', NULL),
(8, '007', NULL),
(9, '008', NULL),
(10, '009', NULL),
(11, '010', NULL),
(12, '011', NULL),
(13, '012', NULL),
(14, '013', NULL),
(15, '014', NULL),
(16, '015', NULL),
(17, '016', NULL),
(18, '017', NULL),
(19, '018', NULL),
(20, '019', NULL),
(21, '020', NULL),
(22, '021', NULL),
(23, '022', NULL),
(24, '023', NULL),
(25, '024', NULL),
(26, '025', NULL),
(27, '026', NULL),
(28, '027', NULL),
(29, '028', NULL),
(30, '029', NULL),
(31, '030', NULL),
(32, '031', NULL),
(33, '032', NULL),
(34, '033', NULL),
(35, '034', NULL),
(36, '035', NULL),
(37, '036', NULL),
(38, '037', NULL),
(39, '038', NULL),
(40, '039', NULL),
(41, '040', NULL),
(42, '041', NULL),
(43, '042', NULL),
(44, '043', NULL),
(45, '044', NULL),
(46, '045', NULL),
(47, '046', NULL),
(48, '047', NULL),
(49, '048', NULL),
(50, '049', NULL),
(51, '050', NULL),
(52, '051', NULL),
(53, '052', NULL),
(54, '053', NULL),
(55, '054', NULL),
(56, '055', NULL),
(57, '056', NULL),
(58, '057', NULL),
(59, '058', NULL),
(60, '059', NULL),
(61, '060', NULL),
(62, '061', NULL),
(63, '062', NULL),
(64, '063', NULL),
(65, '064', NULL),
(66, '065', NULL),
(67, '066', NULL),
(68, '067', NULL),
(69, '068', NULL),
(70, '069', NULL),
(71, '070', NULL),
(72, '071', '2021-06-15 07:35:02'),
(77, '072', '2021-12-02 08:42:01'),
(102, '2020-05-22_01-zidle-neodhlasovat', '2022-05-24 09:22:06'),
(73, '2021-06-14_01-drop-old-db_migrations', '2021-06-15 07:35:04'),
(75, '2021-07-01_01-potvrzeni-proti-covidu', '2021-07-07 17:27:57'),
(74, '2021-07-01_01-sloupec-posadil-k-pravum', '2021-07-07 08:42:24'),
(149, '2021-07-13_01-prejmenovat-celkovy-report-na-bfgr-report', '2022-11-05 17:56:04'),
(76, '2021-07-15-samostatny-skript-pro-stravenky-bianco', '2021-07-15 13:22:50'),
(78, '2021-07-21-lepsi-popis-pro-admin-zidli', '2021-12-02 08:42:02'),
(79, '2021-11-20-pridat-unikatni-index-na-fio-id', '2021-12-02 08:42:03'),
(80, '2021-12-17-prejmenovat-slevu-na-bonus', '2022-03-17 18:08:24'),
(81, '2022-02-23-povolit-mazani-z-tabulky-instanci', '2022-04-03 09:54:24'),
(122, '2022-04-28-stavy-v-logu-prihlaseni', '2022-07-05 13:56:46'),
(123, '2022-04-29-pridat-serial-id-do-logu-prihlaseni', '2022-07-05 13:56:48'),
(82, '2022-05-04-pravo-nastaveni', '2022-05-09 07:43:02'),
(83, '2022-05-05_01-tabulka-systemove-nastaveni', '2022-05-09 07:43:03'),
(84, '2022-05-05_02-tabulka-systemove-nastaveni-log', '2022-05-09 07:43:04'),
(85, '2022-05-05_03-kurz-euro-do-systemoveho-nastaveni', '2022-05-09 07:43:05'),
(116, '2022-05-05_04-utf8-pro-tabulky-systemoveho-nastaveni', '2022-06-27 21:59:56'),
(86, '2022-05-09_01-poradi-a-skupina-do-systemoveho-nastaveni', '2022-05-11 09:08:44'),
(87, '2022-05-09_02-bonusy-vypravecu-do-systemoveho-nastaveni', '2022-05-11 09:08:45'),
(88, '2022-05-10_01-shop-predmety', '2022-05-11 09:08:46'),
(90, '2022-05-11_01-shop-upravy', '2022-05-11 21:35:33'),
(96, '2022-05-11_02-prepinani-rucni-a-automaticke-hodnoty-systemoveho-nastaveni', '2022-05-18 08:39:45'),
(97, '2022-05-11_03-zacatek-a-konec-gameconu-do-systemoveho-nastaveni', '2022-05-18 08:39:46'),
(89, '2022-05-11-jen-zakladni-bonus-vypravecu-v-systemovem-nastaveni', '2022-05-11 10:57:14'),
(98, '2022-05-12_02-dalsi-casy-do-systemoveho-nastaveni', '2022-05-18 08:39:47'),
(99, '2022-05-12_03-lidstejsi-nazvy-skupin-systemoveho-nastaveni', '2022-05-18 08:39:48'),
(91, '2022-05-12-zvednout-cenu-kostek-na-25', '2022-05-12 10:05:59'),
(124, '2022-05-13-prejmenovat-sloupec-s-timestamp-v-logu-prihlaseni', '2022-07-05 13:56:49'),
(92, '2022-05-14_01-shop-3XL-tricka', '2022-05-14 13:37:07'),
(93, '2022-05-15_1-mistnosti-2022', '2022-05-15 21:42:08'),
(117, '2022-05-17_00-url-uzivatele', '2022-06-27 21:59:59'),
(94, '2022-05-17_1-mistnosti-oprava-2022', '2022-05-17 14:49:38'),
(95, '2022-05-17_1-Warhammer_40k_turnaj_1_kolo-otevren', '2022-05-17 19:01:59'),
(100, '2022-05-18_01-import-mistnosti-2022-v3', '2022-05-18 08:39:49'),
(112, '2022-05-20_01-report-infopult-ucastnici-balicky', '2022-06-26 11:41:18'),
(103, '2022-05-20_01-zmena-poradi-menu-aktivit', '2022-05-24 15:10:54'),
(113, '2022-05-20_02-infopult-poznamka-k-uzivateli', '2022-06-26 11:41:20'),
(101, '2022-05-20-zvednout-cenu-obedu-a-veceri-na-120', '2022-05-21 11:05:14'),
(106, '2022-05-22_01-zidle-neodhlasovat', '2022-05-30 16:43:47'),
(120, '2022-05-22_02-neplatic-do-systemoveho-nastaveni', '2022-06-30 15:16:17'),
(104, '2022-05-24_01-skryt-typ-aktivity-workshop', '2022-05-24 15:10:55'),
(105, '2022-05-24_01-systemovejsi-skryvani-typu-aktivity-v-menu', '2022-05-24 15:10:56'),
(114, '2022-05-26_01-reporty-v-xlsx', '2022-06-26 11:41:21'),
(118, '2022-05-26_1-logovani-zmen-zidli', '2022-06-27 22:00:00'),
(119, '2022-05-28_1-doplneni-logu-zmen-zidli', '2022-06-27 22:00:05'),
(134, '2022-05-29_01-cas-posledni-zmeny-platby', '2022-07-10 22:57:24'),
(108, '2022-05-29_01-url-uzivatele', '2022-06-01 08:56:13'),
(107, '2022-05-29_01-zidle-herman', '2022-05-30 16:43:48'),
(109, '2022-06-08_1-Oldest_Old_World-Tournament-1-kolo', '2022-06-08 10:37:56'),
(125, '2022-06-11_01-aktivita_editovatelna_x_sekund_po_zavreni', '2022-07-05 13:56:51'),
(126, '2022-06-11_02-aktivita_stavy_log', '2022-07-05 13:56:52'),
(111, '2022-06-14-upravit-cizi-klic-aby-slo-smazat-aktivitu', '2022-06-23 20:10:23'),
(127, '2022-06-16_01-automaticky_zamknout_aktivitu_po', '2022-07-05 13:56:54'),
(128, '2022-06-16_01-upozornit_na_neuzamknutou_aktivitu_poi', '2022-07-05 13:56:55'),
(110, '2022-06-22_01-shop-dalsi-xxl-tricka', '2022-06-22 09:43:45'),
(129, '2022-06-23_01-upozornit_na_neuzamknutou_aktivitu_jen_pokud_ma_par_vypravecu', '2022-07-05 13:56:56'),
(115, '2022-06-25_01-prejmenovat-skript-s-exportem-ubytovani', '2022-06-26 11:41:22'),
(121, '2022-06-29_01-report-neplaticu', '2022-06-30 15:16:18'),
(142, '2022-07-01-obchod_mrizka', '2022-07-14 23:00:35'),
(130, '2022-07-02-prejmenovat-sekci-v-nastaveni', '2022-07-05 13:56:58'),
(131, '2022-07-05-smazat-nepouzite-nastaveni-o-poctu-vypravecu', '2022-07-07 16:08:41'),
(132, '2022-07-07_01-texy-clanku-do-utf8mb4', '2022-07-09 13:54:46'),
(140, '2022-07-08_01-virtualni-uzivatel-system', '2022-07-14 09:27:50'),
(133, '2022-07-09_01-uzavrit-nabidku-ubytovani-2022-11-7', '2022-07-10 13:34:36'),
(135, '2022-07-10_01-text-na-sparovani-odchozich-plateb', '2022-07-10 22:57:25'),
(136, '2022-07-11_01-datum-pro-ukonceni-prodeje-a-zmen-ubytovani', '2022-07-11 20:25:28'),
(137, '2022-07-11_01-datum-pro-ukonceni-prodeje-a-zmen-vseho-mozneho', '2022-07-12 16:00:13'),
(139, '2022-07-11_01-datum-pro-ukonceni-registrace-na-gamecon', '2022-07-13 22:00:07'),
(138, '2022-07-12_01-posunout-cas-prodeje-jidla', '2022-07-12 16:00:14'),
(141, '2022-07-14_01-prejmenovat-report-neplaticu', '2022-07-14 22:31:14'),
(143, '2022-07-14_01-zmenit-editovatelnost-aktivity-na-pridavatelnost', '2022-07-17 14:41:32'),
(148, '2022-07-21_01-logovat-kdo-zmenil-stav-aktivity', '2022-08-01 08:28:36'),
(145, '2022-07-22_01-log-udalosti', '2022-07-22 16:00:48'),
(144, '2022-07-22_01-organizacni-typ-aktivity', '2022-07-22 13:24:54'),
(146, '2022-07-28_01-nastaveni-do-kdy-lze-pridavat-ucastniky', '2022-07-28 23:51:21'),
(147, '2022-07-28_02-prejmenovat-stavy-aktivity-v-databazi', '2022-07-29 09:11:19'),
(150, '2022-08-03_01-pridat-zidli-brigadnik', '2022-11-05 18:08:41'),
(151, '2022-08-03_02-pridat-typ-aktivity-brigadnicka', '2022-11-05 18:08:43'),
(152, '2022-11-14_01-sloucit-rozdeleny-report-starych-ucasti', '2022-11-14 10:33:19'),
(153, '2022-11-30_01-foreign-keys-kaskady', '2022-12-09 17:35:22'),
(154, '2022-12-05_01-vymenit-nulu-jako-id-stavu-aktivity', '2022-12-10 22:35:09'),
(155, '2023-01-28_01-rocnik-platnosti-zidle', '2023-02-10 18:51:52'),
(156, '2023-01-29_01-cizi-klice-pro-zidle', '2023-02-10 18:51:54'),
(157, '2023-01-30_01-kody-zidli', '2023-02-10 18:51:55'),
(158, '2023-01-31_01-sql-pohledy-s-platnymi-rolemi', '2023-02-10 18:51:57'),
(159, '2023-02-01_01-idcka-roli-na-novy-format', '2023-02-10 18:51:58'),
(160, '2023-02-01_02-typy-roli', '2023-02-10 18:51:59'),
(161, '2023-02-02_01-vyznam-roli', '2023-02-10 18:52:01'),
(162, '2023-02-06_01-sjednotit-nazvy-konstant-s-hromadnym-odhlasovanim', '2023-02-13 10:33:14'),
(163, '2023-02-06_02-cas-tretiho-hromadneho-odhlasovani', '2023-02-13 10:33:16'),
(164, '2023-02-10_01-zidle-na-role', '2023-02-25 16:11:51'),
(165, '2023-02-13_01-nrahradit-zidli-za-roli-v-textu', '2023-02-25 16:11:52'),
(166, '2023-02-13_02-admin-na-prezencni-admin', '2023-03-19 14:08:48'),
(167, '2023-02-15_01-odstranit-rok-z-kodu-trvalych-roli', '2023-03-19 14:08:49'),
(168, '2023-02-15_02-skryt-vypravecskou-skupinu', '2023-03-19 14:08:50'),
(169, '2023-02-16_01-prejmenovat-role-s-bonusy', '2023-03-19 14:08:51'),
(170, '2023-02-16_02-aktualizovat-nazvy-prav', '2023-03-19 14:08:52'),
(171, '2023-02-16_03-dalsi-prava-na-noci-zdarma', '2023-03-19 14:08:53'),
(172, '2023-02-16_04-rozdelit-admin-finance-na-penize', '2023-03-19 14:08:54'),
(173, '2023-02-16_05-clen-rady-sef-infopultu', '2023-03-19 14:08:56'),
(174, '2023-02-17_01-pouze-clen-rady-ma-pravo-menit-prava', '2023-03-19 14:08:57'),
(175, '2023-02-23_01-clenove-rady-2023', '2023-03-19 14:08:58'),
(176, '2023-02-23_02-kategorie-role', '2023-03-19 14:08:59'),
(181, '2023-02-25_01-dalsi-vlny-aktivit', '2023-05-11 20:27:54'),
(177, '2023-02-25_01-prejmenovat-cfo', '2023-03-19 14:09:00'),
(182, '2023-03-02_01-log-hromadnych-akci', '2023-05-11 20:27:55'),
(183, '2023-03-02_01-priznak-aktivni-prejmenovat-na-vlastni', '2023-05-11 20:27:56'),
(184, '2023-03-02_02-uprava-nazvu-nastaveni', '2023-05-11 20:27:58'),
(185, '2023-03-06_01-zruseni-konstant-pro-hromadne-odhlasovani', '2023-05-11 20:27:59'),
(186, '2023-03-08_01-platby-mohou-byt-bez-sparovaneho-uzivatele', '2023-05-11 20:28:00'),
(187, '2023-03-10_01-zrusene-objednavky', '2023-05-11 20:28:03'),
(188, '2023-03-13_01-duvod-zmeny-aktivity', '2023-05-11 20:28:09'),
(178, '2023-03-24_01-kategorie-predmetu', '2023-03-24 12:52:05'),
(189, '2023-03-24_01-oprava-preklepu-v-popisu-nastaveni', '2023-05-11 20:28:10'),
(179, '2023-04-06_01-import-mistnosti-2023', '2023-04-13 18:55:02'),
(190, '2023-04-13_01-rocnikove-nastaveni', '2023-05-11 20:28:12'),
(191, '2023-04-14_01-rocnikove-vstupne', '2023-05-11 20:28:14'),
(200, '2023-05-03_01-obnoveni-konstant-pro-hromadne-odhlasovani', '2023-05-17 21:43:28'),
(180, '2023-05-04_01-prejmenovat-report-prihlaseni-a-ubytovani', '2023-05-04 09:16:02'),
(197, '2023-05-05_01-pravo-na-prihlasovani-na-dosud-neotevrene-aktivity', '2023-05-15 17:56:18'),
(192, '2023-05-09_01-report-eshopu', '2023-05-11 20:28:15'),
(193, '2023-05-09_02-unikatni-kombinace-eshopu-nazev-rok', '2023-05-11 20:28:16'),
(194, '2023-05-11_01-doklady-totoznosti', '2023-05-11 20:28:18'),
(195, '2023-05-11_02-statni-obcanstvi', '2023-05-12 10:00:05'),
(196, '2023-05-13_01-moznost-vypnout-mail-o-uvolnenem-ubytovani', '2023-05-13 10:25:04'),
(198, '2023-05-16_01-podpora-plateb-deset-tisic-a-vice', '2023-05-16 18:27:29'),
(199, '2023-05-17_01-moznost-omezit-format-quick-reportu', '2023-05-17 17:42:43'),
(201, '2023-05-23_01-ujasnit-nazev-reportu-se-zustatky', '2023-05-23 10:18:57'),
(203, '2023-05-24_01-odhlaseni-pet-minut-po-prihlaseni-bez-pokuty', '2023-06-05 16:44:08'),
(202, '2023-05-26_01-platne_role_vcetne_historicke_ucasti', '2023-05-26 11:20:47'),
(204, '2023-06-13_01-fix-platnost-noych-systemovych-nastaveni', '2023-06-13 11:03:56'),
(205, '2023-06-26_01-oprava-cizich-klicu-logu-roli', '2023-06-26 08:15:00'),
(206, '2023-06-28_01-prazdne-staty-uctu-na-cekou-republiku', '2023-07-30 18:16:54'),
(207, '2023-07-06_01-priznak-uctu-z-rychloregistrace', '2023-07-30 18:16:54'),
(208, '2023-07-11_01-nedava-slevu-na-nedava-bonus', '2023-07-30 18:16:54'),
(209, '2023-07-11_01-report-balicku-bez-xlsx', '2023-07-30 18:16:54'),
(210, '2023-07-12_01-skryt-report-tricek-negrouped', '2023-07-30 18:16:54'),
(211, '2023-07-21_01-objednatel-do-nakupu', '2023-07-30 18:16:54');

-- --------------------------------------------------------

--
-- Struktura tabulky `mutex`
--

CREATE TABLE `mutex` (
  `id_mutex` int(10) UNSIGNED NOT NULL,
  `akce` varchar(128) COLLATE utf8_czech_ci NOT NULL,
  `klic` varchar(128) COLLATE utf8_czech_ci NOT NULL,
  `zamknul` int(11) DEFAULT NULL,
  `od` datetime NOT NULL,
  `do` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `novinky`
--

CREATE TABLE `novinky` (
  `id` int(11) NOT NULL,
  `typ` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1-novinka 2-blog',
  `vydat` datetime DEFAULT NULL,
  `url` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `nazev` varchar(200) COLLATE utf8_czech_ci NOT NULL,
  `autor` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL,
  `text` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `obchod_bunky`
--

CREATE TABLE `obchod_bunky` (
  `id` int(11) NOT NULL,
  `typ` tinyint(4) NOT NULL COMMENT '0-předmět, 1-stránka, 2-zpět, 3-shrnutí',
  `text` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL,
  `barva` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL,
  `cil_id` int(11) DEFAULT NULL COMMENT 'Id cílove mřížky nebo předmětu.',
  `mrizka_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `obchod_mrizky`
--

CREATE TABLE `obchod_mrizky` (
  `id` int(11) NOT NULL,
  `text` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `platby`
--

CREATE TABLE `platby` (
  `id` int(11) NOT NULL COMMENT 'kvůli indexu a vícenásobným platbám',
  `id_uzivatele` int(11) DEFAULT NULL,
  `fio_id` bigint(20) DEFAULT NULL,
  `castka` decimal(10,2) NOT NULL,
  `rok` smallint(6) NOT NULL,
  `provedeno` timestamp NOT NULL DEFAULT current_timestamp(),
  `provedl` int(11) NOT NULL,
  `poznamka` text COLLATE utf8_czech_ci DEFAULT NULL,
  `pripsano_na_ucet_banky` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Zástupná struktura pro pohled `platne_role`
-- (Vlastní pohled viz níže)
--
CREATE TABLE `platne_role` (
`id_role` int(11)
,`kod_role` varchar(36)
,`nazev_role` varchar(255)
,`popis_role` text
,`rocnik_role` int(11)
,`typ_role` varchar(24)
,`vyznam_role` varchar(48)
,`skryta` tinyint(1)
,`kategorie_role` tinyint(3) unsigned
);

-- --------------------------------------------------------

--
-- Zástupná struktura pro pohled `platne_role_uzivatelu`
-- (Vlastní pohled viz níže)
--
CREATE TABLE `platne_role_uzivatelu` (
`id_uzivatele` int(11)
,`id_role` int(11)
,`posazen` timestamp
,`posadil` int(11)
);

-- --------------------------------------------------------

--
-- Struktura tabulky `prava_role`
--

CREATE TABLE `prava_role` (
  `id_role` int(11) NOT NULL,
  `id_prava` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `prava_role`
--

INSERT INTO `prava_role` (`id_role`, `id_prava`) VALUES
(-202300025, 1008),
(-202300025, 1016),
(-202300025, 1025),
(-202300025, 1028),
(-202300024, 1012),
(-202300024, 1016),
(-202300024, 1019),
(-202300024, 1021),
(-202300024, 1025),
(-202300023, 1016),
(-202300019, 1018),
(-202300018, 1015),
(-202300017, 1012),
(-202300017, 1016),
(-202300017, 1019),
(-202300017, 1021),
(-202300017, 1025),
(-202300013, 4),
(-202300013, 109),
(-202300013, 1016),
(-202300013, 1025),
(-202300013, 1027),
(-202300013, 1028),
(-202300008, 100),
(-202300008, 101),
(-202300008, 1016),
(-202300008, 1025),
(-202300007, 1008),
(-202300007, 1016),
(-202300006, 4),
(-202300006, 109),
(-202300006, 1012),
(-202300006, 1016),
(-202300006, 1019),
(-202300006, 1021),
(-202300006, 1024),
(-202300006, 1025),
(-202300006, 1027),
(-2302, -2302),
(-2301, -2301),
(-2202, -2202),
(-2201, -2201),
(-2102, -2102),
(-2101, -2101),
(-2002, -2002),
(-2001, -2001),
(-1902, -1902),
(-1901, -1901),
(-1802, -1802),
(-1801, -1801),
(-1702, -1702),
(-1701, -1701),
(-1602, -1602),
(-1601, -1601),
(-1502, -1502),
(-1501, -1501),
(-1402, -1402),
(-1401, -1401),
(-1302, -1302),
(-1301, -1301),
(-1202, -1202),
(-1201, -1201),
(-1102, -1102),
(-1101, -1101),
(-1002, -1002),
(-1001, -1001),
(-902, -902),
(-901, -901),
(2, 4),
(2, 100),
(2, 101),
(2, 102),
(2, 103),
(2, 104),
(2, 105),
(2, 106),
(2, 107),
(2, 109),
(2, 1002),
(2, 1003),
(2, 1005),
(2, 1008),
(2, 1016),
(2, 1020),
(2, 1021),
(2, 1022),
(2, 1023),
(2, 1024),
(2, 1025),
(2, 1026),
(2, 1027),
(2, 1028),
(9, 4),
(9, 5),
(9, 1028),
(15, 1002),
(15, 1003),
(15, 1016),
(15, 1019),
(16, 8),
(20, 108),
(20, 110),
(20, 111),
(21, 4),
(21, 100),
(21, 101),
(21, 102),
(21, 103),
(21, 104),
(21, 105),
(21, 106),
(21, 107),
(21, 109),
(21, 1008),
(21, 1012),
(21, 1015),
(21, 1016),
(21, 1018),
(21, 1019),
(21, 1021),
(21, 1022),
(21, 1024),
(21, 1025),
(21, 1026),
(21, 1027),
(22, 4),
(22, 100),
(22, 101),
(22, 102),
(22, 103),
(22, 104),
(22, 105),
(22, 106),
(22, 107),
(22, 109),
(22, 1012),
(22, 1015),
(22, 1016),
(22, 1018),
(22, 1019),
(22, 1020),
(22, 1021),
(22, 1022),
(22, 1024),
(22, 1025),
(22, 1026),
(22, 1027),
(23, 1032),
(23, 1033),
(25, 9);

-- --------------------------------------------------------

--
-- Struktura tabulky `reporty`
--

CREATE TABLE `reporty` (
  `id` int(10) UNSIGNED NOT NULL,
  `skript` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `nazev` varchar(200) COLLATE utf8_czech_ci DEFAULT NULL,
  `format_xlsx` tinyint(1) DEFAULT 1,
  `format_html` tinyint(1) DEFAULT 1,
  `viditelny` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `reporty`
--

INSERT INTO `reporty` (`id`, `skript`, `nazev`, `format_xlsx`, `format_html`, `viditelny`) VALUES
(1, 'aktivity', 'Historie přihlášení na aktivity', 1, 1, 1),
(32, 'bfgr-report', '<span id=\"bfgr\" class=\"hinted\">BFGR (celkový report) {ROK}<span class=\"hint\"><em>Big f**king Gandalf report</em> určený pro Gandalfovu Excelentní magii</span></span>', 1, 1, 1),
(9, 'duplicity', 'Duplicitní uživatelé', 0, 1, 1),
(18, 'finance-aktivity-negenerujici-bonus', 'Finance: Aktivity negenerující bonus', 1, 1, 1),
(17, 'finance-lide-v-databazi-a-zustatky', 'Finance: Lidé v databázi + zůstatky z předchozího ročníku', 1, 1, 1),
(19, 'finance-prijmy-a-vydaje-infopultaka', 'Finance: Příjmy a výdaje infopulťáka', 1, 1, 1),
(53, 'finance-report-eshop', 'Finance: E-shop', 1, 1, 1),
(50, 'finance-report-neplaticu', 'Finance: Neplatiči k odhlášení', 1, 1, 1),
(34, 'finance-report-ubytovani', 'Ubytování', 1, 1, 0),
(6, 'grafy-ankety', 'Grafy k anketě', 0, 1, 0),
(15, 'maily-dle-data-ucasti', 'Maily - nedávní účastníci', 1, 0, 1),
(13, 'maily-neprihlaseni', 'Maily – nepřihlášení na GC', 1, 1, 1),
(12, 'maily-prihlaseni', 'Maily – přihlášení na GC (vč. unsubscribed)', 1, 1, 1),
(14, 'maily-vypraveci', 'Maily – vypravěči (vč. unsubscribed)', 1, 1, 1),
(8, 'neprihlaseni-vypraveci', 'Nepřihlášení a neubytovaní vypravěči + další', 1, 1, 1),
(5, 'parovani-ankety', 'Párování ankety a údajů uživatelů', 0, 1, 0),
(2, 'pocty-her', 'Účastníci a počty jejich aktivit', 1, 0, 1),
(3, 'pocty-her-graf', 'Graf rozložení rozmanitosti her', 0, 1, 1),
(49, 'report-infopult-ucastnici-balicky', 'Infopult: Balíčky účastníků', 0, 1, 1),
(4, 'rozesilani-ankety', 'Rozesílání ankety s tokenem', 0, 1, 0),
(10, 'stravenky', 'Stravenky uživatelů', 0, 1, 1),
(11, 'stravenky-bianco', 'Stravenky (bianco)', 0, 1, 1),
(7, 'update-zustatku', 'UPDATE příkaz zůstatků pro letošní GC', 0, 1, 1),
(26, 'zazemi-a-program-aktivity-pro-dotaznik-dle-linii', 'Zázemí & Program: Aktivity pro dotazník dle linií', 1, 1, 1),
(28, 'zazemi-a-program-casy-a-umisteni-aktivit', 'Zázemí & Program: Časy a umístění aktivit', 1, 1, 1),
(20, 'zazemi-a-program-drd-historie-ucasti', 'Zázemí & Program: DrD: Historie účasti', 1, 1, 1),
(21, 'zazemi-a-program-drd-seznam-prihlasenych-pro-aktualni-rok', 'Zázemí & Program: DrD: Seznam přihlášených pro aktuální rok', 1, 1, 1),
(25, 'zazemi-a-program-emaily-na-ucastniky-dle-linii', 'Zázemí & Program: Emaily na účastníky dle linií', 1, 1, 1),
(24, 'zazemi-a-program-emaily-na-vypravece-dle-linii', 'Zázemí & Program: Emaily na vypravěče dle linií', 1, 1, 1),
(23, 'zazemi-a-program-pocet-sledujicich-pro-aktualni-rok', 'Zázemí & Program: Počet sledujících pro aktuální rok', 1, 1, 1),
(27, 'zazemi-a-program-potvrzeni-pro-navstevniky-mladsi-patnacti-let', 'Zázemí & Program: Potvrzení pro návštěvníky mladší patnácti let', 1, 1, 1),
(29, 'zazemi-a-program-prehled-mistnosti', 'Zázemí & Program: Přehled místností', 1, 1, 1),
(30, 'zazemi-a-program-seznam-ucastniku-a-tricek', 'Zázemí & Program: Seznam účastníků a triček', 1, 1, 0),
(31, 'zazemi-a-program-seznam-ucastniku-a-tricek-grouped', 'Zázemí & Program: Seznam účastníků a triček (grouped)', 1, 1, 1),
(22, 'zazemi-a-program-zarizeni-mistnosti', 'Zázemí & Program: Zařízení místností', 1, 1, 1);

-- --------------------------------------------------------

--
-- Struktura tabulky `reporty_log_pouziti`
--

CREATE TABLE `reporty_log_pouziti` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `id_reportu` int(10) UNSIGNED NOT NULL,
  `id_uzivatele` int(11) NOT NULL,
  `format` varchar(10) COLLATE utf8_czech_ci NOT NULL,
  `cas_pouziti` datetime DEFAULT NULL,
  `casova_zona` varchar(100) COLLATE utf8_czech_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `reporty_quick`
--

CREATE TABLE `reporty_quick` (
  `id` int(11) NOT NULL,
  `nazev` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `dotaz` text COLLATE utf8_czech_ci NOT NULL,
  `format_xlsx` tinyint(1) DEFAULT 1,
  `format_html` tinyint(1) DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `role_seznam`
--

CREATE TABLE `role_seznam` (
  `id_role` int(11) NOT NULL,
  `kod_role` varchar(36) COLLATE utf8_czech_ci NOT NULL,
  `nazev_role` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `popis_role` text COLLATE utf8_czech_ci NOT NULL,
  `rocnik_role` int(11) NOT NULL,
  `typ_role` varchar(24) COLLATE utf8_czech_ci NOT NULL,
  `vyznam_role` varchar(48) COLLATE utf8_czech_ci NOT NULL,
  `skryta` tinyint(1) DEFAULT 0,
  `kategorie_role` tinyint(3) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `role_seznam`
--

INSERT INTO `role_seznam` (`id_role`, `kod_role`, `nazev_role`, `popis_role`, `rocnik_role`, `typ_role`, `vyznam_role`, `skryta`, `kategorie_role`) VALUES
(-202300029, 'GC2023_ZKONTROLOVANE_UDAJE', 'Zkontrolované údaje', 'Zkontrolované údaje', 2023, 'rocnikova', 'ZKONTROLOVANE_UDAJE', 1, 0),
(-202300028, 'GC2023_SOBOTNI_NOC_ZDARMA', 'Sobotní noc zdarma', 'Sobotní noc zdarma', 2023, 'rocnikova', 'SOBOTNI_NOC_ZDARMA', 0, 1),
(-202300025, 'GC2023_BRIGADNIK', 'Brigádník', 'Zase práce?', 2023, 'rocnikova', 'BRIGADNIK', 0, 1),
(-202300024, 'GC2023_HERMAN', 'Herman', 'Živoucí návod deskových her sloužící ve jménu Gameconu', 2023, 'rocnikova', 'HERMAN', 0, 1),
(-202300023, 'GC2023_NEODHLASOVAT', 'Neodhlašovat', 'Může zaplatit až na místě. Je chráněn před odhlašováním neplatičů a nezaplacených objednávek.', 2023, 'rocnikova', 'NEODHLASOVAT', 0, 1),
(-202300019, 'GC2023_NEDELNI_NOC_ZDARMA', 'Nedělní noc zdarma', '', 2023, 'rocnikova', 'NEDELNI_NOC_ZDARMA', 0, 1),
(-202300018, 'GC2023_STREDECNI_NOC_ZDARMA', 'Středeční noc zdarma', '', 2023, 'rocnikova', 'STREDECNI_NOC_ZDARMA', 0, 1),
(-202300017, 'GC2023_DOBROVOLNIK_SENIOR', 'Dobrovolník senior', 'Dobrovolník dlouhodobě spolupracující s GC', 2023, 'rocnikova', 'DOBROVOLNIK_SENIOR', 0, 1),
(-202300013, 'GC2023_PARTNER', 'Partner', 'Vystavovatelé, lidé od deskovek, atp.', 2023, 'rocnikova', 'PARTNER', 0, 1),
(-202300008, 'GC2023_INFOPULT', 'Infopult', 'Operátor infopultu', 2023, 'rocnikova', 'INFOPULT', 0, 1),
(-202300007, 'GC2023_ZAZEMI', 'Zázemí', 'Členové zázemí GC (kuchařky, …)', 2023, 'rocnikova', 'ZAZEMI', 0, 1),
(-202300006, 'GC2023_VYPRAVEC', 'Vypravěč', 'Organizátor aktivit na GC', 2023, 'rocnikova', 'VYPRAVEC', 0, 1),
(-2303, 'GC2023_ODJEL', 'GC2023 odjel', 'GC2023 odjel', 2023, 'ucast', 'ODJEL', 0, 0),
(-2302, 'GC2023_PRITOMEN', 'GC2023 přítomen', 'GC2023 přítomen', 2023, 'ucast', 'PRITOMEN', 0, 0),
(-2301, 'GC2023_PRIHLASEN', 'GC2023 přihlášen', 'GC2023 přihlášen', 2023, 'ucast', 'PRIHLASEN', 0, 0),
(-2203, 'GC2022_ODJEL', 'GC2022 odjel', '', 2022, 'ucast', 'ODJEL', 0, 0),
(-2202, 'GC2022_PRITOMEN', 'GC2022 přítomen', '', 2022, 'ucast', 'PRITOMEN', 0, 0),
(-2201, 'GC2022_PRIHLASEN', 'GC2022 přihlášen', '', 2022, 'ucast', 'PRIHLASEN', 0, 0),
(-2103, 'GC2021_ODJEL', 'GC2021 odjel', '', 2021, 'ucast', 'ODJEL', 0, 0),
(-2102, 'GC2021_PRITOMEN', 'GC2021 přítomen', '', 2021, 'ucast', 'PRITOMEN', 0, 0),
(-2101, 'GC2021_PRIHLASEN', 'GC2021 přihlášen', '', 2021, 'ucast', 'PRIHLASEN', 0, 0),
(-2003, 'GC2020_ODJEL', 'GC2020 odjel', '', 2020, 'ucast', 'ODJEL', 0, 0),
(-2002, 'GC2020_PRITOMEN', 'GC2020 přítomen', '', 2020, 'ucast', 'PRITOMEN', 0, 0),
(-2001, 'GC2020_PRIHLASEN', 'GC2020 přihlášen', '', 2020, 'ucast', 'PRIHLASEN', 0, 0),
(-1903, 'GC2019_ODJEL', 'GC2019 odjel', '', 2019, 'ucast', 'ODJEL', 0, 0),
(-1902, 'GC2019_PRITOMEN', 'GC2019 přítomen', '', 2019, 'ucast', 'PRITOMEN', 0, 0),
(-1901, 'GC2019_PRIHLASEN', 'GC2019 přihlášen', '', 2019, 'ucast', 'PRIHLASEN', 0, 0),
(-1803, 'GC2018_ODJEL', 'GC2018 odjel', '', 2018, 'ucast', 'ODJEL', 0, 0),
(-1802, 'GC2018_PRITOMEN', 'GC2018 přítomen', '', 2018, 'ucast', 'PRITOMEN', 0, 0),
(-1801, 'GC2018_PRIHLASEN', 'GC2018 přihlášen', '', 2018, 'ucast', 'PRIHLASEN', 0, 0),
(-1703, 'GC2017_ODJEL', 'GC2017 odjel', '', 2017, 'ucast', 'ODJEL', 0, 0),
(-1702, 'GC2017_PRITOMEN', 'GC2017 přítomen', '', 2017, 'ucast', 'PRITOMEN', 0, 0),
(-1701, 'GC2017_PRIHLASEN', 'GC2017 přihlášen', '', 2017, 'ucast', 'PRIHLASEN', 0, 0),
(-1603, 'GC2016_ODJEL', 'GC2016 odjel', '', 2016, 'ucast', 'ODJEL', 0, 0),
(-1602, 'GC2016_PRITOMEN', 'GC2016 přítomen', '', 2016, 'ucast', 'PRITOMEN', 0, 0),
(-1601, 'GC2016_PRIHLASEN', 'GC2016 přihlášen', '', 2016, 'ucast', 'PRIHLASEN', 0, 0),
(-1503, 'GC2015_ODJEL', 'GC2015 odjel', '', 2015, 'ucast', 'ODJEL', 0, 0),
(-1502, 'GC2015_PRITOMEN', 'GC2015 přítomen', '', 2015, 'ucast', 'PRITOMEN', 0, 0),
(-1501, 'GC2015_PRIHLASEN', 'GC2015 přihlášen', '', 2015, 'ucast', 'PRIHLASEN', 0, 0),
(-1403, 'GC2014_ODJEL', 'GC2014 odjel', '', 2014, 'ucast', 'ODJEL', 0, 0),
(-1402, 'GC2014_PRITOMEN', 'GC2014 přítomen', '', 2014, 'ucast', 'PRITOMEN', 0, 0),
(-1401, 'GC2014_PRIHLASEN', 'GC2014 přihlášen', '', 2014, 'ucast', 'PRIHLASEN', 0, 0),
(-1302, 'GC2013_PRITOMEN', 'GC2013 přítomen', '', 2013, 'ucast', 'PRITOMEN', 0, 0),
(-1301, 'GC2013_PRIHLASEN', 'GC2013 přihlášen', '', 2013, 'ucast', 'PRIHLASEN', 0, 0),
(-1202, 'GC2012_PRITOMEN', 'GC2012 přítomen', '', 2012, 'ucast', 'PRITOMEN', 0, 0),
(-1201, 'GC2012_PRIHLASEN', 'GC2012 přihlášen', '', 2012, 'ucast', 'PRIHLASEN', 0, 0),
(-1102, 'GC2011_PRITOMEN', 'GC2011 přítomen', '', 2011, 'ucast', 'PRITOMEN', 0, 0),
(-1101, 'GC2011_PRIHLASEN', 'GC2011 přihlášen', '', 2011, 'ucast', 'PRIHLASEN', 0, 0),
(-1002, 'GC2010_PRITOMEN', 'GC2010 přítomen', '', 2010, 'ucast', 'PRITOMEN', 0, 0),
(-1001, 'GC2010_PRIHLASEN', 'GC2010 přihlášen', '', 2010, 'ucast', 'PRIHLASEN', 0, 0),
(-902, 'GC2009_PRITOMEN', 'GC2009 přítomen', '', 2009, 'ucast', 'PRITOMEN', 0, 0),
(-901, 'GC2009_PRIHLASEN', 'GC2009 přihlášen', '', 2009, 'ucast', 'PRIHLASEN', 0, 0),
(2, 'ORGANIZATOR_ZDARMA', 'Organizátor (zdarma)', 'Člen organizačního týmu GC', -1, 'trvala', 'ORGANIZATOR_ZDARMA', 0, 0),
(9, 'VYPRAVECSKA_SKUPINA', 'Vypravěčská skupina', 'Organizátorská skupina pořádající na GC (dodavatelé, …)', -1, 'trvala', 'VYPRAVECSKA_SKUPINA', 1, 0),
(15, 'CESTNY_ORGANIZATOR', 'Čestný organizátor', 'Bývalý organizátor GC', -1, 'trvala', 'CESTNY_ORGANIZATOR', 0, 0),
(16, 'ADMIN', 'Prezenční admin', 'Pro změnu účastníků v uzavřených aktivitách. NEBEZPEČNÉ, NEPOUŽÍVAT!', -1, 'trvala', 'ADMIN', 0, 0),
(20, 'CFO', 'CFO', 'Organizátor, který může nakládat s financemi GC', -1, 'trvala', 'CFO', 0, 0),
(21, 'PUL_ORG_UBYTKO', 'Půl-org s ubytkem', 'Krom jiného ubytování zdarma', -1, 'trvala', 'PUL_ORG_UBYTKO', 0, 0),
(22, 'PUL_ORG_TRICKO', 'Půl-org s tričkem', 'Krom jiného trička zdarma', -1, 'trvala', 'PUL_ORG_TRICKO', 0, 0),
(23, 'CLEN_RADY', 'Člen rady', 'Členové rady mají zvláštní zodpovědnost a pravomoce', -1, 'trvala', 'CLEN_RADY', 0, 0),
(24, 'SEF_INFOPULTU', 'Šéf infopultu', 'S pravomocemi dělat větší zásahy u přhlášených', -1, 'trvala', 'SEF_INFOPULTU', 0, 0),
(25, 'SEF_PROGRAMU', 'Šéf programu', 'Všeobecné \"vedení\" programu - obecná dramaturgie, rozvoj sekcí, finance programu', -1, 'trvala', 'SEF_PROGRAMU', 0, 0);

-- --------------------------------------------------------

--
-- Struktura tabulky `r_prava_soupis`
--

CREATE TABLE `r_prava_soupis` (
  `id_prava` int(11) NOT NULL,
  `jmeno_prava` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `popis_prava` text COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `r_prava_soupis`
--

INSERT INTO `r_prava_soupis` (`id_prava`, `jmeno_prava`, `popis_prava`) VALUES
(-2302, 'GC2023 přítomen', 'GC2023 přítomen'),
(-2301, 'GC2023 přihlášen', 'GC2023 přihlášen'),
(-2202, 'GC2022 přítomen', ''),
(-2201, 'GC2022 přihlášen', ''),
(-2102, 'GC2021 přítomen', ''),
(-2101, 'GC2021 přihlášen', ''),
(-2002, 'GC2020 přítomen', ''),
(-2001, 'GC2020 přihlášen', ''),
(-1902, 'GC2019 přítomen', ''),
(-1901, 'GC2019 přihlášen', ''),
(-1802, 'GC2018 přítomen', ''),
(-1801, 'GC2018 přihlášen', ''),
(-1702, 'GC2017 přítomen', ''),
(-1701, 'GC2017 přihlášen', ''),
(-1602, 'GC2016 přítomen', ''),
(-1601, 'GC2016 přihlášen', ''),
(-1502, 'GC2015 přítomen', ''),
(-1501, 'GC2015 přihlášen', ''),
(-1402, 'GC2014 přítomen', ''),
(-1401, 'GC2014 přihlášen', ''),
(-1302, 'GC2013 přítomen', ''),
(-1301, 'GC2013 přihlášen', ''),
(-1202, 'GC2012 přítomen', ''),
(-1201, 'GC2012 přihlášen', ''),
(-1102, 'GC2011 přítomen', ''),
(-1101, 'GC2011 přihlášen', ''),
(-1002, 'GC2010 přítomen', ''),
(-1001, 'GC2010 přihlášen', ''),
(-902, 'GC2009 přítomen', ''),
(-901, 'GC2009 přihlášen', ''),
(4, 'Pořádání aktivit', 'Uživatel může pořádat aktivity (je v nabídce pořadatelů aktivit a má v administraci nabídku „moje aktivity“)'),
(5, 'Překrývání aktivit', 'Smí mít zaregistrovaných víc aktivit v jeden čas'),
(8, 'Změna historie aktivit', 'může přihlašovat a odhlašovat lidi z aktivit, které už proběhly'),
(9, 'Přhlašování na dosud neotevřené aktivity', 'Může přihlašovat a odhlašovat lidi z aktivit, které ještě nejsou Připravené (jsou teprve Publikované)'),
(100, 'Administrace - panel Infopult', ''),
(101, 'Administrace - panel Uživatel', ''),
(102, 'Administrace - panel Aktivity', ''),
(103, 'Administrace - panel Prezence', ''),
(104, 'Administrace - panel Reporty', ''),
(105, 'Administrace - panel Web', ''),
(106, 'Administrace - panel Práva', ''),
(107, 'Administrace - panel Statistiky', ''),
(108, 'Administrace - panel Finance', ''),
(109, 'Administrace - panel Moje aktivity', ''),
(110, 'Administrace - panel Nastavení', 'Systémové hodnoty pro Gamecon'),
(111, 'Administrace - panel Peníze', 'Koutek pro šéfa financí GC'),
(1002, 'Placka zdarma', ''),
(1003, 'Kostka zdarma', ''),
(1004, 'Jídlo se slevou', 'Může si objednávat jídlo se slevou'),
(1005, 'Jídlo zdarma', 'Může si objednávat jídlo zdarma'),
(1008, 'Ubytování zdarma', 'Má zdarma ubytování po celou dobu'),
(1012, 'Modré tričko za dosaženou slevu %MODRE_TRICKO_ZDARMA_OD%', ''),
(1015, 'Středeční noc zdarma', ''),
(1016, 'Nerušit automaticky objednávky', 'Uživateli se při nezaplacení včas nebudou automaticky rušit objednávky'),
(1018, 'Nedělní noc zdarma', ''),
(1019, 'Sleva na aktivity', 'Sleva 40% na aktivity'),
(1020, 'Dvě jakákoli trička zdarma', ''),
(1021, 'Právo na modré tričko', 'Může si objednávat modrá trička'),
(1022, 'Právo na červené tričko', 'Může si objednávat červená trička'),
(1023, 'Plná sleva na aktivity', 'Sleva 100% na aktivity'),
(1024, 'Statistiky - tabulka účasti', 'V adminu v sekci statistiky v tabulce vlevo nahoře se tato role vypisuje'),
(1025, 'Reporty - zahrnout do reportu \"Nepřihlášení a neubytovaní\"', 'V reportu Nepřihlášení a neubytovaní vypravěči se lidé na této židli vypisují'),
(1026, 'Titul „organizátor“', 'V různých výpisech se označuje jako organizátor'),
(1027, 'Unikátní židle', 'Uživatel může mít jen jednu židli s tímto právem'),
(1028, 'Bez bonusu za vedení aktivit', 'Nedostává bonus za vedení aktivit ani za účast na technických aktivitách'),
(1029, 'Čtvrteční noc zdarma', ''),
(1030, 'Páteční noc zdarma', ''),
(1031, 'Sobotní noc zdarma', ''),
(1032, 'Hromadná aktivace aktivit', 'Může použít \"Aktivovat hromadně\" v aktivitách'),
(1033, 'Změna práv', 'Může měnit práva rolím a měnit role uživatelům');

-- --------------------------------------------------------

--
-- Struktura tabulky `shop_nakupy`
--

CREATE TABLE `shop_nakupy` (
  `id_nakupu` bigint(20) UNSIGNED NOT NULL,
  `id_uzivatele` int(11) NOT NULL,
  `id_objednatele` int(11) DEFAULT NULL,
  `id_predmetu` int(11) NOT NULL,
  `rok` smallint(6) NOT NULL,
  `cena_nakupni` decimal(6,2) NOT NULL COMMENT 'aktuální cena v okamžiku nákupu (bez slev)',
  `datum` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `shop_nakupy_zrusene`
--

CREATE TABLE `shop_nakupy_zrusene` (
  `id_nakupu` bigint(20) UNSIGNED NOT NULL,
  `id_uzivatele` int(11) NOT NULL,
  `id_predmetu` int(11) NOT NULL,
  `rocnik` smallint(6) NOT NULL,
  `cena_nakupni` decimal(6,2) NOT NULL COMMENT 'aktuální cena v okamžiku nákupu (bez slev)',
  `datum_nakupu` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `datum_zruseni` timestamp NOT NULL DEFAULT current_timestamp(),
  `zdroj_zruseni` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `shop_predmety`
--

CREATE TABLE `shop_predmety` (
  `id_predmetu` int(11) NOT NULL,
  `nazev` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `model_rok` smallint(6) NOT NULL,
  `cena_aktualni` decimal(6,2) NOT NULL,
  `stav` tinyint(4) NOT NULL COMMENT '0-mimo, 1-veřejný, 2-podpultový, 3-pozastavený',
  `auto` tinyint(4) NOT NULL COMMENT 'automaticky objednané',
  `nabizet_do` datetime DEFAULT NULL COMMENT 'automatizovaná náhrada za stav 3',
  `kusu_vyrobeno` smallint(6) DEFAULT NULL,
  `typ` tinyint(4) NOT NULL COMMENT '1-předmět, 2-ubytování, 3-tričko, 4-jídlo, 5-vstupné, 6-parcon, 7-vyplaceni',
  `ubytovani_den` tinyint(4) DEFAULT NULL COMMENT 'změněn význam na "obecný atribut den"',
  `popis` varchar(2000) COLLATE utf8_czech_ci NOT NULL,
  `kategorie_predmetu` int(10) UNSIGNED DEFAULT NULL,
  `se_slevou` tinyint(3) UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `shop_predmety`
--

INSERT INTO `shop_predmety` (`id_predmetu`, `nazev`, `model_rok`, `cena_aktualni`, `stav`, `auto`, `nabizet_do`, `kusu_vyrobeno`, `typ`, `ubytovani_den`, `popis`, `kategorie_predmetu`, `se_slevou`) VALUES
(1, 'Placka', 2009, '15.00', 0, 0, NULL, 200, 1, NULL, '', 1, 0),
(2, 'Spacák čtvrtek', 2009, '50.00', 0, 0, NULL, 50, 2, 1, '', NULL, 0),
(3, 'Trojlůžák čtvrtek', 2009, '170.00', 0, 0, NULL, 50, 2, 1, '', NULL, 0),
(4, 'Spacák pátek', 2009, '50.00', 0, 0, NULL, 50, 2, 2, '', NULL, 0),
(5, 'Trojlůžák pátek', 2009, '170.00', 0, 0, NULL, 50, 2, 2, '', NULL, 0),
(6, 'Spacák sobota', 2009, '50.00', 0, 0, NULL, 50, 2, 3, '', NULL, 0),
(7, 'Trojlůžák sobota', 2009, '170.00', 0, 0, NULL, 50, 2, 3, '', NULL, 0),
(8, 'Spacák neděle', 2009, '50.00', 0, 0, NULL, 50, 2, 4, '', NULL, 0),
(9, 'Trojlůžák neděle', 2009, '170.00', 0, 0, NULL, 50, 2, 4, '', NULL, 0),
(10, 'Tričko černé dámské L', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(11, 'Tričko černé dámské M', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(12, 'Tričko černé dámské S', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(13, 'Tričko černé pánské L', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(14, 'Tričko černé pánské M', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(15, 'Tričko černé pánské S', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(16, 'Tričko černé pánské XL', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(17, 'Tričko oranžové dámské L', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(18, 'Tričko oranžové dámské M', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(19, 'Tričko oranžové dámské S', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(20, 'Tričko oranžové pánské L', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(21, 'Tričko oranžové pánské M', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(22, 'Tričko oranžové pánské S', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(23, 'Tričko oranžové pánské XL', 2009, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(24, 'Placka', 2010, '15.00', 0, 0, NULL, 200, 1, NULL, '', 1, 0),
(25, 'Spacák čtvrtek', 2010, '60.00', 0, 0, NULL, 50, 2, 1, '', NULL, 0),
(26, 'Trojlůžák čtvrtek', 2010, '170.00', 0, 0, NULL, 50, 2, 1, '', NULL, 0),
(27, 'Spacák pátek', 2010, '60.00', 0, 0, NULL, 50, 2, 2, '', NULL, 0),
(28, 'Trojlůžák pátek', 2010, '170.00', 0, 0, NULL, 50, 2, 2, '', NULL, 0),
(29, 'Spacák sobota', 2010, '60.00', 0, 0, NULL, 50, 2, 3, '', NULL, 0),
(30, 'Trojlůžák sobota', 2010, '170.00', 0, 0, NULL, 50, 2, 3, '', NULL, 0),
(31, 'Spacák neděle', 2010, '60.00', 0, 0, NULL, 50, 2, 4, '', NULL, 0),
(32, 'Trojlůžák neděle', 2010, '170.00', 0, 0, NULL, 50, 2, 4, '', NULL, 0),
(33, 'Tričko černé dámské L', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(34, 'Tričko černé dámské M', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(35, 'Tričko černé dámské S', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(36, 'Tričko černé pánské L', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(37, 'Tričko černé pánské M', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(38, 'Tričko černé pánské S', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(39, 'Tričko černé pánské XL', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(40, 'Tričko oranžové dámské L', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(41, 'Tričko oranžové dámské M', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(42, 'Tričko oranžové dámské S', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(43, 'Tričko oranžové pánské L', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(44, 'Tričko oranžové pánské M', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(45, 'Tričko oranžové pánské S', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(46, 'Tričko oranžové pánské XL', 2010, '160.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(47, 'Kostka', 2011, '25.00', 0, 0, '2017-07-18 23:59:59', 285, 1, NULL, '', 2, 0),
(48, 'Placka', 2011, '15.00', 0, 0, NULL, 200, 1, NULL, '', 1, 0),
(49, 'Spacák čtvrtek', 2011, '70.00', 0, 0, NULL, 50, 2, 1, '', NULL, 0),
(50, 'Trojlůžák čtvrtek', 2011, '180.00', 0, 0, NULL, 50, 2, 1, '', NULL, 0),
(51, 'Spacák pátek', 2011, '70.00', 0, 0, NULL, 50, 2, 2, '', NULL, 0),
(52, 'Trojlůžák pátek', 2011, '180.00', 0, 0, NULL, 50, 2, 2, '', NULL, 0),
(53, 'Spacák sobota', 2011, '70.00', 0, 0, NULL, 50, 2, 3, '', NULL, 0),
(54, 'Trojlůžák sobota', 2011, '180.00', 0, 0, NULL, 50, 2, 3, '', NULL, 0),
(55, 'Spacák neděle', 2011, '70.00', 0, 0, NULL, 50, 2, 4, '', NULL, 0),
(56, 'Trojlůžák neděle', 2011, '180.00', 0, 0, NULL, 50, 2, 4, '', NULL, 0),
(57, 'Tričko černé dámské L', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(58, 'Tričko černé dámské M', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(59, 'Tričko černé dámské S', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(60, 'Tričko černé pánské L', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(61, 'Tričko černé pánské M', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(62, 'Tričko černé pánské S', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(63, 'Tričko černé pánské XL', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(64, 'Tričko červené dámské L', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(65, 'Tričko červené dámské M', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(66, 'Tričko červené dámské S', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(67, 'Tričko červené pánské L', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(68, 'Tričko červené pánské M', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(69, 'Tričko červené pánské S', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(70, 'Tričko červené pánské XL', 2011, '165.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(71, 'Kostka kruhy', 2022, '25.00', 0, 0, '2022-07-24 21:00:00', 50, 1, NULL, 'kruhy', 2, 0),
(72, 'Placka', 2012, '15.00', 0, 0, NULL, 200, 1, NULL, '', 1, 0),
(73, 'Dvojlůžák čtvrtek', 2012, '190.00', 0, 0, NULL, 50, 2, 1, '', NULL, 0),
(74, 'Spacák čtvrtek', 2012, '70.00', 0, 0, NULL, 50, 2, 1, '', NULL, 0),
(75, 'Trojlůžák čtvrtek', 2012, '180.00', 0, 0, NULL, 50, 2, 1, '', NULL, 0),
(76, 'Dvojlůžák pátek', 2012, '190.00', 0, 0, NULL, 50, 2, 2, '', NULL, 0),
(77, 'Spacák pátek', 2012, '70.00', 0, 0, NULL, 50, 2, 2, '', NULL, 0),
(78, 'Trojlůžák pátek', 2012, '180.00', 0, 0, NULL, 50, 2, 2, '', NULL, 0),
(79, 'Dvojlůžák sobota', 2012, '190.00', 0, 0, NULL, 50, 2, 3, '', NULL, 0),
(80, 'Spacák sobota', 2012, '70.00', 0, 0, NULL, 50, 2, 3, '', NULL, 0),
(81, 'Trojlůžák sobota', 2012, '180.00', 0, 0, NULL, 50, 2, 3, '', NULL, 0),
(82, 'Dvojlůžák neděle', 2012, '190.00', 0, 0, NULL, 50, 2, 4, '', NULL, 0),
(83, 'Spacák neděle', 2012, '70.00', 0, 0, NULL, 50, 2, 4, '', NULL, 0),
(84, 'Trojlůžák neděle', 2012, '180.00', 0, 0, NULL, 50, 2, 4, '', NULL, 0),
(85, 'Tričko černé dámské L', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(86, 'Tričko černé dámské M', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(87, 'Tričko černé dámské S', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(88, 'Tričko černé pánské L', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(89, 'Tričko černé pánské M', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(90, 'Tričko černé pánské S', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(91, 'Tričko černé pánské XL', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(92, 'Tričko červené dámské L', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(93, 'Tričko červené dámské M', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(94, 'Tričko červené dámské S', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(95, 'Tričko červené pánské L', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(96, 'Tričko červené pánské M', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(97, 'Tričko červené pánské S', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(98, 'Tričko červené pánské XL', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(99, 'Tričko modré dámské L', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(100, 'Tričko modré dámské M', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(101, 'Tričko modré dámské S', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(102, 'Tričko modré pánské L', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(103, 'Tričko modré pánské M', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(104, 'Tričko modré pánské S', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(105, 'Tričko modré pánské XL', 2012, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(106, 'Kostka', 2013, '25.00', 0, 0, '2015-06-30 23:59:59', 291, 1, NULL, '', 2, 0),
(107, 'Placka', 2013, '15.00', 0, 0, NULL, 200, 1, NULL, '', 1, 0),
(108, 'Dvojlůžák středa', 2013, '190.00', 0, 0, NULL, 54, 2, 0, '', NULL, 0),
(109, 'Spacák středa', 2013, '70.00', 0, 0, NULL, 150, 2, 0, '', NULL, 0),
(110, 'Trojlůžák středa', 2013, '180.00', 0, 0, NULL, 150, 2, 0, '', NULL, 0),
(111, 'Dvojlůžák čtvrtek', 2013, '190.00', 0, 0, NULL, 54, 2, 1, '', NULL, 0),
(112, 'Spacák čtvrtek', 2013, '70.00', 0, 0, NULL, 150, 2, 1, '', NULL, 0),
(113, 'Trojlůžák čtvrtek', 2013, '180.00', 0, 0, NULL, 150, 2, 1, '', NULL, 0),
(114, 'Dvojlůžák pátek', 2013, '190.00', 0, 0, NULL, 54, 2, 2, '', NULL, 0),
(115, 'Spacák pátek', 2013, '70.00', 0, 0, NULL, 150, 2, 2, '', NULL, 0),
(116, 'Trojlůžák pátek', 2013, '180.00', 0, 0, NULL, 150, 2, 2, '', NULL, 0),
(117, 'Dvojlůžák sobota', 2013, '190.00', 0, 0, NULL, 54, 2, 3, '', NULL, 0),
(118, 'Spacák sobota', 2013, '70.00', 0, 0, NULL, 150, 2, 3, '', NULL, 0),
(119, 'Trojlůžák sobota', 2013, '180.00', 0, 0, NULL, 150, 2, 3, '', NULL, 0),
(120, 'Dvojlůžák neděle', 2013, '190.00', 0, 0, NULL, 54, 2, 4, '', NULL, 0),
(121, 'Spacák neděle', 2013, '70.00', 0, 0, NULL, 150, 2, 4, '', NULL, 0),
(122, 'Trojlůžák neděle', 2013, '180.00', 0, 0, NULL, 150, 2, 4, '', NULL, 0),
(123, 'Tričko černé dámské L', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(124, 'Tričko černé dámské M', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(125, 'Tričko černé dámské S', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(126, 'Tričko černé pánské L', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(127, 'Tričko černé pánské M', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(128, 'Tričko černé pánské S', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(129, 'Tričko černé pánské XL', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(130, 'Tričko červené dámské L', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(131, 'Tričko červené dámské M', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(132, 'Tričko červené dámské S', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(133, 'Tričko červené pánské L', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(134, 'Tričko červené pánské M', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(135, 'Tričko červené pánské S', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(136, 'Tričko červené pánské XL', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(137, 'Tričko modré dámské L', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(138, 'Tričko modré dámské M', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(139, 'Tričko modré dámské S', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(140, 'Tričko modré pánské L', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(141, 'Tričko modré pánské M', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(142, 'Tričko modré pánské S', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(143, 'Tričko modré pánské XL', 2013, '180.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(144, 'Jídlo čtvrtek+neděle*', 2013, '80.00', 0, 0, NULL, NULL, 4, NULL, '', NULL, 0),
(145, 'Jídlo pátek', 2013, '80.00', 0, 0, NULL, NULL, 4, NULL, '', NULL, 0),
(146, 'Jídlo sobota', 2013, '80.00', 0, 0, NULL, NULL, 4, NULL, '', NULL, 0),
(153, 'Penzion Charlie 2L středa', 2013, '890.00', 0, 0, NULL, 6, 2, 0, '', NULL, 0),
(154, 'Penzion Charlie 2L čtvrtek', 2013, '890.00', 0, 0, NULL, 6, 2, 1, '', NULL, 0),
(155, 'Penzion Charlie 2L pátek', 2013, '890.00', 0, 0, NULL, 6, 2, 2, '', NULL, 0),
(156, 'Penzion Charlie 2L sobota', 2013, '890.00', 0, 0, NULL, 6, 2, 3, '', NULL, 0),
(157, 'Penzion Charlie 2L neděle', 2013, '890.00', 0, 0, NULL, 6, 2, 4, '', NULL, 0),
(158, 'Penzion Witch 2-4L středa', 2013, '650.00', 0, 0, NULL, 8, 2, 0, '', NULL, 0),
(159, 'Penzion Witch 2-4L čtvrtek', 2013, '650.00', 0, 0, NULL, 8, 2, 1, '', NULL, 0),
(160, 'Penzion Witch 2-4L pátek', 2013, '650.00', 0, 0, NULL, 8, 2, 2, '', NULL, 0),
(161, 'Penzion Witch 2-4L sobota', 2013, '650.00', 0, 0, NULL, 8, 2, 3, '', NULL, 0),
(162, 'Penzion Witch 2-4L neděle', 2013, '650.00', 0, 0, NULL, 8, 2, 4, '', NULL, 0),
(163, 'Chata Richor 4L středa', 2013, '185.00', 0, 0, NULL, 16, 2, 0, '', NULL, 0),
(164, 'Chata Richor 4L čtvrtek', 2013, '185.00', 0, 0, NULL, 16, 2, 1, '', NULL, 0),
(165, 'Chata Richor 4L pátek', 2013, '185.00', 0, 0, NULL, 16, 2, 2, '', NULL, 0),
(166, 'Chata Richor 4L sobota', 2013, '185.00', 0, 0, NULL, 16, 2, 3, '', NULL, 0),
(167, 'Chata Richor 4L neděle', 2013, '185.00', 0, 0, NULL, 16, 2, 4, '', NULL, 0),
(168, 'Kostka', 2014, '25.00', 0, 0, '2015-06-30 23:59:59', 400, 1, NULL, '', 2, 0),
(169, 'Placka', 2014, '15.00', 0, 1, NULL, NULL, 1, NULL, '', 1, 0),
(170, 'Oběd čtvrtek', 2014, '85.00', 0, 1, '2022-05-21 11:05:14', NULL, 4, 1, '', NULL, 0),
(171, 'Večeře čtvrtek', 2014, '85.00', 0, 1, NULL, NULL, 4, 1, '', NULL, 0),
(172, ' Snídaně pátek', 2014, '25.00', 0, 1, NULL, NULL, 4, 2, '', NULL, 0),
(173, 'Oběd pátek', 2014, '85.00', 0, 1, '2022-05-21 11:05:14', NULL, 4, 2, '', NULL, 0),
(174, 'Večeře pátek', 2014, '85.00', 0, 1, NULL, NULL, 4, 2, '', NULL, 0),
(175, ' Snídaně sobota', 2014, '25.00', 0, 1, NULL, NULL, 4, 3, '', NULL, 0),
(176, 'Oběd sobota', 2014, '85.00', 0, 1, '2022-05-21 11:05:14', NULL, 4, 3, '', NULL, 0),
(177, 'Večeře sobota', 2014, '85.00', 0, 1, NULL, NULL, 4, 3, '', NULL, 0),
(178, ' Snídaně neděle', 2014, '25.00', 0, 1, NULL, NULL, 4, 4, '', NULL, 0),
(179, 'Oběd neděle', 2014, '85.00', 0, 1, '2022-05-21 11:05:14', NULL, 4, 4, '', NULL, 0),
(180, 'Večeře neděle', 2014, '85.00', 0, 1, NULL, NULL, 4, 4, '', NULL, 0),
(181, 'Spacák čtvrtek', 2014, '80.00', 0, 0, NULL, 140, 2, 1, '', NULL, 0),
(182, 'Spacák neděle', 2014, '80.00', 0, 0, NULL, 140, 2, 4, '', NULL, 0),
(183, 'Spacák pátek', 2014, '80.00', 0, 0, NULL, 140, 2, 2, '', NULL, 0),
(184, 'Spacák sobota', 2014, '80.00', 0, 0, NULL, 140, 2, 3, '', NULL, 0),
(185, 'Spacák středa', 2014, '80.00', 0, 0, NULL, 140, 2, 0, '', NULL, 0),
(186, 'Tričko černé dámské L', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(187, 'Tričko černé dámské M', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(188, 'Tričko černé dámské S', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(189, 'Tričko černé pánské L', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(190, 'Tričko černé pánské M', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(191, 'Tričko černé pánské S', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(192, 'Tričko černé pánské XL', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(193, 'Tričko bílé dámské L', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(194, 'Tričko bílé dámské M', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(195, 'Tričko bílé dámské S', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(196, 'Tričko bílé pánské L', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(197, 'Tričko bílé pánské M', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(198, 'Tričko bílé pánské S', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(199, 'Tričko bílé pánské XL', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 0),
(200, 'Tričko červené dámské L', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(201, 'Tričko červené dámské M', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(202, 'Tričko červené dámské S', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(203, 'Tričko červené pánské L', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(204, 'Tričko červené pánské M', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(205, 'Tričko červené pánské S', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(206, 'Tričko červené pánské XL', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(207, 'Tričko modré dámské L', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(208, 'Tričko modré dámské M', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(209, 'Tričko modré dámské S', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(210, 'Tričko modré pánské L', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(211, 'Tričko modré pánské M', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(212, 'Tričko modré pánské S', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(213, 'Tričko modré pánské XL', 2014, '200.00', 0, 0, NULL, NULL, 3, NULL, '', 3, 1),
(214, 'Trojlůžák čtvrtek', 2014, '210.00', 0, 0, NULL, 220, 2, 1, '', NULL, 0),
(215, 'Trojlůžák neděle', 2014, '210.00', 0, 0, NULL, 220, 2, 4, '', NULL, 0),
(216, 'Trojlůžák pátek', 2014, '210.00', 0, 0, NULL, 220, 2, 2, '', NULL, 0),
(217, 'Trojlůžák sobota', 2014, '210.00', 0, 0, NULL, 220, 2, 3, '', NULL, 0),
(218, 'Trojlůžák středa', 2014, '210.00', 0, 0, NULL, 220, 2, 0, '', NULL, 0),
(219, 'Vlastní stan středa', 2014, '50.00', 0, 0, NULL, 35, 2, 0, '', NULL, 0),
(220, 'Vlastní stan čtvrtek', 2014, '50.00', 0, 0, NULL, 35, 2, 1, '', NULL, 0),
(221, 'Vlastní stan pátek', 2014, '50.00', 0, 0, NULL, 35, 2, 2, '', NULL, 0),
(222, 'Vlastní stan sobota', 2014, '50.00', 0, 0, NULL, 35, 2, 3, '', NULL, 0),
(223, 'Vlastní stan neděle', 2014, '50.00', 0, 0, NULL, 35, 2, 4, '', NULL, 0),
(224, 'Kostka', 2015, '25.00', 0, 0, '2018-07-17 23:59:59', 514, 1, NULL, '', 2, 0),
(225, 'Placka', 2015, '15.00', 0, 1, '2015-06-30 23:59:59', NULL, 1, NULL, '', 1, 0),
(226, 'Oběd čtvrtek', 2015, '85.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 1, '', NULL, 0),
(227, 'Večeře čtvrtek', 2015, '85.00', 0, 0, '2015-07-14 23:59:59', NULL, 4, 1, '', NULL, 0),
(228, ' Snídaně pátek', 2015, '25.00', 0, 0, '2015-07-15 23:59:59', NULL, 4, 2, '', NULL, 0),
(229, 'Oběd pátek', 2015, '85.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 2, '', NULL, 0),
(230, 'Večeře pátek', 2015, '85.00', 0, 0, '2015-07-15 23:59:59', NULL, 4, 2, '', NULL, 0),
(231, ' Snídaně sobota', 2015, '25.00', 0, 0, '2015-07-16 23:59:59', NULL, 4, 3, '', NULL, 0),
(232, 'Oběd sobota', 2015, '85.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 3, '', NULL, 0),
(233, 'Večeře sobota', 2015, '85.00', 0, 0, '2015-07-16 23:59:59', NULL, 4, 3, '', NULL, 0),
(234, ' Snídaně neděle', 2015, '25.00', 0, 0, '2015-07-17 23:59:59', NULL, 4, 4, '', NULL, 0),
(235, 'Oběd neděle', 2015, '85.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 4, '', NULL, 0),
(236, 'Večeře neděle', 2015, '85.00', 0, 0, '2015-07-17 23:59:59', NULL, 4, 4, '', NULL, 0),
(237, 'Tričko zelené dámské L', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(238, 'Tričko zelené dámské M', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(239, 'Tričko zelené dámské S', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(240, 'Tričko zelené pánské L', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(241, 'Tričko zelené pánské M', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(242, 'Tričko zelené pánské S', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(243, 'Tričko zelené pánské XL', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(244, 'Tričko červené dámské L', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(245, 'Tričko červené dámské M', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(246, 'Tričko červené dámské S', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(247, 'Tričko červené pánské L', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(248, 'Tričko červené pánské M', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(249, 'Tričko červené pánské S', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(250, 'Tričko červené pánské XL', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(251, 'Tričko modré dámské L', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(252, 'Tričko modré dámské M', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(253, 'Tričko modré dámské S', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(254, 'Tričko modré pánské L', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(255, 'Tričko modré pánské M', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(256, 'Tričko modré pánské S', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(257, 'Tričko modré pánské XL', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(258, 'Spacák středa', 2015, '80.00', 0, 0, '2015-07-12 23:59:59', 140, 2, 0, 'Spacákovna se nachází vedle kuchyně, kde se v sobotu brzo od rána vaří a může kvůli tomu být hluk. Za tuto nepříjemnost se předem omlouváme, není ale v našich silách tomu zabránit.', NULL, 0),
(259, 'Spacák čtvrtek', 2015, '80.00', 0, 0, '2015-07-12 23:59:59', 140, 2, 1, '', NULL, 0),
(260, 'Spacák pátek', 2015, '80.00', 0, 0, '2015-07-12 23:59:59', 140, 2, 2, '', NULL, 0),
(261, 'Spacák sobota', 2015, '80.00', 0, 0, '2015-07-12 23:59:59', 140, 2, 3, '', NULL, 0),
(262, 'Spacák neděle', 2015, '80.00', 0, 0, '2015-07-12 23:59:59', 140, 2, 4, '', NULL, 0),
(263, 'Dvojlůžák středa', 2015, '240.00', 0, 0, '2015-07-12 23:59:59', 6, 2, 0, '', NULL, 0),
(264, 'Dvojlůžák čtvrtek', 2015, '240.00', 0, 0, '2015-07-12 23:59:59', 80, 2, 1, '', NULL, 0),
(265, 'Dvojlůžák pátek', 2015, '240.00', 0, 0, '2015-07-12 23:59:59', 80, 2, 2, '', NULL, 0),
(266, 'Dvojlůžák sobota', 2015, '240.00', 0, 0, '2015-07-12 23:59:59', 80, 2, 3, '', NULL, 0),
(267, 'Dvojlůžák neděle', 2015, '240.00', 0, 0, '2015-07-12 23:59:59', 4, 2, 4, '', NULL, 0),
(268, 'Trojlůžák středa', 2015, '210.00', 0, 0, '2015-07-12 23:59:59', 192, 2, 0, '', NULL, 0),
(269, 'Trojlůžák čtvrtek', 2015, '210.00', 0, 0, '2015-07-12 23:59:59', 192, 2, 1, '', NULL, 0),
(270, 'Trojlůžák pátek', 2015, '210.00', 0, 0, '2015-07-12 23:59:59', 192, 2, 2, '', NULL, 0),
(271, 'Trojlůžák sobota', 2015, '210.00', 0, 0, '2015-07-12 23:59:59', 192, 2, 3, '', NULL, 0),
(272, 'Trojlůžák neděle', 2015, '210.00', 0, 0, '2015-07-12 23:59:59', 192, 2, 4, '', NULL, 0),
(273, '3L garsonka středa', 2015, '270.00', 0, 0, '2015-07-12 23:59:59', 12, 2, 0, '', NULL, 0),
(274, '3L garsonka čtvrtek', 2015, '270.00', 0, 0, '2015-07-12 23:59:59', 12, 2, 1, '', NULL, 0),
(275, '3L garsonka pátek', 2015, '270.00', 0, 0, '2015-07-12 23:59:59', 12, 2, 2, '', NULL, 0),
(276, '3L garsonka sobota', 2015, '270.00', 0, 0, '2015-07-12 23:59:59', 12, 2, 3, '', NULL, 0),
(277, '3L garsonka neděle', 2015, '270.00', 0, 0, '2015-07-12 23:59:59', 12, 2, 4, '', NULL, 0),
(278, '2L na dvoupokojáku čtvrtek', 2015, '260.00', 0, 0, '2015-07-12 23:59:59', 10, 2, 1, 'dvoulůžkový pokoj v rámci dvou pokojů s sdíleným soc. zázemím a ledničkou (mini nezařízená kuchyňka)', NULL, 0),
(279, '2L na dvoupokojáku pátek', 2015, '260.00', 0, 0, '2015-07-12 23:59:59', 10, 2, 2, '', NULL, 0),
(280, '2L na dvoupokojáku sobota', 2015, '260.00', 0, 0, '2015-07-12 23:59:59', 10, 2, 3, '', NULL, 0),
(281, '3L na dvoupokojáku čtvrtek', 2015, '260.00', 0, 0, '2015-07-12 23:59:59', 9, 2, 1, 'trojlůžkový pokoj v rámci dvou pokojů s sdíleným soc. zázemím a ledničkou (mini nezařízená kuchyňka)', NULL, 0),
(282, '3L na dvoupokojáku pátek', 2015, '260.00', 0, 0, '2015-07-12 23:59:59', 9, 2, 2, '', NULL, 0),
(283, '3L na dvoupokojáku sobota', 2015, '260.00', 0, 0, '2015-07-12 23:59:59', 9, 2, 3, '', NULL, 0),
(284, 'Dobrovolné vstupné', 2015, '0.00', 0, 0, '2015-06-30 23:59:59', NULL, 5, NULL, '', NULL, 0),
(285, 'Dobrovolné vstupné (pozdě)', 2015, '0.00', 0, 0, NULL, NULL, 5, NULL, '', NULL, 0),
(286, 'Tílko zelené dámské L', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(287, 'Tílko zelené dámské M', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(288, 'Tílko zelené dámské S', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(289, 'Tílko červené dámské L', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(290, 'Tílko červené dámské M', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(291, 'Tílko červené dámské S', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(292, 'Tílko modré dámské L', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(293, 'Tílko modré dámské M', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(294, 'Tílko modré dámské S', 2015, '200.00', 0, 0, '2015-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(295, 'Dobrovolné vstupné (pozdě)', 2016, '0.00', 0, 0, NULL, NULL, 5, NULL, '', NULL, 0),
(296, 'Dobrovolné vstupné', 2016, '0.00', 0, 0, '2016-06-30 23:59:59', NULL, 5, NULL, '', NULL, 0),
(297, '3L na dvoupokojáku neděle', 2016, '280.00', 0, 0, '2016-07-17 23:59:59', 9, 2, 4, '', NULL, 0),
(298, '3L na dvoupokojáku sobota', 2016, '280.00', 0, 0, '2016-07-17 23:59:59', 9, 2, 3, '', NULL, 0),
(299, '3L na dvoupokojáku pátek', 2016, '280.00', 0, 0, '2016-07-17 23:59:59', 9, 2, 2, '', NULL, 0),
(300, '3L na dvoupokojáku čtvrtek', 2016, '280.00', 0, 0, '2016-07-17 23:59:59', 9, 2, 1, '', NULL, 0),
(301, '3L na dvoupokojáku středa', 2016, '280.00', 0, 0, '2016-07-17 23:59:59', 9, 2, 0, 'trojlůžkový pokoj v rámci dvou pokojů s sdíleným soc. zázemím a ledničkou (mini nezařízená kuchyňka)', NULL, 0),
(302, '2L na dvoupokojáku neděle', 2016, '280.00', 0, 0, '2016-07-17 23:59:59', 16, 2, 4, '', NULL, 0),
(303, '2L na dvoupokojáku sobota', 2016, '280.00', 0, 0, '2016-07-17 23:59:59', 16, 2, 3, '', NULL, 0),
(304, '2L na dvoupokojáku pátek', 2016, '280.00', 0, 0, '2016-07-17 23:59:59', 16, 2, 2, '', NULL, 0),
(305, '2L na dvoupokojáku čtvrtek', 2016, '280.00', 0, 0, '2016-07-17 23:59:59', 16, 2, 1, '', NULL, 0),
(306, '2L na dvoupokojáku středa', 2016, '280.00', 0, 0, '2016-07-17 23:59:59', 16, 2, 0, 'dvoulůžkový pokoj v rámci dvou pokojů s sdíleným soc. zázemím a ledničkou (mini nezařízená kuchyňka)', NULL, 0),
(307, '3L garsonka neděle', 2016, '300.00', 0, 0, '2016-07-17 23:59:59', 0, 2, 4, '', NULL, 0),
(308, '3L garsonka sobota', 2016, '300.00', 0, 0, '2016-07-17 23:59:59', 0, 2, 3, '', NULL, 0),
(309, '3L garsonka pátek', 2016, '300.00', 0, 0, '2016-07-17 23:59:59', 0, 2, 2, '', NULL, 0),
(310, '3L garsonka čtvrtek', 2016, '300.00', 0, 0, '2016-07-17 23:59:59', 0, 2, 1, '', NULL, 0),
(311, '3L garsonka středa', 2016, '300.00', 0, 0, '2016-07-17 23:59:59', 0, 2, 0, '', NULL, 0),
(312, 'Trojlůžák neděle', 2016, '210.00', 0, 0, '2016-07-17 23:59:59', 999, 2, 4, '', NULL, 0),
(313, 'Trojlůžák sobota', 2016, '210.00', 0, 0, '2016-07-17 23:59:59', 999, 2, 3, '', NULL, 0),
(314, 'Trojlůžák pátek', 2016, '210.00', 0, 0, '2016-07-17 23:59:59', 999, 2, 2, '', NULL, 0),
(315, 'Trojlůžák čtvrtek', 2016, '210.00', 0, 0, '2016-07-17 23:59:59', 999, 2, 1, 'Trojlůžkové pokoje se nachází v budově naproti kulturního domu Dukla (ve kterém je například deskoherna). Počítejte ale prosím s tím, že na této budově probíhá letos rekonstrukce kuchyně a jídelny a nelze tak zaručit, že v budově nebude přes den žádný ruch.', NULL, 0),
(316, 'Trojlůžák středa', 2016, '210.00', 0, 0, '2016-07-17 23:59:59', 999, 2, 0, 'Trojlůžkové pokoje se nachází v budově naproti kulturního domu Dukla (ve kterém je například deskoherna). Počítejte ale prosím s tím, že na této budově probíhá letos rekonstrukce kuchyně a jídelny a nelze tak zaručit, že v budově nebude přes den žádný ruch.', NULL, 0),
(317, 'Dvojlůžák neděle', 2016, '240.00', 0, 0, '2016-07-17 23:59:59', 999, 2, 4, '', NULL, 0),
(318, 'Dvojlůžák sobota', 2016, '240.00', 0, 0, '2016-07-17 23:59:59', 999, 2, 3, '', NULL, 0),
(319, 'Dvojlůžák pátek', 2016, '240.00', 0, 0, '2016-07-17 23:59:59', 999, 2, 2, '', NULL, 0),
(320, 'Dvojlůžák čtvrtek', 2016, '240.00', 0, 0, '2016-07-17 23:59:59', 999, 2, 1, '', NULL, 0),
(321, 'Dvojlůžák středa', 2016, '240.00', 0, 0, '2016-07-17 23:59:59', 999, 2, 0, '', NULL, 0),
(322, 'Spacák neděle', 2016, '90.00', 0, 0, '2016-07-17 23:59:59', 140, 2, 4, '', NULL, 0),
(323, 'Spacák sobota', 2016, '90.00', 0, 0, '2016-07-17 23:59:59', 140, 2, 3, '', NULL, 0),
(324, 'Spacák pátek', 2016, '90.00', 0, 0, '2016-07-17 23:59:59', 140, 2, 2, '', NULL, 0),
(325, 'Spacák čtvrtek', 2016, '90.00', 0, 0, '2016-07-17 23:59:59', 140, 2, 1, '', NULL, 0),
(326, 'Spacák středa', 2016, '90.00', 0, 0, '2016-07-17 23:59:59', 140, 2, 0, 'Spaní ve spacáku bude letos externě v tělocvičně Základní školy Staňkova (hned vedle kulturního domu Dukla, kde je například deskoherna). Do tělocvičny bude umožněn přístup pouze po registraci s odpovídající účastnickou páskou. Nenechávejte v tělocvičně bez dohledu žádné své věci - jejich úschova bude možná na označeném místě.', NULL, 0),
(327, 'Tričko modré pánské XL', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(328, 'Tričko modré pánské S', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(329, 'Tričko modré pánské M', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(330, 'Tričko modré pánské L', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(331, 'Tričko modré dámské S', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(332, 'Tričko modré dámské M', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(333, 'Tričko modré dámské L', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(334, 'Tričko červené pánské XL', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(335, 'Tričko červené pánské S', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(336, 'Tričko červené pánské M', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(337, 'Tričko červené pánské L', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(338, 'Tričko červené dámské S', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(339, 'Tričko červené dámské M', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(340, 'Tričko červené dámské L', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(341, 'Tričko účastnické pánské XL', 2016, '200.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(342, 'Tričko účastnické pánské S', 2016, '200.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(343, 'Tričko účastnické pánské M', 2016, '200.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(344, 'Tričko účastnické pánské L', 2016, '200.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(345, 'Tričko účastnické dámské S', 2016, '200.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(346, 'Tričko účastnické dámské M', 2016, '200.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(347, 'Tričko účastnické dámské L', 2016, '200.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(348, 'Večeře neděle', 2016, '85.00', 0, 0, '2016-07-20 23:59:59', NULL, 4, 4, '', NULL, 0),
(349, 'Oběd neděle', 2016, '85.00', 0, 1, '2022-05-21 11:05:14', NULL, 4, 4, '', NULL, 0),
(350, ' Snídaně neděle', 2016, '35.00', 0, 1, '2016-07-20 23:59:59', NULL, 4, 4, '', NULL, 0),
(351, 'Večeře sobota', 2016, '85.00', 0, 1, '2016-07-20 23:59:59', NULL, 4, 3, '', NULL, 0),
(352, 'Oběd sobota', 2016, '85.00', 0, 1, '2022-05-21 11:05:14', NULL, 4, 3, '', NULL, 0),
(353, ' Snídaně sobota', 2016, '35.00', 0, 1, '2016-07-20 23:59:59', NULL, 4, 3, '', NULL, 0),
(354, 'Večeře pátek', 2016, '85.00', 0, 1, '2016-07-20 23:59:59', NULL, 4, 2, '', NULL, 0),
(355, 'Oběd pátek', 2016, '85.00', 0, 1, '2022-05-21 11:05:14', NULL, 4, 2, '', NULL, 0),
(356, ' Snídaně pátek', 2016, '35.00', 0, 1, '2016-07-20 23:59:59', NULL, 4, 2, '', NULL, 0),
(357, 'Večeře čtvrtek', 2016, '85.00', 0, 1, '2016-07-19 23:59:59', NULL, 4, 1, '', NULL, 0),
(358, 'Oběd čtvrtek', 2016, '85.00', 0, 1, '2022-05-21 11:05:14', NULL, 4, 1, '', NULL, 0),
(359, 'Placka', 2016, '15.00', 0, 1, '2016-06-30 23:59:59', 350, 1, NULL, '', 1, 0),
(360, 'Kostka', 2016, '25.00', 0, 0, '2018-07-17 23:59:59', 534, 1, NULL, '', 2, 0),
(361, 'Tílko modré dámské S', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(362, 'Tílko modré dámské M', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(363, 'Tílko modré dámské L', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(364, 'Tílko červené dámské S', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(365, 'Tílko červené dámské M', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(366, 'Tílko červené dámské L', 2016, '150.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(367, 'Tílko účastnické dámské S', 2016, '200.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(368, 'Tílko účastnické dámské M', 2016, '200.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(369, 'Tílko účastnické dámské L', 2016, '200.00', 0, 0, '2016-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(370, 'Parcon', 2017, '150.00', 0, 0, NULL, NULL, 6, NULL, '', NULL, 0),
(371, 'Placka', 2017, '15.00', 0, 1, '2017-07-18 23:59:59', 350, 1, NULL, '', 1, 0),
(372, 'Kostka', 2017, '25.00', 0, 0, '2018-07-17 23:59:59', 547, 1, NULL, '', 2, 0),
(373, 'Placka Parcon', 2017, '15.00', 0, 0, '2017-06-30 23:59:59', NULL, 1, NULL, '', 1, 0),
(374, '3L na dvoupokojáku neděle', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 4, '', NULL, 0),
(375, '3L na dvoupokojáku sobota', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 3, '', NULL, 0),
(376, '3L na dvoupokojáku pátek', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 2, '', NULL, 0),
(377, '3L na dvoupokojáku čtvrtek', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 1, '', NULL, 0),
(378, '3L na dvoupokojáku středa', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 0, '', NULL, 0),
(379, '2L na dvoupokojáku neděle', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 4, '', NULL, 0),
(380, '2L na dvoupokojáku sobota', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 3, '', NULL, 0),
(381, '2L na dvoupokojáku pátek', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 2, '', NULL, 0),
(382, '2L na dvoupokojáku čtvrtek', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 1, '', NULL, 0),
(383, '2L na dvoupokojáku středa', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 0, '', NULL, 0),
(384, '3L garsonka neděle', 2017, '300.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 4, '', NULL, 0),
(385, '3L garsonka sobota', 2017, '300.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 3, '', NULL, 0),
(386, '3L garsonka pátek', 2017, '300.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 2, '', NULL, 0),
(387, '3L garsonka čtvrtek', 2017, '300.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 1, '', NULL, 0),
(388, '3L garsonka středa', 2017, '300.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 0, '', NULL, 0),
(389, '2L garsonka neděle', 2017, '300.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 4, '', NULL, 0),
(390, '2L garsonka sobota', 2017, '300.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 3, '', NULL, 0),
(391, '2L garsonka pátek', 2017, '300.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 2, '', NULL, 0),
(392, '2L garsonka čtvrtek', 2017, '300.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 1, '', NULL, 0),
(393, '2L garsonka středa', 2017, '300.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 0, '', NULL, 0),
(394, 'Trojlůžák neděle', 2017, '210.00', 0, 0, '2017-07-16 23:59:59', 231, 2, 4, '', NULL, 0),
(395, 'Trojlůžák sobota', 2017, '210.00', 0, 0, '2017-07-16 23:59:59', 281, 2, 3, '', NULL, 0),
(396, 'Trojlůžák pátek', 2017, '210.00', 0, 0, '2017-07-16 23:59:59', 281, 2, 2, '', NULL, 0),
(397, 'Trojlůžák čtvrtek', 2017, '210.00', 0, 0, '2017-07-16 23:59:59', 231, 2, 1, '', NULL, 0),
(398, 'Trojlůžák středa', 2017, '210.00', 0, 0, '2017-07-16 23:59:59', 231, 2, 0, '', NULL, 0),
(399, 'Dvojlůžák neděle', 2017, '240.00', 0, 0, '2017-07-16 23:59:59', 170, 2, 4, '', NULL, 0),
(400, 'Dvojlůžák sobota', 2017, '240.00', 0, 0, '2017-07-16 23:59:59', 220, 2, 3, '', NULL, 0),
(401, 'Dvojlůžák pátek', 2017, '240.00', 0, 0, '2017-07-16 23:59:59', 220, 2, 2, '', NULL, 0),
(402, 'Dvojlůžák čtvrtek', 2017, '240.00', 0, 0, '2017-07-16 23:59:59', 170, 2, 1, '', NULL, 0),
(403, 'Dvojlůžák středa', 2017, '240.00', 0, 0, '2017-07-16 23:59:59', 170, 2, 0, '', NULL, 0),
(404, 'Jednolůžák neděle', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 11, 2, 4, '', NULL, 0),
(405, 'Jednolůžák sobota', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 11, 2, 3, '', NULL, 0),
(406, 'Jednolůžák pátek', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 11, 2, 2, '', NULL, 0),
(407, 'Jednolůžák čtvrtek', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 9, 2, 1, '', NULL, 0),
(408, 'Jednolůžák středa', 2017, '280.00', 0, 0, '2017-07-16 23:59:59', 5, 2, 0, '', NULL, 0),
(409, 'Spacák neděle', 2017, '90.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 4, '', NULL, 0),
(410, 'Spacák sobota', 2017, '90.00', 0, 0, '2017-07-16 23:59:59', 200, 2, 3, '', NULL, 0),
(411, 'Spacák pátek', 2017, '90.00', 0, 0, '2017-07-16 23:59:59', 200, 2, 2, '', NULL, 0),
(412, 'Spacák čtvrtek', 2017, '90.00', 0, 0, '2017-07-16 23:59:59', 200, 2, 1, 'Spaní ve spacáku bude opět externě v tělocvičně Základní školy Staňkova (hned vedle kulturního domu Dukla, kde je například deskoherna). Do tělocvičny bude umožněn přístup pouze po registraci s odpovídající účastnickou páskou. Nenechávejte v tělocvičně bez dohledu žádné své věci - jejich úschova bude možná na označeném místě.', NULL, 0),
(413, 'Spacák středa', 2017, '90.00', 0, 0, '2017-07-16 23:59:59', 0, 2, 0, 'Spaní ve spacáku bude opět externě v tělocvičně Základní školy Staňkova (hned vedle kulturního domu Dukla, kde je například deskoherna). Do tělocvičny bude umožněn přístup pouze po registraci s odpovídající účastnickou páskou. Nenechávejte v tělocvičně bez dohledu žádné své věci - jejich úschova bude možná na označeném místě.', NULL, 0),
(414, 'Tričko modré pánské XXL', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(415, 'Tričko modré pánské XL', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(416, 'Tričko modré pánské S', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(417, 'Tričko modré pánské M', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(418, 'Tričko modré pánské L', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(419, 'Tričko modré dámské S', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(420, 'Tričko modré dámské M', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(421, 'Tričko modré dámské L', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(422, 'Tričko modré dámské XL', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(423, 'Tričko červené pánské XXL', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(424, 'Tričko červené pánské XL', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(425, 'Tričko červené pánské S', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(426, 'Tričko červené pánské M', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(427, 'Tričko červené pánské L', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(428, 'Tričko červené dámské S', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(429, 'Tričko červené dámské M', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(430, 'Tričko červené dámské L', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(431, 'Tričko červené dámské XL', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(432, 'Tričko účastnické pánské XXL', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(433, 'Tričko účastnické pánské XL', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(434, 'Tričko účastnické pánské S', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(435, 'Tričko účastnické pánské M', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(436, 'Tričko účastnické pánské L', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(437, 'Tričko účastnické dámské S', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(438, 'Tričko účastnické dámské M', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(439, 'Tričko účastnické dámské L', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(440, 'Tričko účastnické dámské XL', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(441, 'Tílko modré dámské S', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(442, 'Tílko modré dámské M', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(443, 'Tílko modré dámské L', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(444, 'Tílko modré dámské XL', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(445, 'Tílko červené dámské S', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(446, 'Tílko červené dámské M', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(447, 'Tílko červené dámské L', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(448, 'Tílko červené dámské XL', 2017, '150.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(449, 'Tílko účastnické dámské S', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(450, 'Tílko účastnické dámské M', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(451, 'Tílko účastnické dámské L', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(452, 'Tílko účastnické dámské XL', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(453, 'Tričko Parcon žluté S', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(454, 'Tričko Parcon žluté M', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(455, 'Tričko Parcon žluté L', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(456, 'Tričko Parcon žluté XL', 2017, '200.00', 0, 0, '2017-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(457, 'Večeře neděle', 2017, '85.00', 0, 0, '2017-07-16 23:59:59', NULL, 4, 4, '', NULL, 0),
(458, 'Oběd neděle', 2017, '85.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 4, '', NULL, 0),
(459, ' Snídaně neděle', 2017, '35.00', 0, 0, '2017-07-16 23:59:59', NULL, 4, 4, '', NULL, 0),
(460, 'Večeře sobota', 2017, '85.00', 0, 0, '2017-07-16 23:59:59', NULL, 4, 3, '', NULL, 0),
(461, 'Oběd sobota', 2017, '85.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 3, '', NULL, 0),
(462, ' Snídaně sobota', 2017, '35.00', 0, 0, '2017-07-16 23:59:59', NULL, 4, 3, '', NULL, 0),
(463, 'Večeře pátek', 2017, '85.00', 0, 0, '2017-07-16 23:59:59', NULL, 4, 2, '', NULL, 0),
(464, 'Oběd pátek', 2017, '85.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 2, '', NULL, 0),
(465, ' Snídaně pátek', 2017, '35.00', 0, 0, '2017-07-16 23:59:59', NULL, 4, 2, '', NULL, 0),
(466, 'Večeře čtvrtek', 2017, '85.00', 0, 0, '2017-07-16 23:59:59', NULL, 4, 1, '', NULL, 0),
(467, 'Oběd čtvrtek', 2017, '85.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 1, '', NULL, 0),
(468, 'Dobrovolné vstupné (pozdě)', 2017, '0.00', 0, 0, NULL, NULL, 5, NULL, '', NULL, 0),
(469, 'Dobrovolné vstupné', 2017, '0.00', 0, 0, '2017-06-30 23:59:59', NULL, 5, NULL, '', NULL, 0),
(470, 'Hrnek 2017', 2017, '175.00', 0, 0, '2017-06-30 23:59:59', 40, 1, NULL, '', NULL, 0),
(471, 'Kostka', 2018, '25.00', 0, 0, '2021-07-13 23:59:00', 50, 1, NULL, 'western', 2, 0),
(472, 'Placka', 2018, '15.00', 0, 1, '2018-07-17 23:59:59', 500, 1, NULL, '', 1, 0),
(473, 'Trojlůžák (C) neděle', 2018, '210.00', 0, 0, '2018-07-15 23:59:59', 228, 2, 4, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(474, 'Trojlůžák (C) sobota', 2018, '210.00', 0, 0, '2018-07-15 23:59:59', 228, 2, 3, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(475, 'Trojlůžák (C) pátek', 2018, '210.00', 0, 0, '2018-07-15 23:59:59', 228, 2, 2, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(476, 'Trojlůžák (C) čtvrtek', 2018, '210.00', 0, 0, '2018-07-15 23:59:59', 228, 2, 1, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(477, 'Trojlůžák (C) středa', 2018, '210.00', 0, 0, '2018-07-15 23:59:59', 228, 2, 0, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(478, 'Dvojlůžák (15min od GC) neděle', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 0, 2, 4, 'Část ubytovacích kapacit letošního GC je na kolejích Pardubice, cca <a href=\"https://mapy.cz/s/2Cbvm\" target=\"_blank\">15min autobusem</a> od GC. Více o letošním ubytování se dočtete na našem <a href=\"https://gamecon.cz/blog/novinky-2018\" target=\"_blank\">blogu</a>.', NULL, 0),
(479, 'Dvojlůžák (15min od GC) sobota', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 150, 2, 3, 'Část ubytovacích kapacit letošního GC je na kolejích Pardubice, cca <a href=\"https://mapy.cz/s/2Cbvm\" target=\"_blank\">15min autobusem</a> od GC. Více o letošním ubytování se dočtete na našem <a href=\"https://gamecon.cz/blog/novinky-2018\" target=\"_blank\">blogu</a>.', NULL, 0),
(480, 'Dvojlůžák (15min od GC) pátek', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 150, 2, 2, 'Část ubytovacích kapacit letošního GC je na kolejích Pardubice, cca <a href=\"https://mapy.cz/s/2Cbvm\" target=\"_blank\">15min autobusem</a> od GC. Více o letošním ubytování se dočtete na našem <a href=\"https://gamecon.cz/blog/novinky-2018\" target=\"_blank\">blogu</a>.', NULL, 0),
(481, 'Dvojlůžák (15min od GC) čtvrtek', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 150, 2, 1, 'Část ubytovacích kapacit letošního GC je na kolejích Pardubice, cca <a href=\"https://mapy.cz/s/2Cbvm\" target=\"_blank\">15min autobusem</a> od GC. Více o letošním ubytování se dočtete na našem <a href=\"https://gamecon.cz/blog/novinky-2018\" target=\"_blank\">blogu</a>.', NULL, 0),
(482, 'Dvojlůžák (15min od GC) středa', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 0, 2, 0, 'Část ubytovacích kapacit letošního GC je na kolejích Pardubice, cca <a href=\"https://mapy.cz/s/2Cbvm\" target=\"_blank\">15min autobusem</a> od GC. Více o letošním ubytování se dočtete na našem <a href=\"https://gamecon.cz/blog/novinky-2018\" target=\"_blank\">blogu</a>.', NULL, 0),
(483, 'Jednolůžák (C) neděle', 2018, '280.00', 0, 0, '2018-07-15 23:59:59', 13, 2, 4, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(484, 'Jednolůžák (C) sobota', 2018, '280.00', 0, 0, '2018-07-15 23:59:59', 13, 2, 3, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(485, 'Jednolůžák (C) pátek', 2018, '280.00', 0, 0, '2018-07-15 23:59:59', 13, 2, 2, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(486, 'Jednolůžák (C) čtvrtek', 2018, '280.00', 0, 0, '2018-07-15 23:59:59', 13, 2, 1, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(487, 'Jednolůžák (C) středa', 2018, '280.00', 0, 0, '2018-07-15 23:59:59', 13, 2, 0, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(488, 'Spacák neděle', 2018, '90.00', 0, 0, '2018-07-15 23:59:59', 0, 2, 4, '', NULL, 0),
(489, 'Spacák sobota', 2018, '90.00', 0, 0, '2018-07-15 23:59:59', 100, 2, 3, 'Spaní ve spacáku bude v tělocvičně ZŠ Waldorfská (350 metrů od GC). Do tělocvičny bude umožněn přístup pouze po registraci s odpovídající účastnickou páskou. Nenechávejte v tělocvičně bez dohledu žádné cenné věci - jejich úschova bude možná na označeném místě.', NULL, 0),
(490, 'Spacák pátek', 2018, '90.00', 0, 0, '2018-07-15 23:59:59', 100, 2, 2, 'Spaní ve spacáku bude v tělocvičně ZŠ Waldorfská (350 metrů od GC). Do tělocvičny bude umožněn přístup pouze po registraci s odpovídající účastnickou páskou. Nenechávejte v tělocvičně bez dohledu žádné cenné věci - jejich úschova bude možná na označeném místě.', NULL, 0),
(491, 'Spacák čtvrtek', 2018, '90.00', 0, 0, '2018-07-15 23:59:59', 100, 2, 1, 'Spaní ve spacáku bude v tělocvičně ZŠ Waldorfská (350 metrů od GC). Do tělocvičny bude umožněn přístup pouze po registraci s odpovídající účastnickou páskou. Nenechávejte v tělocvičně bez dohledu žádné cenné věci - jejich úschova bude možná na označeném místě.', NULL, 0),
(492, 'Spacák středa', 2018, '90.00', 0, 0, '2018-07-15 23:59:59', 0, 2, 0, '', NULL, 0),
(493, 'Tričko modré pánské XXL', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(494, 'Tričko modré pánské XL', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(495, 'Tričko modré pánské S', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(496, 'Tričko modré pánské M', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1);
INSERT INTO `shop_predmety` (`id_predmetu`, `nazev`, `model_rok`, `cena_aktualni`, `stav`, `auto`, `nabizet_do`, `kusu_vyrobeno`, `typ`, `ubytovani_den`, `popis`, `kategorie_predmetu`, `se_slevou`) VALUES
(497, 'Tričko modré pánské L', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(498, 'Tričko modré dámské S', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(499, 'Tričko modré dámské M', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(500, 'Tričko modré dámské L', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(501, 'Tričko modré dámské XL', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(502, 'Tričko červené pánské XXL', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(503, 'Tričko červené pánské XL', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(504, 'Tričko červené pánské S', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(505, 'Tričko červené pánské M', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(506, 'Tričko červené pánské L', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(507, 'Tričko červené dámské S', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(508, 'Tričko červené dámské M', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(509, 'Tričko červené dámské L', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(510, 'Tričko červené dámské XL', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(511, 'Tričko účastnické pánské XXL', 2018, '200.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(512, 'Tričko účastnické pánské XL', 2018, '200.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(513, 'Tričko účastnické pánské S', 2018, '200.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(514, 'Tričko účastnické pánské M', 2018, '200.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(515, 'Tričko účastnické pánské L', 2018, '200.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(516, 'Tričko účastnické dámské S', 2018, '200.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(517, 'Tričko účastnické dámské M', 2018, '200.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(518, 'Tričko účastnické dámské L', 2018, '200.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(519, 'Tričko účastnické dámské XL', 2018, '200.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(520, 'Tílko modré dámské S', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(521, 'Tílko modré dámské M', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(522, 'Tílko modré dámské L', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(523, 'Tílko modré dámské XL', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(524, 'Tílko červené dámské S', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(525, 'Tílko červené dámské M', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(526, 'Tílko červené dámské L', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(527, 'Tílko červené dámské XL', 2018, '150.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(528, 'Tílko účastnické dámské S', 2018, '200.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(529, 'Tílko účastnické dámské M', 2018, '200.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(530, 'Tílko účastnické dámské L', 2018, '200.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(531, 'Tílko účastnické dámské XL', 2018, '200.00', 0, 0, '2018-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(532, 'Večeře neděle', 2018, '85.00', 0, 0, '2018-07-15 23:59:59', NULL, 4, 4, '', NULL, 0),
(533, 'Oběd neděle', 2018, '85.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 4, '', NULL, 0),
(534, ' Snídaně neděle', 2018, '35.00', 0, 0, '2018-07-15 23:59:59', NULL, 4, 4, '', NULL, 0),
(535, 'Večeře sobota', 2018, '85.00', 0, 0, '2018-07-15 23:59:59', NULL, 4, 3, '', NULL, 0),
(536, 'Oběd sobota', 2018, '85.00', 0, 0, '2022-05-21 11:05:14', 98, 4, 3, '', NULL, 0),
(537, ' Snídaně sobota', 2018, '35.00', 0, 0, '2018-07-15 23:59:59', NULL, 4, 3, '', NULL, 0),
(538, 'Večeře pátek', 2018, '85.00', 0, 0, '2018-07-15 23:59:59', NULL, 4, 2, '', NULL, 0),
(539, 'Oběd pátek', 2018, '85.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 2, '', NULL, 0),
(540, ' Snídaně pátek', 2018, '35.00', 0, 0, '2018-07-15 23:59:59', NULL, 4, 2, '', NULL, 0),
(541, 'Večeře čtvrtek', 2018, '85.00', 0, 0, '2018-07-15 23:59:59', NULL, 4, 1, '', NULL, 0),
(542, 'Oběd čtvrtek', 2018, '85.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 1, '', NULL, 0),
(543, 'Dobrovolné vstupné (pozdě)', 2018, '0.00', 0, 0, NULL, NULL, 5, NULL, '', NULL, 0),
(544, 'Dobrovolné vstupné', 2018, '0.00', 0, 0, '2018-06-30 23:59:59', NULL, 5, NULL, '', NULL, 0),
(549, 'Dvojlůžák (A) středa', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 102, 2, 0, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(550, 'Dvojlůžák (A) čtvrtek', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 102, 2, 1, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(551, 'Dvojlůžák (A) pátek', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 102, 2, 2, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(552, 'Dvojlůžák (A) sobota', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 102, 2, 3, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(553, 'Dvojlůžák (A) neděle', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 102, 2, 4, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(554, 'Dvojlůžák (C) středa', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 8, 2, 0, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(555, 'Dvojlůžák (C) čtvrtek', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 8, 2, 1, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(556, 'Dvojlůžák (C) pátek', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 8, 2, 2, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(557, 'Dvojlůžák (C) sobota', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 8, 2, 3, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(558, 'Dvojlůžák (C) neděle', 2018, '250.00', 0, 0, '2018-07-15 23:59:59', 8, 2, 4, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(561, 'Trojlůžák (A) neděle', 2018, '210.00', 0, 0, '2018-07-15 23:59:59', 36, 2, 4, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(562, 'Trojlůžák (A) sobota', 2018, '210.00', 0, 0, '2018-07-15 23:59:59', 36, 2, 3, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(563, 'Trojlůžák (A) pátek', 2018, '210.00', 0, 0, '2018-07-15 23:59:59', 36, 2, 2, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(564, 'Trojlůžák (A) čtvrtek', 2018, '210.00', 0, 0, '2018-07-15 23:59:59', 36, 2, 1, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(565, 'Trojlůžák (A) středa', 2018, '210.00', 0, 0, '2018-07-15 23:59:59', 36, 2, 0, 'Písmena (A) a (C) v popisu je označení budov na místě. Budovy jsou vzdálené od sebe cca 30m, standard pokojů je stejný. Rozdělení slouží pouze pro snažší administrativu.', NULL, 0),
(568, 'Kostka', 2019, '25.00', 0, 1, '2019-07-16 23:59:59', 550, 1, NULL, '', 2, 0),
(569, 'Placka', 2019, '15.00', 0, 1, '2019-07-16 23:59:59', 450, 1, NULL, '', 1, 0),
(570, 'Batoh', 2019, '450.00', 0, 0, '2019-06-27 23:59:59', NULL, 1, NULL, '', NULL, 0),
(571, 'Nicknack', 2019, '60.00', 0, 0, '2021-07-13 23:59:00', NULL, 1, NULL, 'GC', 6, 0),
(572, 'Trojlůžák neděle', 2019, '210.00', 0, 0, '2019-07-14 23:59:59', 297, 2, 4, '', NULL, 0),
(573, 'Trojlůžák sobota', 2019, '210.00', 0, 0, '2019-07-14 23:59:59', 297, 2, 3, '', NULL, 0),
(574, 'Trojlůžák pátek', 2019, '210.00', 0, 0, '2019-07-14 23:59:59', 297, 2, 2, '', NULL, 0),
(575, 'Trojlůžák čtvrtek', 2019, '210.00', 0, 0, '2019-07-14 23:59:59', 297, 2, 1, '', NULL, 0),
(576, 'Trojlůžák středa', 2019, '210.00', 0, 0, '2019-07-14 23:59:59', 297, 2, 0, '', NULL, 0),
(577, 'Dvojlůžák neděle', 2019, '250.00', 0, 0, '2019-07-14 23:59:59', 296, 2, 4, '', NULL, 0),
(578, 'Dvojlůžák sobota', 2019, '250.00', 0, 0, '2019-07-14 23:59:59', 296, 2, 3, '', NULL, 0),
(579, 'Dvojlůžák pátek', 2019, '250.00', 0, 0, '2019-07-14 23:59:59', 296, 2, 2, '', NULL, 0),
(580, 'Dvojlůžák čtvrtek', 2019, '250.00', 0, 0, '2019-07-14 23:59:59', 296, 2, 1, '', NULL, 0),
(581, 'Dvojlůžák středa', 2019, '250.00', 0, 0, '2019-07-14 23:59:59', 296, 2, 0, '', NULL, 0),
(582, 'Jednolůžák neděle', 2019, '300.00', 0, 0, '2019-07-14 23:59:59', 13, 2, 4, '', NULL, 0),
(583, 'Jednolůžák sobota', 2019, '300.00', 0, 0, '2019-07-14 23:59:59', 13, 2, 3, '', NULL, 0),
(584, 'Jednolůžák pátek', 2019, '300.00', 0, 0, '2019-07-14 23:59:59', 13, 2, 2, '', NULL, 0),
(585, 'Jednolůžák čtvrtek', 2019, '300.00', 0, 0, '2019-07-14 23:59:59', 13, 2, 1, '', NULL, 0),
(586, 'Jednolůžák středa', 2019, '300.00', 0, 0, '2019-07-14 23:59:59', 13, 2, 0, '', NULL, 0),
(587, 'Spacák neděle', 2019, '90.00', 0, 0, '2019-07-14 23:59:59', 80, 2, 4, 'Spaní ve spacáku bude v několika vyhrazených místnostech v budovách A, B, C. Vstup bude umožněn pouze po registraci s odpovídající účastnickou páskou. Nenechávejte v místnostech bez dohledu žádné cenné věci - jejich úschova je možná ve skříňkách (zámek bude zapůjčen oproti kauci 500 Kč).', NULL, 0),
(588, 'Spacák sobota', 2019, '90.00', 0, 0, '2019-07-14 23:59:59', 80, 2, 3, 'Spaní ve spacáku bude v několika vyhrazených místnostech v budovách A, B, C. Vstup bude umožněn pouze po registraci s odpovídající účastnickou páskou. Nenechávejte v místnostech bez dohledu žádné cenné věci - jejich úschova je možná ve skříňkách (zámek bude zapůjčen oproti kauci 500 Kč).', NULL, 0),
(589, 'Spacák pátek', 2019, '90.00', 0, 0, '2019-07-14 23:59:59', 80, 2, 2, 'Spaní ve spacáku bude v několika vyhrazených místnostech v budovách A, B, C. Vstup bude umožněn pouze po registraci s odpovídající účastnickou páskou. Nenechávejte v místnostech bez dohledu žádné cenné věci - jejich úschova je možná ve skříňkách (zámek bude zapůjčen oproti kauci 500 Kč).', NULL, 0),
(590, 'Spacák čtvrtek', 2019, '90.00', 0, 0, '2019-07-14 23:59:59', 80, 2, 1, 'Spaní ve spacáku bude v několika vyhrazených místnostech v budovách A, B, C. Vstup bude umožněn pouze po registraci s odpovídající účastnickou páskou. Nenechávejte v místnostech bez dohledu žádné cenné věci - jejich úschova je možná ve skříňkách (zámek bude zapůjčen oproti kauci 500 Kč).', NULL, 0),
(591, 'Spacák středa', 2019, '90.00', 0, 0, '2019-07-14 23:59:59', 80, 2, 0, 'Spaní ve spacáku bude v několika vyhrazených místnostech v budovách A, B, C. Vstup bude umožněn pouze po registraci s odpovídající účastnickou páskou. Nenechávejte v místnostech bez dohledu žádné cenné věci - jejich úschova je možná ve skříňkách (zámek bude zapůjčen oproti kauci 500 Kč).', NULL, 0),
(592, 'Tričko modré pánské XXL', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(593, 'Tričko modré pánské XL', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(594, 'Tričko modré pánské S', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(595, 'Tričko modré pánské M', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(596, 'Tričko modré pánské L', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(597, 'Tričko modré dámské S', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(598, 'Tričko modré dámské M', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(599, 'Tričko modré dámské L', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(600, 'Tričko modré dámské XL', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(601, 'Tričko červené pánské XXL', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(602, 'Tričko červené pánské XL', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(603, 'Tričko červené pánské S', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(604, 'Tričko červené pánské M', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(605, 'Tričko červené pánské L', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(606, 'Tričko červené dámské S', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(607, 'Tričko červené dámské M', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(608, 'Tričko červené dámské L', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(609, 'Tričko červené dámské XL', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 1),
(610, 'Tričko účastnické černé pánské XXL', 2019, '200.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(611, 'Tričko účastnické černé pánské XL', 2019, '200.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(612, 'Tričko účastnické černé pánské S', 2019, '200.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(613, 'Tričko účastnické černé pánské M', 2019, '200.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(614, 'Tričko účastnické černé pánské L', 2019, '200.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(615, 'Tričko účastnické černé dámské S', 2019, '200.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(616, 'Tričko účastnické černé dámské M', 2019, '200.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(617, 'Tričko účastnické černé dámské L', 2019, '200.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(618, 'Tričko účastnické černé dámské XL', 2019, '200.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 3, 0),
(619, 'Tílko modré dámské S', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(620, 'Tílko modré dámské M', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(621, 'Tílko modré dámské L', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(622, 'Tílko modré dámské XL', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(623, 'Tílko červené dámské S', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(624, 'Tílko červené dámské M', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(625, 'Tílko červené dámské L', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(626, 'Tílko červené dámské XL', 2019, '150.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 4, 1),
(627, 'Tílko účastnické černé dámské S', 2019, '200.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(628, 'Tílko účastnické černé dámské M', 2019, '200.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(629, 'Tílko účastnické černé dámské L', 2019, '200.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(630, 'Tílko účastnické černé dámské XL', 2019, '200.00', 0, 0, '2019-06-30 23:59:59', NULL, 3, NULL, '', 4, 0),
(631, 'Večeře neděle', 2019, '90.00', 0, 0, '2019-07-14 23:59:59', NULL, 4, 4, '', NULL, 0),
(632, 'Oběd neděle', 2019, '90.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 4, '', NULL, 0),
(633, ' Snídaně neděle', 2019, '35.00', 0, 0, '2019-07-14 23:59:59', NULL, 4, 4, '', NULL, 0),
(634, 'Večeře sobota', 2019, '90.00', 0, 0, '2019-07-14 23:59:59', NULL, 4, 3, '', NULL, 0),
(635, 'Oběd sobota', 2019, '90.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 3, '', NULL, 0),
(636, ' Snídaně sobota', 2019, '35.00', 0, 0, '2019-07-14 23:59:59', NULL, 4, 3, '', NULL, 0),
(637, 'Večeře pátek', 2019, '90.00', 0, 0, '2019-07-14 23:59:59', NULL, 4, 2, '', NULL, 0),
(638, 'Oběd pátek', 2019, '90.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 2, '', NULL, 0),
(639, ' Snídaně pátek', 2019, '35.00', 0, 0, '2019-07-14 23:59:59', NULL, 4, 2, '', NULL, 0),
(640, 'Večeře čtvrtek', 2019, '90.00', 0, 0, '2019-07-14 23:59:59', NULL, 4, 1, '', NULL, 0),
(641, 'Oběd čtvrtek', 2019, '90.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 1, '', NULL, 0),
(642, 'Dobrovolné vstupné (pozdě)', 2019, '0.00', 0, 0, NULL, NULL, 5, NULL, '', NULL, 0),
(643, 'Dobrovolné vstupné', 2019, '0.00', 0, 0, '2019-06-30 23:59:59', NULL, 5, NULL, '', NULL, 0),
(644, 'Proplacení bonusu', 2019, '0.00', 0, 0, NULL, NULL, 7, NULL, 'Pro vyplacení bonusů za vedení aktivit', NULL, 0),
(645, 'Kostka Cthulhu', 2022, '25.00', 0, 0, '2022-07-24 21:00:00', 500, 1, NULL, 'Cthulhu', 2, 0),
(646, 'Fate kostka', 2022, '25.00', 0, 0, '2022-07-24 21:00:00', 600, 1, NULL, '', 2, 0),
(647, 'Placka', 2021, '20.00', 0, 0, '2021-07-13 23:59:00', 250, 1, NULL, '', 1, 0),
(648, 'Ponožky (vel. 42-45)', 2021, '100.00', 0, 0, '2021-07-13 23:59:00', 200, 1, NULL, '', 7, 0),
(649, 'Ponožky (vel. 38-39)', 2021, '100.00', 0, 0, '2021-07-13 23:59:00', 100, 1, NULL, '', 7, 0),
(650, 'Trojlůžák neděle', 2021, '210.00', 0, 0, '2021-07-11 23:59:00', 282, 2, 4, '', NULL, 0),
(651, 'Trojlůžák sobota', 2021, '210.00', 0, 0, '2021-07-11 23:59:00', 282, 2, 3, '', NULL, 0),
(652, 'Trojlůžák pátek', 2021, '210.00', 0, 0, '2021-07-11 23:59:00', 282, 2, 2, '', NULL, 0),
(653, 'Trojlůžák čtvrtek', 2021, '210.00', 0, 0, '2021-07-11 23:59:00', 282, 2, 1, '', NULL, 0),
(654, 'Trojlůžák středa', 2021, '210.00', 0, 0, '2021-07-11 23:59:00', 282, 2, 0, '', NULL, 0),
(655, 'Dvojlůžák neděle', 2021, '250.00', 0, 0, '2021-07-11 23:59:00', 300, 2, 4, '', NULL, 0),
(656, 'Dvojlůžák sobota', 2021, '250.00', 0, 0, '2021-07-11 23:59:00', 300, 2, 3, '', NULL, 0),
(657, 'Dvojlůžák pátek', 2021, '250.00', 0, 0, '2021-07-11 23:59:00', 300, 2, 2, '', NULL, 0),
(658, 'Dvojlůžák čtvrtek', 2021, '250.00', 0, 0, '2021-07-11 23:59:00', 300, 2, 1, '', NULL, 0),
(659, 'Dvojlůžák středa', 2021, '250.00', 0, 0, '2021-07-11 23:59:00', 300, 2, 0, '', NULL, 0),
(660, 'Jednolůžák neděle', 2021, '300.00', 0, 0, '2021-07-11 23:59:00', 11, 2, 4, '', NULL, 0),
(661, 'Jednolůžák sobota', 2021, '300.00', 0, 0, '2021-07-11 23:59:00', 11, 2, 3, '', NULL, 0),
(662, 'Jednolůžák pátek', 2021, '300.00', 0, 0, '2021-07-11 23:59:00', 11, 2, 2, '', NULL, 0),
(663, 'Jednolůžák čtvrtek', 2021, '300.00', 0, 0, '2021-07-11 23:59:00', 11, 2, 1, '', NULL, 0),
(664, 'Jednolůžák středa', 2021, '300.00', 0, 0, '2021-07-11 23:59:00', 11, 2, 0, '', NULL, 0),
(665, 'Tričko modré pánské XXL', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(666, 'Tričko modré pánské XL', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(667, 'Tričko modré pánské S', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(668, 'Tričko modré pánské M', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(669, 'Tričko modré pánské L', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(670, 'Tričko červené pánské XXL', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(671, 'Tričko červené pánské XL', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(672, 'Tričko červené pánské S', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(673, 'Tričko červené pánské M', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(674, 'Tričko červené pánské L', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(675, 'Tričko účastnické pánské XXL', 2021, '220.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 0),
(676, 'Tričko účastnické pánské XL', 2021, '220.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 0),
(677, 'Tričko účastnické pánské S', 2021, '220.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 0),
(678, 'Tričko účastnické pánské M', 2021, '220.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 0),
(679, 'Tričko účastnické pánské L', 2021, '220.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 3, 0),
(680, 'Tílko modré dámské S', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(681, 'Tílko modré dámské M', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(682, 'Tílko modré dámské L', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(683, 'Tílko modré dámské XL', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(684, 'Tílko červené dámské S', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(685, 'Tílko červené dámské M', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(686, 'Tílko červené dámské L', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(687, 'Tílko červené dámské XL', 2021, '170.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(688, 'Tílko účastnické dámské S', 2021, '220.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 4, 0),
(689, 'Tílko účastnické dámské M', 2021, '220.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 4, 0),
(690, 'Tílko účastnické dámské L', 2021, '220.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 4, 0),
(691, 'Tílko účastnické dámské XL', 2021, '220.00', 0, 0, '2021-06-30 23:59:00', NULL, 3, NULL, '', 4, 0),
(692, 'Večeře neděle', 2021, '100.00', 0, 0, '2021-07-11 23:59:00', NULL, 4, 4, '', NULL, 0),
(693, 'Oběd neděle', 2021, '100.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 4, '', NULL, 0),
(694, ' Snídaně neděle', 2021, '45.00', 0, 0, '2021-07-11 23:59:00', NULL, 4, 4, '', NULL, 0),
(695, 'Večeře sobota', 2021, '100.00', 0, 0, '2021-07-11 23:59:00', NULL, 4, 3, '', NULL, 0),
(696, 'Oběd sobota', 2021, '100.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 3, '', NULL, 0),
(697, ' Snídaně sobota', 2021, '45.00', 0, 0, '2021-07-11 23:59:00', NULL, 4, 3, '', NULL, 0),
(698, 'Večeře pátek', 2021, '100.00', 0, 0, '2021-07-11 23:59:00', NULL, 4, 2, '', NULL, 0),
(699, 'Oběd pátek', 2021, '100.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 2, '', NULL, 0),
(700, ' Snídaně pátek', 2021, '45.00', 0, 0, '2021-07-11 23:59:00', NULL, 4, 2, '', NULL, 0),
(701, 'Večeře čtvrtek', 2021, '100.00', 0, 0, '2021-07-11 23:59:00', NULL, 4, 1, '', NULL, 0),
(702, 'Oběd čtvrtek', 2021, '100.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 1, '', NULL, 0),
(703, 'Dobrovolné vstupné (pozdě)', 2021, '0.00', 0, 0, NULL, NULL, 5, NULL, '', NULL, 0),
(704, 'Dobrovolné vstupné', 2021, '0.00', 0, 0, '2021-07-13 23:59:59', NULL, 5, NULL, '', NULL, 0),
(705, 'Proplacení bonusu', 2021, '0.00', 0, 0, NULL, NULL, 7, NULL, 'Pro vyplacení bonusů za vedení aktivit', NULL, 0),
(706, 'GameCon blok', 2019, '50.00', 0, 0, '2021-07-13 23:59:00', 100, 1, NULL, 'GC', 5, 0),
(707, 'COVID test', 2021, '250.00', 0, 0, '2021-07-11 00:00:00', NULL, 1, NULL, '', 8, 0),
(708, 'Kostka', 2022, '25.00', 0, 0, '2022-07-24 21:00:00', 500, 1, NULL, 'Duna', 2, 0),
(709, 'Placka', 2022, '25.00', 0, 0, '2022-07-24 21:00:00', 186, 1, NULL, '', 1, 0),
(710, 'Ponožky (vel. 42-45)', 2022, '100.00', 0, 0, '2022-07-24 21:00:00', 100, 1, NULL, '', 7, 0),
(711, 'Ponožky (vel. 38-39)', 2022, '100.00', 0, 0, '2022-07-24 21:00:00', 70, 1, NULL, '', 7, 0),
(712, 'Nicknack', 2022, '60.00', 0, 0, '2022-07-24 21:00:00', 500, 1, NULL, '', 6, 0),
(713, 'Blok', 2022, '50.00', 0, 0, '2022-07-24 21:00:00', 100, 1, NULL, '', 5, 0),
(714, 'Taška', 2022, '150.00', 0, 0, '2022-07-24 21:00:00', 300, 1, NULL, '', NULL, 0),
(715, 'Spacák neděle', 2022, '100.00', 0, 0, '2022-07-10 23:59:59', 50, 2, 4, '', NULL, 0),
(716, 'Spacák sobota', 2022, '100.00', 0, 0, '2022-07-10 23:59:59', 50, 2, 3, '', NULL, 0),
(717, 'Spacák pátek', 2022, '100.00', 0, 0, '2022-07-10 23:59:59', 50, 2, 2, '', NULL, 0),
(718, 'Spacák čtvrtek', 2022, '100.00', 0, 0, '2022-07-10 23:59:59', 50, 2, 1, '', NULL, 0),
(719, 'Spacák středa', 2022, '100.00', 0, 0, '2022-07-10 23:59:59', 50, 2, 0, '', NULL, 0),
(720, 'Trojlůžák neděle', 2022, '250.00', 0, 0, '2022-07-10 23:59:59', 270, 2, 4, '', NULL, 0),
(721, 'Trojlůžák sobota', 2022, '250.00', 0, 0, '2022-07-10 23:59:59', 270, 2, 3, '', NULL, 0),
(722, 'Trojlůžák pátek', 2022, '250.00', 0, 0, '2022-07-10 23:59:59', 270, 2, 2, '', NULL, 0),
(723, 'Trojlůžák čtvrtek', 2022, '250.00', 0, 0, '2022-07-10 23:59:59', 270, 2, 1, '', NULL, 0),
(724, 'Trojlůžák středa', 2022, '250.00', 0, 0, '2022-07-10 23:59:59', 270, 2, 0, '', NULL, 0),
(725, 'Dvojlůžák neděle', 2022, '300.00', 0, 0, '2022-07-10 23:59:59', 300, 2, 4, '', NULL, 0),
(726, 'Dvojlůžák sobota', 2022, '300.00', 0, 0, '2022-07-10 23:59:59', 300, 2, 3, '', NULL, 0),
(727, 'Dvojlůžák pátek', 2022, '300.00', 0, 0, '2022-07-10 23:59:59', 300, 2, 2, '', NULL, 0),
(728, 'Dvojlůžák čtvrtek', 2022, '300.00', 0, 0, '2022-07-10 23:59:59', 300, 2, 1, '', NULL, 0),
(729, 'Dvojlůžák středa', 2022, '300.00', 0, 0, '2022-07-10 23:59:59', 300, 2, 0, '', NULL, 0),
(730, 'Jednolůžák neděle', 2022, '400.00', 0, 0, '2022-07-10 23:59:59', 14, 2, 4, '', NULL, 0),
(731, 'Jednolůžák sobota', 2022, '400.00', 0, 0, '2022-07-10 23:59:59', 14, 2, 3, '', NULL, 0),
(732, 'Jednolůžák pátek', 2022, '400.00', 0, 0, '2022-07-10 23:59:59', 14, 2, 2, '', NULL, 0),
(733, 'Jednolůžák čtvrtek', 2022, '400.00', 0, 0, '2022-07-10 23:59:59', 14, 2, 1, '', NULL, 0),
(734, 'Jednolůžák středa', 2022, '400.00', 0, 0, '2022-07-10 23:59:59', 14, 2, 0, '', NULL, 0),
(735, 'Tričko modré pánské XXL', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(736, 'Tričko modré pánské XL', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(737, 'Tričko modré pánské S', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(738, 'Tričko modré pánské M', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(739, 'Tričko modré pánské L', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(740, 'Tričko červené pánské XXL', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(741, 'Tričko červené pánské XL', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(742, 'Tričko červené pánské S', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(743, 'Tričko červené pánské M', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(744, 'Tričko červené pánské L', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(745, 'Tričko účastnické pánské XXL', 2022, '250.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 0),
(746, 'Tričko účastnické pánské XL', 2022, '250.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 0),
(747, 'Tričko účastnické pánské S', 2022, '250.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 0),
(748, 'Tričko účastnické pánské M', 2022, '250.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 0),
(749, 'Tričko účastnické pánské L', 2022, '250.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 0),
(750, 'Tílko modré dámské S', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(751, 'Tílko modré dámské M', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(752, 'Tílko modré dámské L', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(753, 'Tílko modré dámské XL', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(754, 'Tílko červené dámské S', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(755, 'Tílko červené dámské M', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(756, 'Tílko červené dámské L', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(757, 'Tílko červené dámské XL', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(758, 'Tílko účastnické dámské S', 2022, '250.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 0),
(759, 'Tílko účastnické dámské M', 2022, '250.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 0),
(760, 'Tílko účastnické dámské L', 2022, '250.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 0),
(761, 'Tílko účastnické dámské XL', 2022, '250.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 0),
(762, 'Večeře neděle levnější', 2022, '100.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 4, '', NULL, 0),
(763, 'Oběd neděle levnější', 2022, '100.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 4, '', NULL, 0),
(764, ' Snídaně neděle', 2022, '45.00', 0, 0, '2022-07-18 00:00:00', NULL, 4, 4, '', NULL, 0),
(765, 'Večeře sobota levnější', 2022, '100.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 3, '', NULL, 0),
(766, 'Oběd sobota levnější', 2022, '100.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 3, '', NULL, 0),
(767, ' Snídaně sobota', 2022, '45.00', 0, 0, '2022-07-18 00:00:00', NULL, 4, 3, '', NULL, 0),
(768, 'Večeře pátek levnější', 2022, '100.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 2, '', NULL, 0),
(769, 'Oběd pátek levnější', 2022, '100.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 2, '', NULL, 0),
(770, ' Snídaně pátek', 2022, '45.00', 0, 0, '2022-07-18 00:00:00', NULL, 4, 2, '', NULL, 0),
(771, 'Večeře čtvrtek levnější', 2022, '100.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 1, '', NULL, 0),
(772, 'Oběd čtvrtek levnější', 2022, '100.00', 0, 0, '2022-05-21 11:05:14', NULL, 4, 1, '', NULL, 0),
(773, 'Dobrovolné vstupné (pozdě)', 2022, '0.00', 0, 0, NULL, NULL, 5, NULL, '', NULL, 0),
(774, 'Dobrovolné vstupné', 2022, '0.00', 0, 0, '2022-07-13 23:59:59', NULL, 5, NULL, '', NULL, 0),
(775, 'Proplacení bonusu', 2022, '0.00', 0, 0, NULL, NULL, 7, NULL, 'Pro vyplacení bonusů za vedení aktivit', NULL, 0),
(776, 'COVID test', 2022, '250.00', 0, 0, '2022-07-24 21:00:00', NULL, 1, NULL, '', 8, 0),
(777, 'Tričko modré pánské XXXL', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(778, 'Tričko účastnické pánské XXXL', 2022, '250.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 0),
(779, 'Večeře neděle', 2022, '120.00', 0, 0, '2022-07-18 00:00:00', NULL, 4, 4, '', NULL, 0),
(780, 'Oběd neděle', 2022, '120.00', 0, 0, '2022-07-18 00:00:00', NULL, 4, 4, '', NULL, 0),
(781, 'Večeře sobota', 2022, '120.00', 0, 0, '2022-07-18 00:00:00', NULL, 4, 3, '', NULL, 0),
(782, 'Oběd sobota', 2022, '120.00', 0, 0, '2022-07-18 00:00:00', NULL, 4, 3, '', NULL, 0),
(783, 'Večeře pátek', 2022, '120.00', 0, 0, '2022-07-18 00:00:00', NULL, 4, 2, '', NULL, 0),
(784, 'Oběd pátek', 2022, '120.00', 0, 0, '2022-07-18 00:00:00', NULL, 4, 2, '', NULL, 0),
(785, 'Večeře čtvrtek', 2022, '120.00', 0, 0, '2022-07-18 00:00:00', NULL, 4, 1, '', NULL, 0),
(786, 'Oběd čtvrtek', 2022, '120.00', 0, 0, '2022-07-18 00:00:00', NULL, 4, 1, '', NULL, 0),
(787, 'Tričko červené pánské XXXL', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 3, 1),
(788, 'Tílko modré dámské XXL', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(789, 'Tílko červené dámské XXL', 2022, '200.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 1),
(790, 'Tílko účastnické dámské XXL', 2022, '250.00', 0, 0, '2022-06-30 23:59:00', NULL, 3, NULL, '', 4, 0),
(791, 'Tričko staré', 2022, '250.00', 0, 0, '2022-07-24 23:59:00', NULL, 3, NULL, '', 3, 0),
(792, 'Dračí kostka', 2023, '60.00', 1, 0, '2023-07-09 23:59:00', 500, 1, NULL, '2023', NULL, 0),
(793, 'Placka', 2023, '25.00', 1, 0, '2023-07-09 23:59:00', 300, 1, NULL, '', NULL, 0),
(794, 'Kostka kruhy', 2023, '25.00', 1, 0, '2023-07-09 23:59:00', 80, 1, NULL, '', NULL, 0),
(795, 'Fate kostka', 2023, '25.00', 1, 0, '2023-07-09 23:59:00', 240, 1, NULL, '', NULL, 0),
(796, 'Duna kostka', 2023, '25.00', 1, 0, '2023-07-09 23:59:00', 220, 1, NULL, '', NULL, 0),
(797, 'Ponožky (vel. 42-45)', 2023, '100.00', 1, 0, '2023-07-09 23:59:00', 207, 1, NULL, '', NULL, 0),
(798, 'Ponožky (vel. 38-39)', 2023, '100.00', 1, 0, '2023-07-09 23:59:00', 43, 1, NULL, '', NULL, 0),
(799, 'Nicknack', 2023, '60.00', 1, 0, '2023-07-09 23:59:00', 500, 1, NULL, '', NULL, 0),
(800, 'Blok', 2023, '100.00', 1, 0, '2023-07-09 23:59:00', 300, 1, NULL, '', NULL, 0),
(801, 'Taška', 2023, '150.00', 1, 0, '2023-07-09 23:59:00', 220, 1, NULL, '', NULL, 0),
(802, 'Spacák neděle', 2023, '100.00', 1, 0, '2023-07-16 23:59:00', 50, 2, 4, '', NULL, 0),
(803, 'Spacák sobota', 2023, '100.00', 1, 0, '2023-07-16 23:59:00', 49, 2, 3, '', NULL, 0),
(804, 'Spacák pátek', 2023, '100.00', 1, 0, '2023-07-16 23:59:00', 49, 2, 2, '', NULL, 0),
(805, 'Spacák čtvrtek', 2023, '100.00', 1, 0, '2023-07-16 23:59:00', 42, 2, 1, '', NULL, 0),
(806, 'Spacák středa', 2023, '100.00', 1, 0, '2023-07-16 23:59:00', 10, 2, 0, '', NULL, 0),
(807, 'Trojlůžák neděle', 2023, '250.00', 1, 0, '2023-07-16 23:59:00', 213, 2, 4, '', NULL, 0),
(808, 'Trojlůžák sobota', 2023, '250.00', 1, 0, '2023-07-16 23:59:00', 204, 2, 3, '', NULL, 0),
(809, 'Trojlůžák pátek', 2023, '250.00', 1, 0, '2023-07-16 23:59:00', 215, 2, 2, '', NULL, 0),
(810, 'Trojlůžák čtvrtek', 2023, '250.00', 1, 0, '2023-07-16 23:59:00', 198, 2, 1, '', NULL, 0),
(811, 'Trojlůžák středa', 2023, '250.00', 1, 0, '2023-07-16 23:59:00', 66, 2, 0, '', NULL, 0),
(812, 'Dvojlůžák neděle', 2023, '300.00', 1, 0, '2023-07-16 23:59:00', 257, 2, 4, '', NULL, 0),
(813, 'Dvojlůžák sobota', 2023, '300.00', 1, 0, '2023-07-16 23:59:00', 253, 2, 3, '', NULL, 0),
(814, 'Dvojlůžák pátek', 2023, '300.00', 1, 0, '2023-07-16 23:59:00', 257, 2, 2, '', NULL, 0),
(815, 'Dvojlůžák čtvrtek', 2023, '300.00', 1, 0, '2023-07-16 23:59:00', 235, 2, 1, '', NULL, 0),
(816, 'Dvojlůžák středa', 2023, '300.00', 1, 0, '2023-07-16 23:59:00', 61, 2, 0, '', NULL, 0),
(817, 'Jednolůžák neděle', 2023, '400.00', 1, 0, '2023-07-16 23:59:00', 10, 2, 4, '', NULL, 0),
(818, 'Jednolůžák sobota', 2023, '400.00', 1, 0, '2023-07-16 23:59:00', 10, 2, 3, '', NULL, 0),
(819, 'Jednolůžák pátek', 2023, '400.00', 1, 0, '2023-07-16 23:59:00', 10, 2, 2, '', NULL, 0),
(820, 'Jednolůžák čtvrtek', 2023, '400.00', 1, 0, '2023-07-16 23:59:00', 10, 2, 1, '', NULL, 0),
(821, 'Jednolůžák středa', 2023, '400.00', 1, 0, '2023-07-16 23:59:00', 5, 2, 0, '', NULL, 0),
(822, 'Tričko modré pánské XXXL', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(823, 'Tričko modré pánské XXL', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(824, 'Tričko modré pánské XL', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(825, 'Tričko modré pánské S', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(826, 'Tričko modré pánské M', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(827, 'Tričko modré pánské L', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(828, 'Tričko červené pánské XXXL', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(829, 'Tričko červené pánské XXL', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(830, 'Tričko červené pánské XL', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(831, 'Tričko červené pánské S', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(832, 'Tričko červené pánské M', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(833, 'Tričko červené pánské L', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(834, 'Tričko účastnické pánské XXXL', 2023, '250.00', 1, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(835, 'Tričko účastnické pánské XXL', 2023, '250.00', 1, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(836, 'Tričko účastnické pánské XL', 2023, '250.00', 1, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(837, 'Tričko účastnické pánské S', 2023, '250.00', 1, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(838, 'Tričko účastnické pánské M', 2023, '250.00', 1, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(839, 'Tričko účastnické pánské L', 2023, '250.00', 1, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(840, 'Tílko modré dámské S', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(841, 'Tílko modré dámské M', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(842, 'Tílko modré dámské L', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(843, 'Tílko modré dámské XL', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(844, 'Tílko modré dámské XXL', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(845, 'Tílko červené dámské S', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(846, 'Tílko červené dámské M', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(847, 'Tílko červené dámské L', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(848, 'Tílko červené dámské XL', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(849, 'Tílko červené dámské XXL', 2023, '200.00', 2, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(850, 'Tílko účastnické dámské S', 2023, '250.00', 1, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(851, 'Tílko účastnické dámské M', 2023, '250.00', 1, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(852, 'Tílko účastnické dámské L', 2023, '250.00', 1, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(853, 'Tílko účastnické dámské XL', 2023, '250.00', 1, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(854, 'Tílko účastnické dámské XXL', 2023, '250.00', 1, 0, '2023-06-23 23:59:00', NULL, 3, NULL, '', NULL, 0),
(855, 'Večeře neděle', 2023, '120.00', 1, 0, '2023-07-16 23:59:00', NULL, 4, 4, '', NULL, 0),
(856, 'Oběd neděle', 2023, '120.00', 1, 0, '2023-07-16 23:59:00', NULL, 4, 4, '', NULL, 0),
(857, 'Snídaně neděle', 2023, '80.00', 1, 0, '2023-07-16 23:59:00', NULL, 4, 4, '', NULL, 0),
(858, 'Večeře sobota', 2023, '120.00', 1, 0, '2023-07-16 23:59:00', NULL, 4, 3, '', NULL, 0),
(859, 'Oběd sobota', 2023, '120.00', 1, 0, '2023-07-16 23:59:00', NULL, 4, 3, '', NULL, 0),
(860, 'Snídaně sobota', 2023, '80.00', 1, 0, '2023-07-16 23:59:00', NULL, 4, 3, '', NULL, 0),
(861, 'Večeře pátek', 2023, '120.00', 1, 0, '2023-07-16 23:59:00', NULL, 4, 2, '', NULL, 0),
(862, 'Oběd pátek', 2023, '120.00', 1, 0, '2023-07-16 23:59:00', NULL, 4, 2, '', NULL, 0),
(863, 'Snídaně pátek', 2023, '80.00', 1, 0, '2023-07-16 23:59:00', NULL, 4, 2, '', NULL, 0),
(864, 'Večeře čtvrtek', 2023, '120.00', 1, 0, '2023-07-16 23:59:00', NULL, 4, 1, '', NULL, 0),
(865, 'Oběd čtvrtek', 2023, '120.00', 1, 0, '2023-07-16 23:59:00', NULL, 4, 1, '', NULL, 0),
(866, 'Dobrovolné vstupné (pozdě)', 2023, '0.00', 3, 0, NULL, NULL, 5, NULL, '', NULL, 0),
(867, 'Dobrovolné vstupné', 2023, '0.00', 2, 0, '2022-07-13 23:59:59', NULL, 5, NULL, '', NULL, 0),
(868, 'Proplacení bonusu', 2023, '0.00', 1, 0, NULL, NULL, 7, NULL, 'Pro vyplacení bonusů za vedení aktivit', NULL, 0),
(869, 'COVID test', 2023, '250.00', 2, 0, '2022-07-11 00:00:00', NULL, 1, NULL, '', NULL, 0);

-- --------------------------------------------------------

--
-- Struktura tabulky `sjednocene_tagy`
--

CREATE TABLE `sjednocene_tagy` (
  `id` int(10) UNSIGNED NOT NULL,
  `id_kategorie_tagu` int(10) UNSIGNED NOT NULL,
  `nazev` varchar(128) COLLATE utf8_czech_ci NOT NULL,
  `poznamka` text COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `sjednocene_tagy`
--

INSERT INTO `sjednocene_tagy` (`id`, `id_kategorie_tagu`, `nazev`, `poznamka`) VALUES
(45, 41, '13th Age', ''),
(2309, 14, 'Abstraktní', ''),
(12375, 47, 'Age of Sigmar', ''),
(12393, 41, 'AGON', ''),
(12422, 41, 'Achtung! Cthulhu', ''),
(109, 3, 'Akční', ''),
(12400, 41, 'Alice is Missing', ''),
(12401, 41, 'Alien RPG', ''),
(769, 4, 'Alternativní historie', ''),
(4944, 26, 'Amazonie', ''),
(66, 14, 'Ameritrash', ''),
(12411, 17, 'Anime', ''),
(99, 41, 'Apocalypse World', ''),
(277, 36, 'Argumentační', ''),
(8282, 25, 'Asterion', ''),
(3665, 5, 'Atmosférická', ''),
(12403, 41, 'Avatar Legends', ''),
(776, 41, 'Aye Dark Overlord', ''),
(919, 37, 'Běhací', ''),
(232, 41, 'Bez systému', ''),
(7991, 33, 'Bez vypravěče', ''),
(12408, 41, 'Blade Runner', ''),
(2615, 41, 'Blades in the Dark', ''),
(12395, 14, 'Blafovací', ''),
(87, 26, 'Blázinec', ''),
(2790, 41, 'Bliss Stage', ''),
(12419, 41, 'Call of Cthulhu', ''),
(12427, 41, 'Call of Cthulhu 7e', ''),
(2784, 41, 'Capes RPG', ''),
(12426, 41, 'Cats of Catthulhu', ''),
(9246, 4, 'Cestování časem', ''),
(12347, 49, 'CGE', ''),
(12348, 41, 'City of Mist', ''),
(12410, 41, 'Cornucopia RPG', ''),
(2182, 4, 'Cthulhu Mythos', ''),
(12402, 41, 'Cy_Borg', ''),
(227, 3, 'Cyberpunk', ''),
(12389, 41, 'Cyberpunk RED', ''),
(768, 41, 'Časy se mění', ''),
(12366, 26, 'Čechy', ''),
(84, 26, 'Čína', ''),
(8161, 41, 'Dakara', ''),
(2648, 3, 'Dark Fantasy', ''),
(12398, 41, 'Death in Space', ''),
(1837, 16, 'Debata', ''),
(97, 14, 'Deckbuilding', ''),
(12373, 41, 'Delta Green', ''),
(72, 1, 'Deluxe', ''),
(10284, 38, 'Demohraní', ''),
(9107, 49, 'Deskofobie', ''),
(88, 3, 'Detektivka', ''),
(12384, 41, 'DnD 3.5e', ''),
(12, 41, 'DnD 4e', ''),
(50, 41, 'DnD 5e', ''),
(9342, 41, 'DnD 5e upravené', ''),
(2598, 3, 'Dobrodružná', ''),
(13, 41, 'Dogs in the Vineyard', ''),
(12418, 41, 'Dračák podle staré školy', ''),
(60, 16, 'Dračí doupě', ''),
(12420, 41, 'Dračí Hlídka', ''),
(2, 41, 'Dračí kutloch', ''),
(49, 41, 'DrD 1.0', ''),
(5, 41, 'DrD 1.6', ''),
(18, 41, 'DrD II', ''),
(9333, 41, 'DrD upravené', ''),
(38, 41, 'DrD+', ''),
(7, 41, 'Dread', ''),
(12381, 41, 'Dune - Adventures in the Imperium', ''),
(9008, 41, 'Dungeon World', ''),
(8109, 33, 'Dungeoncrawl', ''),
(12383, 3, 'Dystopie', ''),
(920, 5, 'Edukativní', 'učící'),
(5078, 38, 'Ekonomická', ''),
(12349, 36, 'Emoční', ''),
(5302, 41, 'End of the World', ''),
(62, 1, 'Eng Only', ''),
(16, 41, 'Engel', ''),
(68, 14, 'Euro', ''),
(10, 41, 'Exalted', ''),
(33, 41, 'FAE', ''),
(2181, 41, 'Fall of Delta Green', ''),
(1110, 3, 'Fantasy', ''),
(1, 41, 'Fate', '(nejasné edice)'),
(32, 41, 'Fate 4e', ''),
(9, 41, 'Fate: Příběhy Impéria', ''),
(12350, 41, 'Feng Shui 2', ''),
(12387, 26, 'Férie', ''),
(41, 41, 'Fiasco', ''),
(299, 4, 'Forgotten Realms', ''),
(1372, 26, 'Francie', ''),
(5283, 7, 'Gamebook', ''),
(12416, 41, 'Genesys', ''),
(2142, 41, 'GUMSHOE', ''),
(17, 41, 'GURPS', ''),
(12370, 41, 'Hero Kids', ''),
(300, 3, 'High Fantasy', ''),
(12421, 41, 'Hillfolk (DramaSystem)', ''),
(351, 4, 'Historie', ''),
(12424, 41, 'Honey heist', ''),
(371, 3, 'Horor', ''),
(12377, 41, 'Horror Story Round Table', ''),
(11102, 41, 'Hunter: the Vigil', ''),
(12405, 41, 'Chronicles of Darkness', ''),
(2416, 41, 'Chuubo', ''),
(104, 1, 'I pro nováčky', ''),
(11764, 5, 'Improvizační', ''),
(83, 26, 'Itálie', ''),
(2633, 12, 'Jeepforma', ''),
(12386, 41, 'Jeskyně a draci', ''),
(12412, 17, 'JRPG', ''),
(12365, 41, 'k6 core', ''),
(12368, 14, 'Kartičková', ''),
(85, 26, 'Kensington', ''),
(1109, 47, 'Kings of War', ''),
(12415, 41, 'Kobold Endeavour', ''),
(78, 3, 'Komedie', ''),
(36, 25, 'Končina', ''),
(94, 26, 'Konstantinopol', ''),
(67, 14, 'Kooperativní', ''),
(355, 36, 'Kostýmová', ''),
(12429, 41, 'Kult: Divinity Lost', ''),
(8074, 41, 'Labyrinth Lord', ''),
(12379, 16, 'Larp', 'SPECIÁLNÍ - označuje Larp program v ne-Larp sekcích.'),
(1855, 26, 'Londýn', ''),
(1672, 3, 'Low Fantasy', ''),
(31, 41, 'Mage', ''),
(92, 26, 'Malajsie', ''),
(2220, 41, 'Malifaux', ''),
(12417, 41, 'Masks: A New Generation', ''),
(12391, 41, 'Mausritter', ''),
(5875, 26, 'Mexiko', ''),
(2308, 41, 'Microscope', ''),
(12352, 49, 'Mindok', ''),
(12390, 41, 'Monster of the Week', ''),
(12399, 41, 'Mörk Borg', ''),
(21, 41, 'Mouse Guard', ''),
(12423, 41, 'Mutant Chronicles', ''),
(11785, 5, 'Muzikál', ''),
(2652, 25, 'My Little Pony', ''),
(2432, 3, 'Mysteriózní', ''),
(12353, 3, 'Mystická', ''),
(93, 26, 'Nanking', ''),
(12354, 26, 'Německo', ''),
(2614, 3, 'New Weird', ''),
(2141, 41, 'Night\'s Black Agents', ''),
(1464, 3, 'Noir', ''),
(1859, 26, 'Norsko', ''),
(34, 41, 'Numenéra', ''),
(223, 5, 'Odlehčená', ''),
(1054, 37, 'Odpočinková', ''),
(52, 41, 'Og', ''),
(12428, 41, 'Old School Essentials', ''),
(3768, 33, 'Oldschool', ''),
(1853, 4, 'Pán prstenů', ''),
(12382, 16, 'Panelová diskuse', ''),
(230, 41, 'Paranoia XP', ''),
(75, 14, 'Párty hra', ''),
(46, 41, 'Pathfinder', ''),
(96, 41, 'PbtA', ''),
(15, 41, 'Pendragon', ''),
(8241, 41, 'Penny for My Thoughts', ''),
(1569, 3, 'Piráti', ''),
(10865, 1, 'Playtest', ''),
(7989, 41, 'Polaris', ''),
(1468, 3, 'Post-apo', ''),
(1863, 26, 'Praha', ''),
(25, 41, 'Primetime Adventures', ''),
(69, 1, 'Pro pokročilé', ''),
(12371, 41, 'Projekt Omega', ''),
(1046, 37, 'Přemýšlecí', ''),
(8242, 2, 'Psychologická', ''),
(2599, 3, 'Pulp', ''),
(12369, 26, 'Rakousko-Uhersko', ''),
(40, 41, 'Renaissance Deluxe', ''),
(6049, 41, 'Risus', ''),
(4454, 3, 'Romance', ''),
(5717, 26, 'Rovníková Afrika', ''),
(12355, 5, 'Rozhodovací', ''),
(3659, 16, 'RPG', 'SPECIÁLNÍ - označuje RPG program v ne-RPG sekcích.'),
(12392, 3, 'Řecké báje', ''),
(1132, 47, 'Saga', ''),
(12374, 33, 'Sandbox', ''),
(231, 3, 'Sci-fi', ''),
(1469, 3, 'Science-fantasy', ''),
(63, 14, 'Semi-kooperativní', ''),
(101, 41, 'Shadow of the Demon Lord', ''),
(29, 41, 'Shadowrun 2e', ''),
(12404, 41, 'Shadowrun 3e', ''),
(6, 41, 'Shadows', ''),
(58, 41, 'Shadows of Esteren', ''),
(1488, 41, 'Schwarze Auge 5e', ''),
(4947, 26, 'Sibiř', ''),
(82, 26, 'Singapur', ''),
(12376, 47, 'Skirmish', ''),
(315, 12, 'Skriptovaná', ''),
(86, 26, 'Sny', ''),
(11765, 36, 'Sociální drama', ''),
(8, 41, 'Solar', ''),
(89, 4, 'Současnost', ''),
(1463, 3, 'Space opera', ''),
(12385, 41, 'Spire', ''),
(2126, 4, 'Star Wars', ''),
(98, 41, 'Star Wars Saga Edition', ''),
(12425, 41, 'Star Wars: Edge of the Empire', ''),
(2221, 3, 'Steampunk', ''),
(64, 38, 'Strategická', ''),
(4, 41, 'Střepy snů', ''),
(2785, 3, 'Superhrdinové', ''),
(12414, 41, 'Svitky hrdinů', ''),
(10994, 41, 'Symbaroum', ''),
(2651, 41, 'Tails of Equestria', ''),
(12396, 16, 'Talk', 'přednáška, prezentace'),
(12317, 13, 'Taneční', ''),
(2368, 25, 'Taria', ''),
(5807, 26, 'Tasmánie', ''),
(1377, 26, 'Taškent', ''),
(12356, 25, 'Tauril', ''),
(1598, 41, 'Ten Candles', ''),
(12406, 41, 'The Babylon Project', ''),
(1852, 41, 'The One Ring', ''),
(12378, 41, 'The Quiet Year', ''),
(226, 41, 'The Sprawl', ''),
(12388, 41, 'Thirsty Sword Lesbians', ''),
(2219, 41, 'Through the Breach', ''),
(5869, 26, 'Tibet', ''),
(12413, 41, 'Trademark Colony RPG', ''),
(7990, 3, 'Tragédie', ''),
(4026, 26, 'Tropy', ''),
(73, 1, 'Turnaj', ''),
(12407, 41, 'Twilight: 2000 4e', ''),
(1047, 1, 'Týmová', ''),
(12357, 26, 'Uhry', ''),
(2143, 3, 'Urbanfantasy', ''),
(12394, 41, 'Vaesen', ''),
(12409, 41, 'Vampire: The Masquerade 5e', ''),
(274, 5, 'Vážná', ''),
(5074, 50, 'Věk: 10+', ''),
(4120, 50, 'Věk: 12+', ''),
(4055, 50, 'Věk: 14+', ''),
(4067, 50, 'Věk: 15+', ''),
(12360, 50, 'Věk: 16+', ''),
(4464, 50, 'Věk: 18+', ''),
(12345, 50, 'Věk: 6+', ''),
(12361, 50, 'Věk: 7+', ''),
(4941, 50, 'Věk: 8+', ''),
(8759, 50, 'Věk: 9+', ''),
(12362, 50, 'Věk: do 15', '(akční hry / turnaje atp.)'),
(76, 13, 'Venkovní', ''),
(4455, 4, 'Vesmír', ''),
(12358, 33, 'Vícepostavová', ''),
(2586, 4, 'Viktoriánská doba', ''),
(12367, 41, 'Vlastní systém', ''),
(65, 5, 'Vyjednávací', ''),
(71, 5, 'Vyprávěcí', ''),
(77, 14, 'Vyprávění dle karet', '(bylo i v RPG - tarot atp.)'),
(12359, 8, 'Výška: 120+', ''),
(276, 12, 'Vztahová', ''),
(70, 14, 'Wargame', ''),
(11855, 16, 'Wargaming', 'SPECIÁLNÍ - označuje WG program v ne-WG sekcích.'),
(12363, 4, 'Warhammer (svět)', ''),
(1223, 47, 'Warzone', ''),
(4955, 3, 'Western', ''),
(1246, 41, 'WH 40k (RPG)', ''),
(54, 47, 'WH 40k (WG)', ''),
(19, 47, 'WH 40k: Dark Heresy', ''),
(56, 47, 'WH 40k: Rogue Trader', ''),
(1129, 47, 'WH Fantasy Battle', ''),
(51, 41, 'WH Fantasy Roleplay', ''),
(35, 41, 'WH Fantasy Roleplay 2e', ''),
(28, 41, 'WH Fantasy Roleplay 3e', ''),
(12372, 41, 'Wilderness of Mirrors', ''),
(4278, 14, 'Worker Placement', ''),
(690, 2, 'Workshop', ''),
(103, 41, 'World of Darkness 4e', ''),
(11, 41, 'World of Darkness 5e', ''),
(12364, 41, 'Zaklínač RPG', ''),
(12380, 41, 'Zapovězené země', ''),
(79, 12, 'Žánrovka', ''),
(12397, 16, 'Živé hraní', '');

-- --------------------------------------------------------

--
-- Struktura tabulky `slevy`
--

CREATE TABLE `slevy` (
  `id` int(11) NOT NULL,
  `id_uzivatele` int(11) NOT NULL,
  `castka` decimal(10,2) NOT NULL,
  `rok` int(11) NOT NULL,
  `provedeno` timestamp NOT NULL DEFAULT current_timestamp(),
  `provedl` int(11) DEFAULT NULL,
  `poznamka` text COLLATE utf8_czech_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `stranky`
--

CREATE TABLE `stranky` (
  `id_stranky` int(11) NOT NULL,
  `url_stranky` varchar(64) COLLATE utf8_czech_ci NOT NULL,
  `obsah` longtext COLLATE utf8_czech_ci NOT NULL COMMENT 'markdown',
  `poradi` tinyint(4) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `stranky`
--

INSERT INTO `stranky` (`id_stranky`, `url_stranky`, `obsah`, `poradi`) VALUES
(14, 'drd-info', '#O Mistrovství v DrD\r\n\r\n<!--\r\n<div class = \"galerie\">\r\n  <div style = \"float: right; padding-left: 6px;\">\r\n    <a href = \"http://fc09.deviantart.net/fs71/i/2014/105/b/8/dark_lane_by_rhysgriffiths-d6v25zi.jpg\" rel = \"lightbox[galerie]\">\r\n      <img src = \"http://fc09.deviantart.net/fs71/i/2014/105/b/8/dark_lane_by_rhysgriffiths-d6v25zi.jpg\" height=\"240px\" width=\"201px\" />\r\n    </a>\r\n  </div>\r\n</div>\r\n-->\r\n\r\n\r\nTurnaj v nejstarší původní české fantasy hry na hrdiny Dračí Doupě. Ve hře se ocitnete v kůži vámi vytvořené postavy a společně se spoluhráči projdete dobrodružstvím, které pro vás připravili zkušení Páni Jeskyně. V turnaji, který má tři kola, poměříte důvtip a herní um s ostatními družinami. Pouze jedna z družin může vyhrát putovní pohár a vstoupit do Síně slávy. Bude to letos vaše družina?\r\n\r\nDalší informace k turnaji naleznete v záložkách níže.\r\n\r\n<!--\r\n- [Organizace turnaje](drd/organizace-turnaje)\r\n- [Přihlašování na turnaj](drd/navod-na-prihlaseni)\r\n- [Pravidla pro tvorbu postavy](drd/pravidla-pro-tvorbu-postav)\r\n- [Informace k dobrodružství](drd/informace-o-dobrodruzstvi)\r\n- [Seznam PJů](organizatori/pjove)\r\n- [Starší dobrodružství](drd/starsi-dobrodruzstvi)\r\n- [Síň slávy](drd/sin-slavy)\r\n-->\r\n\r\n', 0),
(17, 'o-rpg-na-gc', '#RPG\r\n\r\nRPG jsou rolové hry, ve kterých se skupinou spoluhráčů vyprávíte společný a jedinečný příběh. Ocitnete se v kůži některé z postav, které v příběhu vystupují, popisujete jejich činy, mluvíte jejich ústy. \r\n\r\nObčas kromě vyprávění také sáhnete po kostkách i pravidlech, abyste do příběhu vnesli nejistotu a napětí. Nepotřebujete žádné prostředí ani rekvizity - podobně, jako když čtete knihu, jste omezeni jen vaší vlastní fantazií.', 0),
(24, 'o-larpech-na-gc', '#Larpy\r\n\r\n(Komorní) larp je hra, ve které se na několik hodin ponoříte do jiného světa. Nemáte scénář jako například herci ve filmu, vy sami jste tvůrci svého příběhu. Svou roli hrajete podobně jako v divadle, nehrajete však pro diváky, ale pro sebe navzájem. Vyjednáváte, intrikujete a snažíte se o dosažení cílů či o maximální prožití postavy. Nemusíte být žádní herci, larp se nedá zkazit. Každý hraje tak, jak je mu přirozené - nejde o herecký výkon, ale o zážitek ze hry.', 0),
(26, 'o-turnajich-v-deskovkach', '#Turnaje v deskovkách\r\n\r\nRád soutěžíš? Rád vyhráváš? Máš svoji oblíbenou hru a chceš zjistit, jak ji hrají ostatní? Máme pro tebe turnaje, ve kterých můžeš vyhrát některou z nádherných deskových her.', 0),
(28, 'o-prednaskach-na-gc', '#Přednášky\r\n\r\nTěšte se na přednášky, workshopy a panelové diskuze se známými i méně známými promotery a lidmi z komunity.\r\n\r\n**Uvedené časy přednášek jsou orientační**. Upřesnění naleznete v anotaci.\r\n\r\n**Přednášky jsou bezplatné.**', 0),
(41, 'o-workshopech-na-gc', '#O Přednáškách a Workshopech\r\n\r\nPřednášky a WS na GC jsou letos spojené do společných bloků vždy kolem jednoho tématu. Můžete je samozřejmě navštěvovat i jednotlivě, ale záměr je takový, aby vždy v rámci jednoho bloku utvořily plnohodnotný celek, který vám přinese co nejvíce.\r\n\r\nBloky jsou koncipované tak, aby vám poskytly co nejlepší vhled do věcí a abyste si z nich vždy něco odnesli - ať už nějakou dovednost, vědomost nebo rovnou materiál a nápady do vašich vlastních her. \r\n\r\nTěšit se můžete na témata deskových her, roleplayingu, stavby příběhů a mnohá další a jako vždy i na setkání se zajímavými tvůrci.', 0),
(43, 'organizatori/jak-se-stat-organizatorem', '<h1>Jak se stát organizátorem</h1>\r\n<p>\r\nPokud se vám GameCon líbí, jste plní elánu a bavilo by vás podílet se na jeho přípravě, ať už jako PJ, vypravěč, přednášející nebo třeba organizátor, určitě nám dejte vědět. Vždycky rádi přijmeme do našeho týmu novou krev.\r\n</p><p>\r\nPokud máte chuť jít do toho s námi, napište nám na email <a href = \"mailto:foo@example.com\">foo@example.com</a> cz něco o sobě a s čím byste třeba rádi pomáhali. Určitě se vám ozveme.\r\n</p>\r\n\r\n\r\n\r\n<h2>Hledáme 1-2 nové PJ</h2> \r\n<p>\r\nJsi skvělý Pán Jeskyně? Dokážeš  udržet potřebnou atmosféru, ale zároveň se i s hráči pobavit? Jsi nepodplatitelný, spravedlivý a umíš pevně držet otěže vyprávění? Tak přesně takového vypravěče či vypravěčku hledáme.\r\n</p> \r\n\r\n<p>\r\nVyhlašujeme tímto <strong>nábor nových Pánů Jeskyně</strong> pro <a href=\"#\">Mistrovství v Dračím Doupěti</a>. Výběrové řízení bude rozděleno na 3 kola:\r\n</p>\r\n<ul>\r\n\r\n      <li>vypracování  námětu pro soutěžní dobrodružství,</li>\r\n\r\n      <li>přátelský pohovor</li>\r\n\r\n      <li>a odehrání krátké hry za účasti některých ze stávajících <a href = \"http://gamecon.cz/organizatori/pjove\">Pánů Jeskyně</a>.</li>\r\n\r\n</ul> \r\n\r\n<p>\r\nMilý adepte, jako první  krok nám tedy pošli na mail <a href = \"mailto:foo@example.com\">foo@example.com</a> svůj námět na soutěžní dobrodružství. Měl by obsahovat dostatečně popsaný příběh rozdělený na tři části; doporučená délka textu jsou 2-3 stránky, ale konkrétní množství slov necháme na tvých vyjadřovacích schopnostech. Obratem se ozveme zpět a domluvíme se, jak dál.\r\n</p> \r\n\r\n<p>\r\nNeváhejte a pište. Těšíme se na novou krev. Ať žijí noví Pánové Jeskyně! (A těm starým věčnou slávu.)\r\n</p>', 0),
(48, 'kontakty', '#Kontakty\r\n\r\n<style>\r\n.org {margin-top: 40px; height:150px;}\r\n.leftOrg {border-radius:50%; width:150px !important; height:150px; float: left; margin-right: 50px; margin-bottom: 12px;}\r\n.rightOrg {float:left; }\r\n.description {min-height: 130px; max-width: 230px;}\r\n.link:hover {cursor: pointer}\r\n.name {font-size: 14pt; margin-bottom: 18px; font-weight: bold;}\r\n.about {margin-top: 12px;}\r\n.clear {clear: both;}\r\n.kontakt {float: left; max-width: 270px; margin-right: 60px; margin-bottom: 24px; text-align: justify;}\r\n.gcos {float: left; max-width: 220px;}\r\n.mail {font-size: 20pt; text-align: center; margin: 24px 0px 24px 0px; }\r\n</style>\r\n\r\n<div style=\"height: 70px;\"></div>\r\n\r\n<div class=\"kontakt\">\r\nMáte dotaz? Nejste si něčím jistí? Máte problém? Vyřešíme ho na této adrese:\r\n<div class=\"mail\">\r\n<a href=\"mailto:foo@example.com\">foo@example.com</a>\r\n</div>\r\n<p>V průběhu festivalu můžete využít také telefonický kontakt na Infopult: \r\n<div class=\"mail\">\r\n<a href=\"tel:+420735513899\">+420 735 513 899</a>\r\n</div>\r\nZdravotníka:\r\n<div class=\"mail\">\r\n<a href=\"tel:+420735540479\">+420 735 540 479</a>\r\n</div>\r\n...nebo Spřízněnou duši:\r\n<div class=\"mail\">\r\n<a href=\"tel:+420705943002\">+420 705 943 002</a>\r\n</div>\r\nSpřízněnou duši můžete kontaktovat i emailem, ke kterému má přístup pouze profesionální psycholožka Hana \"Fáňa\" Kovářová.\r\n<div class=\"mail\">\r\n<a href=\"mailto:foo@example.com\">foo@example.com</a>\r\n</div>\r\n</div>\r\n\r\n<div class=\"gcos\">\r\n\r\n<div id=\"gcos\">\r\n<b>GameCon z.s.</b><br />\r\nPernického 825/9<br />\r\n199 00 Praha 9 Letňany <br />\r\n<br />\r\n<b>IČO:</b> 22725474  <br />\r\n<b>Číslo účtu ČR:</b> 2800035147/2010  <br />\r\n<b>Číslo účtu SR:</b> 2800035147/8330 <br />\r\n</div>\r\n</div>\r\n\r\n<div style=\"clear: both;\"></div>\r\n<div style=\"text-align: justify;\">\r\n<p>Jste-li Vypravěč či instituce, je vždy rychlejší využít kontaktů na jednotlivé organizátory.</p></div>\r\n\r\n\r\n\r\n## Rada GC\r\n\r\n\r\n<!------- GANDALF -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/gandalf150.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Petr \"Gandalf\" Holub</div>\r\n      <div class=\"position\">Předseda Rady (\"hlavní organizátor\")</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com-ak.cz\">foo@example.com-ak.cz</a>\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(petr); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"clear\"></div>\r\n\r\n<div class=\"about\" id=\"petr\" style=\"display: none;\">\r\n<p>Na GameCon jsem jel poprvé v roce 1996 a od té doby jsem si vysloužil prakticky své vlastní inventární číslo. Nejprve jako PJ a v roce 2008 jsem převzal roli hlavního organizátora GameConu. V této „kratochvíli“ mi udělaly nucenou přestávku děti a po ní jsem střídavě vedl zázemí nebo finance (nebo obojí :)) až jsem si letos opět vysloužil místo v čele organizačního týmu.</p>\r\n\r\n<p>Na hraní už mi přes rok zbývá času výrazně méně a většinou to jsou deskovky a občas nějaké RPG. GameCon je ale stále více než koníček - spíše srdcová záležitost. Všechny ty hodiny práce stojí za to, když se GameCon vydaří a je z něj skvělá akce, na kterou lidi rádi jezdí.</p>\r\n</div>\r\n\r\n\r\n<!------- FLANT -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/flant.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Mirek \"Flant\" Dokoupil</div>\r\n      <div class=\"position\">Šéf Zázemí a provozu, Místopředseda Rady</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a>\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(flant); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"clear\"></div>\r\n\r\n<div class=\"about\" id=\"flant\" style=\"display: none;\">\r\n<p>Na svůj první Gamecon jsem se dostal vlastně náhodou, v roce 2011. Hlavním tahákem pro mě byly deskovky, moc příležitostí jak si je zahrát jsem během roku neměl, takže Gamecon jsem si užíval. Ale začaly mě zajímat i figurky a wargaming, ke kterému jsem taky přičichnul. </p>\r\n\r\n<p>Jak šel čas a Gamecon se přesunul do Parbudic, chtěl jsem přiložit ruku k dílu a pomoct jako dobrovolník. A tak nějak se stalo, že jsem pomáhal víc a víc, až jsem nakonec zapadl do organizačního týmu Zázemí.</p>\r\n</div>\r\n\r\n\r\n<!------- PAVEL -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/zapa.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Pavel \"ZaPa\" Zahradil</div>\r\n      <div class=\"position\">Finance, Sponzoři, Místopředseda Rady</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(zapa); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div class=\"clear\"></div>\r\n\r\n<div id=\"zapa\" style=\"display: none;\">\r\n\r\n<p>Na první GameCon jsem přijel na přelomu tisíciletí do Olomouce, kdy jsme s kamarády coby skupina začínajících hráčů poprvé přijeli na mistrovství v DrD, kterého jsme se pravidelně účastnili následující dekádu. Po deseti letech bojů o titul jsem se rozhodl přejít na druhou stranu barikády a v roce 2010 jsem poprvé přijel na Gamecon jako vypravěč a organizátor. Od té doby se pohybuji v různých funkcích zázemí a pomáhám udržovat GameCon v chodu.</p>\r\n\r\n<p>S běžícím časem ubývalo času na hraní a od DrD a RPG se těžiště posunulo k občasným deskovkám a mojí nejoblíbenější aktivitou na GameConu se stal samotný GameCon a potkávání se s lidmi.\r\n</p></div>\r\n\r\n\r\n\r\n<!------- SIRIEN -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/sirien150.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Petr \"Sirien\" Mazák</div>\r\n      <div class=\"position\">Programová dramaturgie, člen Rady</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(sirien); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div class=\"clear\"></div>\r\n\r\n<div id=\"sirien\" style=\"display: none;\">\r\n\r\n<p>Má cesta ke GameConu a do jeho organizace byla dlouhá a složitá. Čím si mě GameCon nakonec získal byla perfektní kombinace různých druhů her, zábavy a párty a suprovou komunitou. Během mnoha let jsem prošel mnoha pozicemi GameConové organizace až po předsedu, odkud teď zase padám zpátky dolů. Důležité je, že GameCon i navzdory mému vedení stále ještě funguje a prosperuje, což je dobrá vizitka jeho kvality a síly komunity, která za ním stojí.</p>\r\n\r\n<p> Lidé mají často problém poznat, kdy si dělám srandu a kdy ne. Několikrát se stalo, že moje ironické vtipy během organizace vzali ostatní vážně a opravdu je realizovali. Nejsem si úplně jistý, co to o kom vypovídá. Obecně jsem přístupnější, než by se možná zdálo, takže mě určitě neváhejte oslovit (ať už online během roku nebo přímo na GC).</p>\r\n\r\n<p>Moje \"herní těžiště\" jsou a vždy byly RPGčka, ale časem jsem přišel na chuť snad všem druhům her, které GC v současnosti nabízí, zejména deskovkám a larpům. Kromě GC jsem v minulosti zorganizoval i pár jiných věcí a jsem jedním z adminů RPG webu <a href=\"http://www.d20.cz\">Kostky</a>. </p>\r\n\r\n</div>\r\n\r\n\r\n\r\n<!------- CEMI -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/cemi.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Lenka \"Cemi\" Zavadilová</div>\r\n      <div class=\"position\">Larpy, šéfka IT, členka Rady</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(cemi); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"clear\"></div>\r\n\r\n<div class=\"about\" id=\"cemi\" style=\"display: none;\">\r\n<p>Na GameConu jsem byla poprvé v roce 2013, kdy historky mých kamarádů o epických párty začaly být nesnesitelné a musela jsem se jet sama přesvědčit, co je na nich pravdy. Inu, nelhaly, párty jsou na GameConu skutečně legendární! Stejně boží je ale celá komunita, která na GameCon jezdí, našla jsem tu spoustu kamarádů, a zahrála si bezpočet skvělých her. GameCon mám prostě ráda.</p>\r\n\r\n<p>Larpy hraju… dlouho. Dlouho jsem taky vedla brněnské sdružení Hraju larpy, se kterým jsme v Brně zorganizovali dva epické larpové festivaly - Festival otrlého hráče a Festival elitních larpů. Pokud chcete zažít další boží larpový festival, přijeďte na GameCon!</p>\r\n</div>\r\n\r\n\r\n<!------- AMENTIA -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/amentia.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Lucka \"Amentia\" Faulhammerová</div>\r\n      <div class=\"position\">Šéfka Comms, členka Rady</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(amentia); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"clear\"></div>\r\n\r\n<div class=\"about\" id=\"amentia\" style=\"display: none;\">\r\n<p>under construction</p>\r\n\r\n</div>\r\n\r\n\r\n<!------- WEXXAR -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/wexxar.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Petr \"WexxAr\" Sejkora</div>\r\n      <div class=\"position\">Nákupy, vybavení, služby a místní záležitosti, člen Rady</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(wexxar); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"clear\"></div>\r\n\r\n<div class=\"about\" id=\"wexxar\" style=\"display: none;\">\r\n<p>Jo, to bylo někdy v roce 2014, kdy jsem si řekl, že bych si po dlouhé době fakt rád zahrál dračák. Chvilka googlování a vyběhl na mě GameCon. Co to je? No, je to v Pardubkách a hraje se tam dračák, tak to zkusím. Krátký pokec na fóru a vznikla družina Náhodné číslo, připravena vyhrát mDrD (připraveni jsme dodnes…).</p>\r\n\r\n<p>Atmosféra na GameConu mě tak pohltila, že jsem pár týdnů po skončení napsal na info mail, že bych chtěl pro GC taky něco dělat. Říkal jsem si, že bych mohl dělat jen něco málo, něco nenáročného… Chramst, chramst a už jsem vedl sekci offline marketingu. To mi vydrželo asi tři roky. Pak přišel nějakej Gandalf a že prej jestli nechci jít do Zázemí, že by se jim hodil člověk z Pardubic na řešení místních záležitostí. Hmm, tak proč ne… Žvejk, žvejk a kromě místních záležitostí jsem začal řešit i Snídaně (doufám, že Vám chutnaly), zajišťovat organizátorské srazy, včetně Valné hromady, občas koordinaci středečních, čtvrtečních a sobotních párty, a komunikaci s místními dodavateli (pizza, zmrzka, výdejníky na vodu, ale i popelnice a odpaďáky :D ).</p>\r\n\r\n<p>Letos (2021) za mnou zase přišel Gandalf, že prý jestli bych nechtěl dělat i celoGC nákupy. Nevím proč, na rameni se mi objevil miniaturní Admirál Ackbar a něco ikonického mi šeptal do ucha, ale já ho moc neposlouchal a na rozšíření své působnosti jsem kývnul (takže, jestli budete mít špatná trika, tak víte na koho nadávat). Abych toho, s čerstvě narozeným synem, neměl málo, tak jsem byl zvolen i jako člen Rady GC. No není to paráda? :D</p>\r\n\r\n<p>Každopádně vůbec nelituju (zatím) ani jedné hodiny, které jsem GameConu věnoval a rád této skvělé akci věnuji spousty dalších. Ten potlesk na ukončení GC mi za to stojí ;)</p>\r\n\r\n<p>V současné době hraju kromě deskovek i několik PC her, užívám si nový život jako otec a jako vesničan ve vlastním baráku. S Náhodným číslem stále čekáme na titul a každý týden trénujeme souhru v Dračí Hlídce. Zprvu jsem měl k online hraní dračáku odpor, ale postupem času jsem změnil názor a i toto má něco do sebe. Už se ale těším na další ročník a až se zase se všemi setkám osobně!</p>\r\n\r\n</div>\r\n\r\n\r\n\r\n## Zázemí a provoz\r\n\r\n<!------- FLANT -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/flant.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Mirek \"Flant\" Dokoupil</div>\r\n      <div class=\"position\">Šéf Zázemí a provozu, Místopředseda Rady</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a>\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(flant2); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"clear\"></div>\r\n\r\n<div class=\"about\" id=\"flant2\" style=\"display: none;\">\r\n<p>Na svůj první Gamecon jsem se dostal vlastně náhodou, v roce 2011. Hlavním tahákem pro mě byly deskovky, moc příležitostí jak si je zahrát jsem během roku neměl, takže Gamecon jsem si užíval. Ale začaly mě zajímat i figurky a wargaming, ke kterému jsem taky přičichnul. </p>\r\n\r\n<p>Jak šel čas a Gamecon se přesunul do Parbudic, chtěl jsem přiložit ruku k dílu a pomoct jako dobrovolník. A tak nějak se stalo, že jsem pomáhal víc a víc, až jsem nakonec zapadl do organizačního týmu Zázemí.</p>\r\n</div>\r\n\r\n\r\n<!------- PAVEL -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/zapa.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Pavel \"ZaPa\" Zahradil</div>\r\n      <div class=\"position\">Finance, Sponzoři, Místopředseda Rady</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(zapa2); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div class=\"clear\"></div>\r\n\r\n<div id=\"zapa2\" style=\"display: none;\">\r\n\r\n<p>Na první GameCon jsem přijel na přelomu tisíciletí do Olomouce, kdy jsme s kamarády coby skupina začínajících hráčů poprvé přijeli na mistrovství v DrD, kterého jsme se pravidelně účastnili následující dekádu. Po deseti letech bojů o titul jsem se rozhodl přejít na druhou stranu barikády a v roce 2010 jsem poprvé přijel na Gamecon jako vypravěč a organizátor. Od té doby se pohybuji v různých funkcích zázemí a pomáhám udržovat GameCon v chodu.</p>\r\n\r\n<p>S běžícím časem ubývalo času na hraní a od DrD a RPG se těžiště posunulo k občasným deskovkám a mojí nejoblíbenější aktivitou na GameConu se stal samotný GameCon a potkávání se s lidmi.\r\n</p></div>\r\n\r\n\r\n\r\n<!------- WEXXAR -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/wexxar.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Petr \"WexxAr\" Sejkora</div>\r\n      <div class=\"position\">Nákupy, vybavení, služby a místní záležitosti, člen Rady</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(wexxar2); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"clear\"></div>\r\n\r\n<div class=\"about\" id=\"wexxar2\" style=\"display: none;\">\r\n<p>Jo, to bylo někdy v roce 2014, kdy jsem si řekl, že bych si po dlouhé době fakt rád zahrál dračák. Chvilka googlování a vyběhl na mě GameCon. Co to je? No, je to v Pardubkách a hraje se tam dračák, tak to zkusím. Krátký pokec na fóru a vznikla družina Náhodné číslo, připravena vyhrát mDrD (připraveni jsme dodnes…).</p>\r\n\r\n<p>Atmosféra na GameConu mě tak pohltila, že jsem pár týdnů po skončení napsal na info mail, že bych chtěl pro GC taky něco dělat. Říkal jsem si, že bych mohl dělat jen něco málo, něco nenáročného… Chramst, chramst a už jsem vedl sekci offline marketingu. To mi vydrželo asi tři roky. Pak přišel nějakej Gandalf a že prej jestli nechci jít do Zázemí, že by se jim hodil člověk z Pardubic na řešení místních záležitostí. Hmm, tak proč ne… Žvejk, žvejk a kromě místních záležitostí jsem začal řešit i Snídaně (doufám, že Vám chutnaly), zajišťovat organizátorské srazy, včetně Valné hromady, občas koordinaci středečních, čtvrtečních a sobotních párty, a komunikaci s místními dodavateli (pizza, zmrzka, výdejníky na vodu, ale i popelnice a odpaďáky :D ).</p>\r\n\r\n<p>Letos (2021) za mnou zase přišel Gandalf, že prý jestli bych nechtěl dělat i celoGC nákupy. Nevím proč, na rameni se mi objevil miniaturní Admirál Ackbar a něco ikonického mi šeptal do ucha, ale já ho moc neposlouchal a na rozšíření své působnosti jsem kývnul (takže, jestli budete mít špatná trika, tak víte na koho nadávat). Abych toho, s čerstvě narozeným synem, neměl málo, tak jsem byl zvolen i jako člen Rady GC. No není to paráda? :D</p>\r\n\r\n<p>Každopádně vůbec nelituju (zatím) ani jedné hodiny, které jsem GameConu věnoval a rád této skvělé akci věnuji spousty dalších. Ten potlesk na ukončení GC mi za to stojí ;)</p>\r\n\r\n<p>V současné době hraju kromě deskovek i několik PC her, užívám si nový život jako otec a jako vesničan ve vlastním baráku. S Náhodným číslem stále čekáme na titul a každý týden trénujeme souhru v Dračí Hlídce. Zprvu jsem měl k online hraní dračáku odpor, ale postupem času jsem změnil názor a i toto má něco do sebe. Už se ale těším na další ročník a až se zase se všemi setkám osobně!</p>\r\n\r\n</div>\r\n\r\n\r\n## Šéfové programových sekcí\r\n\r\n\r\n<!------- MACIK -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/martina-piratska.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Martina \"Macík\" Čapková</div>\r\n      <div class=\"position\">Akční a bonusové hry, přednášky</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(macik); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div class=\"clear\"></div>\r\n\r\n<div  id=\"macik\" style=\"display: none;\">\r\n<p>Mám ráda zábavu, mám ráda pohyb, ráda se směju a ráda zkouším nové věci. Dlouhou dobu jsem také připravovala celoroční aktivity pro teenagery, což mě moc bavilo.  Akční hry na Gameconu proto pro mě od začátku byly největším tahákem. A tak jsem došla k rozhodnutí, že nechci být jen konzument zábavy, ale že se chci trochu víc podílet na přípravě těch super aktivit. Jak to dopadlo, můžete vidět sami.</br>\r\n</br>\r\nA protože mám nejspíš pocit, že mám hodně volného času, tak jsem se vrhla také do organizace přednášek. Doufám, že to bude k dobrému. Ale o tom se můžete přesvědčit na GameConu sami. A pokud byste měli nějaký nápad, o čem byste rádi slyšeli zajímavou přednášku, určitě mi dejte vědět a já zjistím, co se s tím dá dělat.</br>\r\n</br>\r\nJestli o mě chcete vědět víc, stačí se jen zeptat. Pokud mě tedy najdete a poznáte. Nebude to však jednoduché, protože jsem ženou mnoha tváří.</p>\r\n</div>\r\n\r\n\r\n<!------- JIRKA -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/jirka-hovorka-150.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Jiří „JirkaJ“ Hovorka</div>\r\n      <div class=\"position\">Deskoherna</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(jirka); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"clear\"></div>\r\n\r\n<div class=\"about\" id=\"jirka\" style=\"display: none;\">\r\n<p>Na Gamecon jsem začal jezdit jako účastník, následně jako vypravěč a nyní působím v týmu Gameconu jako vedoucí Deskoherny.</p>\r\n\r\n<p>Postupné zapojení má řadu výhod. Jako hráč i jako vypravěč vím co se dalo zlepšit a podle zpětné vazby se mi toto daří.</p>\r\n\r\n<p>Děkuji za podporu všem účastníkům i partnerům, kterou jsem dosud přijal.</p>\r\n</div>\r\n\r\n\r\n<!------- JINDŘICH -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/jindrich150.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Jindřich Mašek</div>\r\n      <div class=\"position\">Epické deskovky</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(jindra); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"clear\"></div>\r\n\r\n<div class=\"about\" id=\"jindra\" style=\"display: none;\">\r\n<p>Miluji deskovky a rád organizuji akce. Sekce Epické deskovky je pro mě ideální teritorium vyžití, až se toho občas i \"přejím\" :). Ale jsem velice rád, že je o Epiky zájem a zpětné vazby jsou až na výjimky kladné, a doufám, že tomu tak bude i nadále :) .</p>\r\n\r\n<p>GameCon dělají dobrý nejen orgové :-D, ale hlavně účastníci, děkuji Vám a těším se.</p>\r\n\r\n<p>Kdo o mě chce vědět víc, stačí se jen zeptat, budu na GameConu nebo kontakt nahoře :). Máš-li zájem uvádět deskovku v programu, pomáhat mi s organizací, a nebo se jen sejít a něco zahrát v Praze, neváhej a piš.</p>\r\n</div>\r\n\r\n\r\n\r\n<!------- CEMI -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/cemi.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Lenka \"Cemi\" Zavadilová</div>\r\n      <div class=\"position\">Larpy, šéfka IT, členka Rady</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(cemi2); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"clear\"></div>\r\n\r\n<div class=\"about\" id=\"cemi2\" style=\"display: none;\">\r\n<p>Na GameConu jsem byla poprvé v roce 2013, kdy historky mých kamarádů o epických párty začaly být nesnesitelné a musela jsem se jet sama přesvědčit, co je na nich pravdy. Inu, nelhaly, párty jsou na GameConu skutečně legendární! Stejně boží je ale celá komunita, která na GameCon jezdí, našla jsem tu spoustu kamarádů, a zahrála si bezpočet skvělých her. GameCon mám prostě ráda.</p>\r\n\r\n<p>Larpy hraju… dlouho. Dlouho jsem taky vedla brněnské sdružení Hraju larpy, se kterým jsme v Brně zorganizovali dva epické larpové festivaly - Festival otrlého hráče a Festival elitních larpů. Pokud chcete zažít další boží larpový festival, přijeďte na GameCon!</p>\r\n</div>\r\n\r\n\r\n\r\n<!------- APOPHIS -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/apophis150.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Jakub „apophis“ Korál</div>\r\n      <div class=\"position\">Legendy Klubu dobrodruhů</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(apophis); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div class=\"clear\"></div>\r\n\r\n<div id=\"apophis\" style=\"display: none;\">\r\n<p>Fantasy a hry s ním spojené hraju už snad dvě dekády. Milerád zajdu do čajovny, kavárny nebo jen tak na jedno – zdravotní. Může to být jak víno, tak tequilla či whisky. Kromě hraní her rád cestuji a poznávám nové věci, čtu fantasy literaturu a hraju si s Duplem se synem a dcerou.</p>\r\n<p>Začínal jsem na DrD, hrál Shadowrun 2.ed i 4.ed, zabrousil do WoD i nWoD, zkusil různé DnD variace i jinotvary a 24-hour RPGčka. Teď asi nejvíc vede Fate a jeho variace a alternativy. Na RP hrách a LARPech mě baví interakce s lidmi, jejich hraní a popasovávání se s improvizací. Deskovky, jak ty epické tak i jednoduché karetky na zabití času, jsou součástí seznamu činností, kterými plním tu trochu volného času, která mi zbyla.\r\n</p>\r\n</div>\r\n\r\n\r\n\r\n<!------- GUFF -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/guff150.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Vašek \"Guff\" Křapáček</div>\r\n      <div class=\"position\">Mistrovství v DrD</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(guff); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div class=\"clear\"></div>\r\n\r\n<div  id=\"guff\" style=\"display: none;\">\r\n  <p>K Dračímu Doupěti jsem se dostal již v roce 1996 na základní škole. Doupě se stalo mojí první a zároveň jedinou RPG láskou. Na GameCon jsem poprvé přijel v roce 2009. Do řad vypravěčů jsem vstoupil v roce 2011 a do řad organizátorů pak v roce 2014 po skončení GameConu.</p>\r\n  \r\n  <p>Mým hlavním pracovním cílem jako organizátor mDrD linie je připravit pro hráče kvalitní dobrodružství, na které budou rádi vzpomínat. Vedlejším osobním cílem je pak užít si GameCon stejně dobře, jako ty předešlé ročníky.</p>\r\n  \r\n  <p>Těším se!</p>\r\n</div>\r\n\r\n\r\n\r\n<!------- CAPTAIN -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/captain150.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Václav \"Captain\" Švejda</div>\r\n      <div class=\"position\">RPG</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(captain); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n<div class=\"clear\"></div>\r\n\r\n<div id=\"captain\" style=\"display: none;\">\r\n\r\n<p>Na svůj první Gamecon jsem se vydal úplnou náhodou. Kamarádům chyběl jeden člověk do skupiny na Mistrovství v Dračím doupěti a tak vzali i mě, rpg a deskovkami v té době nepostiženého jedince. Od té doby proteklo již řekami hodně vody, ale já se pořád rád vracím každý červenec zpátky, dnes už ale jako jeden z organizátorů.</p>\r\n<p>Za svoji hráčskou kariéru jsem již vyzkoušel nespočetné množství žánrů a systémů. Nemám žádné jasné preference a rád střídám styly. Rád si zahraji taktickými boji propletenou hru ve 4. edici Dungeons and Dragons, detektivku v Gumshoe nebo horor ve World of Darkness. Obecně preferuji spíše vážnější stylizaci, ale nebráním se ani prvoplánově vtipné hře.</p>\r\n</div>\r\n\r\n\r\n\r\n<!------- UGY -------->\r\n\r\n<div class=\"org\">\r\n    <img class=\"leftOrg\" src=\"soubory/obsah/obrazky/organizatori/ugy150.jpg\">\r\n  \r\n  <div class=\"rightOrg\">\r\n    <div class=\"description\">\r\n      <div class=\"name\">Jiří \"Ugy\" Ugorný</div>\r\n      <div class=\"position\">Wargaming</div>\r\n      <div class=\"contact\">\r\n      <a href=\"mailto:foo@example.com\">foo@example.com</a><br />\r\n    </div>      \r\n    </div>\r\n    <div class=\"aboutButton\">\r\n      <a href=\"#\" onclick=\"ukaz(ugy); return false\">O sobě píše</a>\r\n    </div>\r\n  </div>\r\n</div>\r\n\r\n<div class=\"clear\"></div>\r\n\r\n<div class=\"about\" id=\"ugy\" style=\"display: none;\">\r\n<p>Kolem GameConu jsem v Pardubicích chodil mnoho let, ale nikdy jsem neměl štěstí na to sladit termíny, abych se mohl sám účasnit. To se změnilo v roce 2017 a od té doby jsem na GameConu zažil hromadu zábavy a seznámil se se spoustou skvělých lidí. No a díky vysedávání s těmito lidmi, dlouho do noci, na schodech před Gameconem jsem se najednou ocitl v organizačním týmu.</p>\r\n<p>Hraní s miniaturami se věnuji už od střední školy. Víc než k samotnému hraní jsem vždy tíhnul k modelování a barvení, ale pořádnou bitvu neodmítnu. Je mi celkem jedno jestli moje figurky mají meče nebo laserové pušky a jestli jsou to vojáčci, ohromní roboti a nebo roztomilá zvířátka.</p>\r\n<p>Doufám že si na Gameconu oblíbíte wargaming stejně jako já.</p>\r\n</div>\r\n\r\n\r\n\r\n\r\n<!-- nemazat -->\r\n\r\n<script>\r\nfunction ukaz(e) {\r\n    e.style.display = e.style.display == \'none\' ? \'block\' : \'none\'\r\n}\r\n</script>', 0),
(50, 'o-bonusech-na-gc', '#Akční hry a bonusy\r\n\r\nNechcete celý GameCon prosedět mezi čtyřmi stěnami? Akční a bonusové aktivity vás umí pěkně smáčet, slušně vyčerpat, ovšem bez zapojení mozkových závitů se neobejdete. Jsou to právě všechny letní, lehké a nenáročné hry, které neodmyslitelně patří k prázdninám i ke GameConu. Šifrovačky, vodní bitvy, laserové přestřelky a mnohé další.', 0),
(69, 'o-wargamingu-na-gc', '#Wargaming\r\n\r\nZatoužili jste někdy stát v čele armády, vést ji do boje s odhodlaným nepřítelem? Nemáte chuť kvůli tomu vstupovat do armády a projít si celým žebříčkem od vojína až ke generálovi? Ve wargamingu se můžete generálem armády na chvíli opravdu stát.\r\n\r\nWargaming jsou bitvy s překrásnými miniaturami a členitým herním plánem (terénem), jenž vám dovolí odehrát jakoukoliv bitvu, kterou si dokážete představit. Každá hra má mírně odlišná pravidla a obvykle sáhnete po menším metru i kostkách.', 0),
(74, 'gamecon/cajovna', '#Čajovna\r\n\r\n\r\nCo to vlastně je, ta čajovna? Někomu jako odpověď postačí, že je to místo, kde se konzumuje čaj. Je to sice odpověď pravdivá, ovšem hodně suchá a značně neúplná.\r\n\r\nČajovna může, a v historických dobách i současnosti i měla, mít hodně podob a o žádné z nich není možno říci, že je ta jediná pravá. Je jedno jestli je to jenom kotlík na vodu a pár misek, jeden hrnek a ponorná spirála, vyhrazený pavilon v japonské zahradě nebo objekt velikosti hangáru se stočlennou obsluhou.\r\n\r\nMnohem důležitější než místo a vybavení je schopnost vytvořit prostředí, kde se návštěvníci cítí dobře a v bezpečí, mohou se uvolnit, klábosit, jen tak přemýšlet, v klidu řešit spory, nebo uzavírat obchody. Místo, kde se návštěvníci mohou bavit, nechat se bavit i bavit jiné. Místo, kam se rádi vrátíte i když bude jindy, jinde a jiné.\r\n\r\nNemusíte do čajovny přijít popíjet čaj. Nemusíte mít o čaji znalosti čajového mistra. Nemusíte o čaji vědět nic, aby vás tam vpustili. Nemusíte vědět ani co to ten čaj vlastně je, a jaký je rozdíl mezi čajem, odvarem a lektvarem. Dokonce nemusíte ani mít čaj rádi, a přesto budete vítáni.\r\n\r\nČaj má mnoho staletí dlouhou historii a za ta staletí bylo vynalezeno mnoho způsobů jak ho pěstovat, zpracovávat, připravovat, podávat, popíjet, psát o něm verše, malovat obrazy ... jak se chovat v čajovně, u čaje, k čaji.\r\n\r\nTo všechno můžete pustit z hlavy a přijít do čajovny si jen tak posedět a nechat myšlenky volně plynout. Můžete si poklábosit s bytostmi, které přišli s vámi, i s bytostmi, které sa v čajovně vyskytli i bez vašeho přičinění.\r\n\r\nMůžete spolu s nimi, nebo i sami, hrát, psát, kreslit, tvořit nebo i jen tak přemýšlet, zasnít se a nevnímat svět, nebo se nechat unést atmosférou místa.\r\n\r\nMůžete potkat známé i neznámé písmáky, veršotepce, bardy a bardky, kreslíře, malíře, hráče i pány jeskyní, lidi, elfy, skřítky i potvůrky, vypravěče i posluchače, vědmy i chytráky, bytosti kouzlící i okouzlující.\r\n\r\nMůžete zde oslavit svátky, narozeniny i nenarozeniny, vítězství nebo úspěch. Můžete se účastnit i nějakých těch křtů a vyskytnin, pokud se nějaké vyskytnou.\r\n\r\nTo všechno můžete. A navíc si můžete vychutnat i nějaký ten šálek čaje.\r\n\r\n<p style=\"font-weight: bold; text-align: right;\">Melkor</p>', 0),
(81, 'materialy-2010', '<h1>Materiály 2010</h1>\n\n<h2>Plakáty</h2>\n<div class = \"galerie\"> \n<a href = \"/files/obsah/materialy/2010/gc-plakat-2010.jpg\" rel = \"lightbox[galerie]\" title = \"GC 2010 - plakát\"> \n      <img src = \"/files/obsah/materialy/2010/gc-plakat-2010-small.jpg\" /> \n    </a>\n<a href = \"/files/obsah/materialy/2010/gc-plakat-2010-inv.jpg\" rel = \"lightbox[galerie]\" title = \"GC 2010 - plakát\"> \n      <img src = \"/files/obsah/materialy/2010/gc-plakat-2010-inv-small.jpg\" /> \n    </a>\n</div>\n<p>\n  <ul>\n    <li><a href = \"/files/obsah/materialy/2010/gc-plakat-2010.pdf\">Plakát s černým podkladem</a> - pdf, 0,5 MB</li>\n    <li><a href = \"/files/obsah/materialy/2010/gc-plakat-2010-inv.pdf\">Plakát s bílým podkladem</a> - pdf, 0,5 MB</li>\n  </ul>\n</p>\n\n<h2>GameCon Teaser</h2>\n<object width=\"470\" height=\"265\"><param name=\"allowfullscreen\" value=\"true\" /><param name=\"allowscriptaccess\" value=\"always\" /><param name=\"movie\" value=\"http://vimeo.com/moogaloop.swf?clip_id=12709571&amp;server=vimeo.com&amp;show_title=1&amp;show_byline=1&amp;show_portrait=0&amp;color=&amp;fullscreen=1\" /><embed src=\"http://vimeo.com/moogaloop.swf?clip_id=12709571&amp;server=vimeo.com&amp;show_title=1&amp;show_byline=1&amp;show_portrait=0&amp;color=&amp;fullscreen=1\" type=\"application/x-shockwave-flash\" allowfullscreen=\"true\" allowscriptaccess=\"always\" width=\"470\" height=\"265\"></embed></object>\n\n<h2>Motiv</h2>\n<p>\nLeitmotivem letošního GameConu je hledání nové země.\n</p>\n<div class = \"galerie\"> \n<a href = \"/files/obsah/materialy/2010/gc-motiv-2010.jpg\" rel = \"lightbox[galerie]\" title = \"GC 2010 - motiv\"> \n      <img src = \"/files/obsah/materialy/2010/gc-motiv-2010-mensi.jpg\" /> \n    </a>\n</div>\n\n<h2>Trička</h2>\n<p>\nI tento rok budou k dostání trička s motivem GameConu. Můžeš si je objednat v <a href = \"/gamecon/prihlaska\">přihlášce na GC</a>, kde si také můžeš zvolit, o jakou velikost máš zájem.\n</p>\n<div class = \"galerie\"> \n<a href = \"/files/obsah/materialy/2010/triko-2010.jpg\" rel = \"lightbox[galerie]\" title = \"GC 2010 - tričko\"> \n      <img src = \"/files/obsah/materialy/2010/triko-2010-mensi.jpg\" /> \n    </a>\n<a href = \"/files/obsah/materialy/2010/triko2-2010.jpg\" rel = \"lightbox[galerie]\" title = \"GC 2010 - tričko\"> \n      <img src = \"/files/obsah/materialy/2010/triko2-2010-mensi.jpg\" /> \n    </a>\n</div>\n\n\n<h2>Bannery</h2>\n<p>\nPokud byste nám chtěli pomoci s propagací GameConu a můžete třeba na svůj web umístit náš banner, budeme jen rádi. Můžete k tomu použít některý z našich bannerů:\n</p>\n<p>\n  <ul>\n    <li>Banner 486px x 60px</li>\n  </ul>\n  <img src = \"/files/obsah/materialy/2010/gc-velky.gif\" />\n  <ul>\n    <li>Banner 234px x 60px</li>\n  </ul>\n  <img src = \"/files/obsah/materialy/2010/gc-stredni.gif\" />\n  <ul>\n    <li>Ikonka  88px x 31px</li>\n  </ul>\n  <img src = \"/files/obsah/materialy/2010/gc-maly.gif\" />\n  <ul>\n    <li>Userbar 350px x 19px</li>\n  </ul>\n  <img src = \"/files/obsah/materialy/2010/userbar.gif\" />\n</p>', 0),
(103, 'chci-se-prihlasit', '# Chci na GameCon\r\n\r\nSpuštění přihlášek začne  \r\n11. 5. 2023 ve 20:23\r\n\r\nPrvní vlna programu bude spuštěna  \r\n18. 5. 2023 ve 20:23\r\n\r\n\r\nDruhá vlna programu bude spuštěna  \r\n8. 6. 2023 ve 20:23\r\n\r\nTřetí vlna programu bude spuštěna  \r\n1. 7.  2023 ve 20:23\r\n\r\n![](https://gamecon.cz/soubory/obsah/obrazky/contract.svg)\r\n\r\n## Jak se přihlásit?\r\n\r\nStačí se zaregistrovat (vpravo nahoře) a po spuštění přihlašování vyplnit [přihlášku](https://gamecon.cz/prihlaska). Další důležité informace k fungování přímo na festivalu viz [Praktické informace](https://gamecon.cz/prakticke-informace).\r\n\r\n## Jak se přihlásit na jednotlivé aktivity v rámci GC?\r\n\r\nNa všechny aktivity se můžeš přihlásit skrze stránky jednotlivých linií na hlavní stránce, nebo přes [Program](https://gamecon.cz/program). Jedinými výjimkami jsou:\r\n\r\n-   **Deskoherna**  \r\n    Do deskoherny není třeba se nijak přihlašovat, stačí prostě přijít a hrát. Vstupné do ní je zcela dobrovolné.\r\n-   **Týmové aktivity** (např. MDrD nebo LKD)  \r\n    Můžeš založit nový tým (družinu) a do tří dnů vyplnit ID či jména svých spoluhráčů. Pokud tak neučiníte, tým (družina) se po třech dnech otevře k veřejnému přihlašování ostatních účastníků.\r\n\r\n## Kolik stojí GameCon?\r\n\r\nNa GameConu **není vstupné**, festival tak můžeš zažít celý zcela **zdarma**. Zaplatíš jen aktivity, ubytování a jídlo, které si reálně **objednáš**. Deskoherna, přednášky a doprovodný program jsou přístupné zdarma!\r\n\r\n## Platbu je třeba uhradit do 30. 6. 2023\r\n\r\nPokud nebudeš mít **30. 6. 2023** na svém účtu dostatek financí, budeme tě muset z festivalu **odhlásit**. Vždycky doporučujeme poslat si radši na účet o něco víc peněz, než reálně potřebuješ, ulehčíš tím sobě i Infopultu na místě. Případný přeplatek ti vrátíme. \r\n\r\n**9. a 16. 7. 2023** probíhá další odhlašování, pokud nebudeš mít na účtu dostatek financí. Buď tě rovnou odhlásíme, případně ti budeme rušit objednávky – jídlo, ubytování i aktivity tak, aby tvůj účet nebyl v mínusu. \r\n\r\nU aktivit se tedy vyplatí sledovat i již obsazené aktivity po těchto termínech – můžeš získat uvolněné místo.\r\n\r\nV případě ubytování doporučujeme objednat si ho a zaplatit včas, protože kapacita ubytování na pokojích není neomezená.\r\n\r\nTrička je možné objednat do **23. 6.**, poté je posíláme do tisku a objednávky už není možné měnit. Ostatní předměty lze objednávat do **9. 6.**, jídlo a ubytování až do **16. 7.**, ubytování lze později rezervovat e-mailem nebo na místě na Infopultu, ale pouze do vyčerpání míst.\r\n\r\nPočítej prosím s tím, že ubytování a jídlo zajišťujeme (a platíme) podle potřebné kapacity. Pokud si tedy ubytování nebo jídlo objednáš a nedorazíš, nebude možné peníze vracet.', 0);
INSERT INTO `stranky` (`id_stranky`, `url_stranky`, `obsah`, `poradi`) VALUES
(105, 'prakticke-informace', '# Praktické informace\r\n\r\nGameCon letos proběhne v datu **20. - 23. 7. 2023**\r\n\r\nInformace o programových vlnách najdete [zde](https://gamecon.cz/chci-se-prihlasit).\r\n\r\nStejně jako minule jsme pro vás připravili [orientační brožurku](https://gamecon.cz/soubory/obsah/materialy/2022/Brozurka_2022.pdf) se všemi důležitými informacemi, mapkami, odkazy a kontakty. Ta letos *nebude* tištěná, takže si ji prosím stáhněte do svých telefonů - ať ji máte skutečně po ruce, až ji budete potřebovat! \r\n\r\nMapu areálu si můžete stáhnout zvlášť [tady](https://gamecon.cz/soubory/obsah/materialy/2022/mapka.jpg).\r\n\r\n## Příjezd a registrace\r\n\r\n\r\n-   **GameCon** probíhá v **Pardubicích**, v areálu **Domova mládeže** a v **Kulturním domě Dukla.** \r\nAdresa je _Gorkého 2573, Pardubice_.\r\n\r\n-   Z _vlakového nádraží_ se na místo dostaneš autobusem č. 6 (zastávka Dukla, KD) či pěšky podle této <a href=\"https://goo.gl/maps/q8GQ1a4Um3KXzcDz8\" target=\"_blank\">mapy</a>. Při přepravě _autem_ je k dispozici malé parkovistě a okolní ulice. Při parkování buď, prosím, ohleduplný/á vůči místním.\r\n    \r\n-   Po příjezdu se ze všeho nejdříve zaregistruj na **Infopultu**. Bez registrace není možné se účastnit aktivit.\r\n **Je otevřen od 8:30** (ve čtvrtek od 12:00) a **zavírá ve čtvrtek a pátek ve 21:00, v sobotu ve 20:00 a v neděli v 17:00**.\r\n    \r\n-   Pokud máš jakýkoliv problém nebo otázku, vždy se můžeš zastavit na Infopultu.\r\n\r\n## Ubytování a stravování\r\n\r\n- __Ubytování i jídlo si můžeš objednat v [přihlášce](https://gamecon.cz/prihlaska).__\r\n\r\n-   Ubytování je **v rámci areálu** na pokojích Domova mládeže (internátní typ, tj. společné toalety a sprchy jsou k dispozici na patře, na pokojích jsou polštáře, peřiny a ložní prádlo).\r\n    \r\n-   **V přihlášce se vždy objednává pouze postel na pokoji** (tj. ne celý pokoj) a každý účastník, který chce ubytování na pokoji si ji musí v přihlášce objednat sám. V přihlášce je rovněž možnost uvést s kým chcete být na pokoji (pokud to bude možné, pokusíme se tomu vyhovět). \r\n\r\n- Klíč od pokoje je bohužel vždy jen jeden, proto ho prosím **vždy nechávej na vrátnici** (ztráta klíče = 1 600 Kč).\r\n    \r\n-   Stravování:\r\n    \r\n    -   Můžeš si u nás předem objednat **snídaně, obědy i večeře** v [přihlášce](http://gamecon.cz/prihlaska). Jídelníček nalezneš [zde](https://gamecon.cz/jidelnicek). Snídaně jsou od 8 do 10, obědy od 12 do 14 (v neděli 13 - 15) a večeře od 17.30 do 19.30, tak je neprošvihni!\r\n        \r\n    -   Můžeš si vařit. Na každém patře jsou k dispozici společné **kuchyňky** vybavené lednicí, mikrovlnkou a rychlovarnou konvicí, nejsou vybaveny vařičem ani nádobím.\r\n        \r\n    -   Můžeš se najíst a nakoupit si ve městě. Připravili jsme pro tebe [mapku restaurací a obchodů](http://gamecon.cz/soubory/obsah/obrazky/Mapa_expand.pdf) v okolí.    \r\n\r\n\r\n## Aktivity\r\n\r\n\r\n- __Srazy na aktivity jsou u maskotů jednotlivých sekcí__ (najdeš je v mapce areálu po registraci). Zde buď **nejpozději 15 minut před začátkem aktivity**.\r\n\r\n- Pokud nebudeš na místě 15 minut předem a nepodaří se nám ti dovolat, tvé místo propadne a nabídneme ho náhradníkům.\r\n    \r\n   \r\n-   Pokud chceš jít na aktivitu jako _náhradník_, stačí 10 minut před začátkem aktivity postávat u nápisu „Náhradníci“.\r\n    \r\n-   Pokud se z aktivity odhlásíš méně než 24 hodin předem, vrací se 50% z ceny. V případě, že na aktivitu nedorazíš, propadá celá cena aktivity.\r\n        \r\n\r\n## Nezletilí a děti\r\n\r\n-   Pokud je ti **méně než 15 let**, zašli nám předem scan podepsaného [souhlasu rodičů](https://gamecon.cz/soubory/obsah//materialy/2023/souhlas_rodicu_2023.pdf) s účastí na GC a to na náš [email](mailto:foo@example.com).\r\n\r\n- Při výběru aktivit se podívej na jejich **věkový limit** (u každé aktivity je štítek s minimálním věkem). Pokud jsi pod daným věkovým limitem, ale myslíš si, že bys hru zvládl/a, zkus se spojit přímo s šéfem příslušné sekce (viz [Kontakty](https://gamecon.cz/kontakty)) a domluv se přímo s ním - případně se ozvi šéfovi Programu [sirienovi](mailto:foo@example.com).\r\n\r\n-   Není problém účastnit se aktivity se svým dítětem, pokud si ji jdeš taky zahrát (a dítě splňuje věkový limit. Pokud chceš na dítě během aktivity jen dohlížet, je **nutné** se **předem** skrze šéfa sekce domluvit s vypravěčem, zda to je možné. Pokud ne, je potřeba přání vypravěče respektovat.\r\n\r\n- Když si na GameCon vezmeš opravdu malé dítě, které se nebude účastnit aktivit či vyžadovat vlastní postel, nemusíš ho vůbec registrovat. Pokud si chceš v rámci rodičovské pomoci domluvit např. vzájemné hlídání, můžeš k tomu využít naší <a href=\"https://www.facebook.com/groups/gamecon\" target=\"_blank\">FB skupinu</a>.\r\n\r\n\r\n## Na GameConu\r\n\r\n### <span style=\"color:red\">Důležité kontakty</span>\r\n\r\n- **Infopult:** Máš (nejen provozní) problém? Na Infopultu ti pomůžou, nebo tě případně dokážou nasměrovat dál. Pokud jsi v nouzi, nebo už mají po zavíračce, volej na <a href=\"tel:+420735513899\">+420 735 513 899</a>.\r\n\r\n- **Zdravotník:** Jsi raněn? Na GameConu máme zdravotníka. Sehnat ho můžeš buď přímo na čísle <a href=\"+420735540479\">+420 735 540 479</a>, nebo přes Infopult. \r\n\r\n- **Spřízněná duše:** Zažil/a jsi tu něco nepříjemného / není ti dobře, a chceš si o tom popovídat? V takovém případě dej vědět naší Spřízněné duši. Volat můžeš na <a href=\"+420705943002\">+420 705 943 002</a>. Na druhé straně najdeš Míšu, která ti moc ráda pomůže. Opravdu. A všechno, co jí řekneš bude důvěrné, pokud nebudeš chtít jinak. \r\n \r\n### Pravidla účasti:\r\n\r\n- **Nebuď debil.**\r\nPokud tě napadne něco zajímavýho, nejdřív se zamysli, než to uděláš. Zejména večer... Prostě a jednoduše se chovej bezpečně a slušně jak k sobě tak k ostatním a pokud si nejsi jistý/á, jestli je něco v pohodě, tak se radši zeptej a respektuj odpověď (platí i pro fyzický kontakt). \r\n\r\n- Pomoz nám udržovat pořádek.\r\n\r\n- Pamatuj na noční klid a na spící účastníky.\r\n    \r\n- **Alkohol pij jen tolik, abys neporušoval/a předchozí pravidla a nebylo ti špatně.**\r\n\r\n\r\n**V případě nutnosti může být účastník vyloučen vypravěčem z aktivity nebo organizátorem z festivalu, a to i bez udání důvodu.**  ', 0),
(110, 'jidelnicek', '#Jídelníček\r\n \r\nStravování bude letos zajištěno komplexně na zahradě Kulturního domu - tj. klasicky objednané snídaně, obědy i večeře a současně tam bude dostupné celodenní občerstvení. Musíme však upozornit, že pouze ti, co si jídlo objednají dopředu mají zaručeno, že se nají. U ostatního občerstvení k prodeji na místě nelze úplně předvídat jeho dostupnost.\r\n\r\nNabídka jídel k objednání předem bude řešena obdobně jako dosud, tj. snídaně formou bufetu a na obědy i večeře bude výběr z několika jídel (včetně jednoho vegetariánského) s tím, že se rezervuje pouze stravenka a nikoliv konkrétní jídlo z nabídky.\r\n\r\n**Bližší jídelníček se zatím připravuje a bude k dispozici nejpozději do konce června. Jídla si můžete objednávat již nyní a svou volbu můžete upravit kdykoliv až do 16.7.**\r\n', 0),
(116, 'legendy-klubu-dobrodruhu', '#Legendy Klubu Dobrodruhů\r\n\r\nProvázané hraní RPG v prostředí [Příběhů Impéria](http://imperium.mytago.cz/) (viz níže), v němž jeden příběh tvoří společně několik vzájemně se ovlivňujících skupin. Hraní je rozděleno na dvě kola - na první část vámi vytvořeného příběhu navazuje jiná skupina (a vy zase na ni).\r\n\r\n**Systém ani prostředí nemusíte znát!** Oboje je velmi snadné a bude vysvětleno na začátku prvního kola. Nejde toliko o soutěž (i přesto, že nějaká vyhlášení budou) jako spíše o samotný zážitek provázaného otevřeného hraní.\r\n\r\n## Herní běhy (čt+pá) / (pá+so)\r\n\r\nKaždý herní běh obsahuje dvě hry, každou s jiným vypravěčem, volíš si první hru.\r\n\r\n- 1. běh (čt+pá), tj. hraje se ve čtvrtek 19:00–23:00 a v pátek 14:00–18:00\r\n- 2. běh (pá+so) tj. hraje se v pátek 19:00–23:00 a v sobotu 14:00–18:00\r\n\r\n---\r\n\r\n<blockquote>\r\nProsíme - nehrajte oba běhy. Dejte možnost si Legendy zahrát dalším. Děkujeme. \r\n</blockquote>\r\n', 0),
(124, 'o-epickych-deskovkach', '#Epické deskovky\r\n\r\nVždy vás lákaly deskovky v obrovské krabici s hromadou krásných součástek, ale odrazovala vás složitá pravidla? Nemusíte nic studovat, náš vypravěč vám hru vysvětlí a dohlédne na její hladký průběh (vyjma těch pro pokročilé). Epické deskovky bývají značně interaktivní, obsahují prvky konfliktu a diplomacie, jistou roli hraje náhoda. Spíše než na herní mechaniky je důraz kladen na atmosféru, hra obvykle zpracovává určité téma v oblasti fantasy, sci-fi nebo historie a nabízí tak hlubší herní zážitek.', 0),
(127, 'en', '#Welcome\r\n\r\n\r\n###...to the website of GameCon, the oldest and biggest Czech festival of non-computer games and active entertainment.\r\n\r\n_What feels like ages ago, we started attracting people from abroad and we were working on broad support of an English program and international attendance. Then, the Firenation at... COVID happened :/ Despite of that, we are happy to welcome you and there is still plenty of fun to be had, even if you don\'t speak Czech!_\r\n\r\nGameCon is a 4-day long summer event for anyone who loves fun and non-computer games of any kind: Boardgames, PnP RPGs, LARPs, Wargaming, social games, party games or anything similar or in between. On top of that, we also throw some parties and a concert, since we consider GameCon to be both convention and a festival and we actively support both of these aspects of the event. It doesn\'t matter if you are a hardcore or a casual gamer - we do have plenty for anyone. Check out one of our <a href=\"https://www.youtube.com/watch?v=-SBu7WGPkO4\">videos</a> to see what we mean.\r\n\r\n\r\n### When\r\n\r\nEvery year from Thursday to Sunday in second half of July (see the main page).\r\n\r\n*(It\'s always the second whole weekend from the end of July, but some people find it difficult to calculate ;))*\r\n\r\n\r\n### Where\r\n\r\n in  [Pardubice, Czech Republic](https://www.google.com/maps/dir/Pardubice+hlavn%C3%AD+n%C3%A1dra%C5%BE%C3%AD,+n%C3%A1m%C4%9Bst%C3%AD+Jana+Pernera,+530+02+Pardubice,+%C4%8Cesk%C3%A1+republika/50.0252323,15.7646619/@50.0294525,15.7667269,16z/data=!4m9!4m8!1m5!1m1!1s0x470dccbb9ecc6693:0x32e2f2a6eb536849!2m2!1d15.7571401!2d50.0323995!1m0!3e2) (that is less than an hour by train from Prague). \r\n\r\n\r\n### English program FOR you\r\n\r\nFeel free to visit boardgame hall or concert - none of that requires to speak Czech :) .\r\n\r\nAlthough we had to back off from active support of English program, there are nonetheless some English activities every year (offered by us or our foreign GC visiting friends) - and many activities might be accessible to English speakers no matter they are officially played in Czech.\r\n\r\nCheck out program sections and look for activities described in English (turning the automatic page translation off first helps) and/or activities having the \"Eng only\" label. There are usually at least some RPGs and Epic boardgames in English.\r\n\r\nEspecially in Epic boardgames and Action games sections there are many activities which are accessible for English speakers as well - but it is often not stated in their description. Just check what you like and ask us (preferably on Discord, but you may try e-mail as well. Or Facebook.)\r\n\r\n\r\n### English program FROM you\r\n\r\n**GameCon Wants YOU to offer your favourite games!**\r\n\r\nLet us know what you\'ve got and we will find a place for it! Players will then come on their own, don\'t worry about that. (You can contact any of us anywhere - we will pass it on to the relevant person.)\r\n\r\n\r\n### Contact us!\r\n\r\nIf you need help or explanation or if you have questions or whatever, contact us!\r\n\r\n**Our official communication channel** is an e-mail foo@example.com\r\n\r\n**[Discord](https://discord.gg/fpanxCfEVM)** is our preferred way of communication, though. Just come to [our server](https://discord.gg/fpanxCfEVM) and don\'t mind it being in Czech, just write in English. (RED users are GC organizers, \"chit-chat\" channel is for chatting and \"otázky a pomoc\" are \"questions and help\".)\r\n\r\nWe do have Facebook and Instagram too and feel free to use it if you wish, but our response time might be slower.\r\n\r\n### Attendance\r\n\r\nIn order to attend, you need to:\r\n\r\n- First, make an account on our website\r\n- THEN you have to fill the application form for the current year\r\n- then you can apply for activities. Most activities have limited capacity and are booked long in advance, but some are (virtually) unlimited or offered just shortly before GameCon takes place\r\n- ...and then you have to pay it in advance via bank transfer.\r\n\r\nUnfortunately, our web is currently not multi-lingual, but there should be no problem to go through everything using standard page translation offered by all contemporary web browsers.\r\n\r\n**Younger visitors** should keep an eye for age restriction tags for activities. These are (with just a few exception) more of a guideline - if you feel you are mature enough for the game despite being younger, let us know and we will see what can be done. **If you are under 15**, your legal guardians must sign our attendance consent form.\r\n\r\n**Price:** GC is entry-free, you pay only for services (accommodation, food etc.) and for specific games (most of them, some are free as well - mainly whole boardgame hall). Price of a game varies between 2-10 EUR, price for the whole GameCon can vary between cca 60-120 EUR with everything for whole 4 days.\r\n\r\n**Accommodation** is in standard Czech high-school boarding house, which you can picture as a really good and more private hostel or as a ~2* hotel without a service. Rooms have 2 or 3 beds and there are shared toilets and showers on the floor. \r\n\r\n**Food:** We offer a possibility to order food in advance (but only in advance). There is a choice from more options on place, but you can\'t book your choice beforhead. Vegetarian options are available, but not guaranteed - you have to get them before others eat them out. (It is usually not much of a problem if you don\'t come really too late.)\r\n\r\n\r\n### On site\r\n\r\n**Literally first**, please find \"Infopult\" (=Infodesk) and register as present. You can\'t attend anything without it. \r\n\r\n**Help:** If you ever need help, assistance, information or whatever, Infopult is the place to go. During GameCon, Infopult can be also reached at +420 735 513 899. Or just find anyone in RED GameCon T-shirt. \r\n\r\nThere is a medic present at all times. GC-Medic crisis number is +420 735 540 479, Czech medical crisis number is 155 (or 112 for general emergencies). We also have a stress-consultant (female certified psychologist) who can be reached on +420 705 943 002. \r\n\r\n**Color coding** is present on wrist-tape tickets and on GC T-shirts. **RED** means main organizers. We can and will help you with anything. **ORANGE** are staff. They can help you with their area of responsibility (mainly Infodesk, Board game instructors) and they can find us for anything else. **BLUE** are gamemasters or volunteers. Most of them can help you or contact us. Anything else are regular visitors - some regulars might be able to help you and asking doesn\'t cost anything - we are friendly community ;) .\r\n\r\n**To attend activity**, go to the shared meeting point **and be there 15 minutes in advance**. \r\n\r\n**Rules:** \r\n\r\n- **1)** Don\'t be an ass. \r\n- **2)** Help us to keep GC clean. \r\n- **3)** Respect night peace (22-06h) and sleeping visitors. \r\n- **4)** Drink only so much so you are able to keep rules 1-3 and avoid sickness. \r\n\r\nWe are entitled to expel anyone without a reason or a compensation.\r\n\r\n\r\n**Safety:** Czech Republic is a very safe country (it is in world\'s top 10) and GameCon is quite peaceful event (well, figuratively, at least...), so don\'t worry. Be warry of your more valuable possessions though - although there is no history of theft on GameCon, it\'s better not to test it. ', 0),
(128, 'legal', '# Informace o zpracování osobních údajů\r\n\r\nDrahá účastnice, drahý účastníku, odesláním své přihlášky dáváš najevo, že máš zájem se zúčastnit festivalu GameCon („**Festival**\"). Vzhledem k tomu musíme zpracovávat Tvé osobní údaje. Tento krátký text slouží jako základní informační materiál, ve kterém se dozvíš vše podstatné.\r\n\r\nTvé osobní údaje uvedené v přihlášce zpracováváme my, tedy zapsaný spolek GameCon, se sídlem Pernického 825/9, 199 00, Praha 9 Letňany , IČ 227 25 474 („**GameCon**“) za účelem Tvé účasti na akcích pořádaných spolkem GameCon. Právní základ pro toto zpracování je splnění smlouvy, která mezi námi vznikla (tedy Tvá přihláška na Festival). \r\n\r\nJinými slovy, Tvé osobní údaje uvedené v přihlášce jsou nezbytné pro to, aby Festival mohl v pořádku a úspěšně proběhnout – například budeme Tvé osobní údaje používat pro vytvoření seznamu hráčů, nebo proto abychom Tě kontaktovali před hrou (pokud by Tě zajímala právničina, jedná se o čl. 6, odst. 1 písm. b) Obecného nařízení o ochraně osobních údajů č. 2016/679, dále jen „Obecné nařízení“). Tvé osobní údaje můžeme předat třetím osobám, jako jsou konkrétní uvaděči aktivit, nebo ubytovací zařízení. Bude se tak dít opět jen na základě Tvé přihlášky a požadavků, které v ní uvedeš. Přesný přehled třetích osob je Ti zdarma k dispozici dotazem zaslaným na e-mailovou adresu <a href=\"mailto:foo@example.com\">foo@example.com</a>. \r\n\r\nSchválením těchto podmínek souhlasíš s uchováním osobních údajů mezi jednotlivými ročníky. Jedná se o souhlas se zpracováním Tvých osobních údajů udělený na dobu neurčitou za účelem uchování Tvého účastnického profilu, takže ho nebudeš muset opakovaně zakládat pro příští ročníky. Tento souhlas můžeš kdykoli bezplatně odvolat písemnou žádostí doručenou na e-mailovou adresu <a href=\"mailto:foo@example.com\">foo@example.com</a>. Pokud svůj souhlas odvoláš, provedeme anonymizaci Tvých osobních údajů v naší databázi a ponecháme si za účelem zachování statistik jen takové údaje, podle kterých není možnost Tě identifikovat (odvolání souhlasu se však netýká údajů potřebných pro realizaci GameConu nebo těch, které musíme ze zákona po určitou dobu uchovávat).\r\n\r\nPro oba výše zmíněné případy zpracování osobních údajů pak platí, že se na nás kdykoli můžeš obrátit (opět na adresu <a href=\"mailto:foo@example.com\">foo@example.com</a>), pokud bys chtěl/a ke svým osobním údajům přístup (dle čl. 15 Obecného nařízení), pokud bys chtěl/a osobní údaje opravit nebo smazat (dle čl. 16 a 17 Obecného nařízení), a nebo pokud bys chtěl/a omezit zpracování osobních údajů (čl. 18 Obecného nařízení).\r\n\r\nTaké bychom Tě rádi informovali o tom, že Ti budeme párkrát do roka posílat náš Newsletter s informacemi o příštích ročnících Festivalu, případně dalších nabídkách. Můžeme to dělat, protože jsi uvedl svoji emailovou adresu při registraci na Festival (opět, pokud by Tě zajímala právničina, jedná se o § 7 odst. 3 zákona č. 480/2004 Sb., o některých službách informační společnosti). Zasílání našeho Newsletteru můžeš kdykoli odmítnout, když napíšeš na e-mailovou adresu <a href=\"mailto:foo@example.com\">foo@example.com</a>, případně klikem na odkaz přímo v e-mailu. \r\n\r\nDíky, a to je všechno. Těšíme se na Tebe na Festivalu!\r\n', 0),
(129, 'soutez', '#Velká soutěž \"Tak se ukaž, pistolníku\" proběhla!\r\n\r\nVážení přátelé, hráči, no prostě všichni návštěvníci GameConu. Proběhla soutěž o skvělé ceny!\r\n\r\n<!----- ##Jak se zapojit?\r\n\r\nLetošní GC bude ve stylu divokého západu. Stačí, abyste nám poslali fotku, video nebo jiný umělecký výtvor ve stylu \"Western\".  \r\n\r\nVaše výtvory nám můžete zaslat na naši [FB stránku](https://www.facebook.com/gamecon) nebo na e-mailovou adresu <a href=\"mailto:foo@example.com\">foo@example.com</a> do __30.6.2018__\r\n----->\r\n\r\nNaše porota složená převážně z indiánů, kovbojů a kavaleristů vybrala tři nejlepší práce a ty ocení parádními cenami:\r\n\r\n__1. místo - Johann Mason__  \r\nHry Great Western Trail + Carcassone: Zlatá horečka  \r\n__2. místo - Roman Dvořáček__  \r\nHra RONE + RONE: probuzení  \r\n__3. místo - Vladimir Cita__  \r\nHra Panovník\r\n\r\n<h2 style=\"text-align: center;\">Uvidíme se v GameTownu!</h2>\r\n\r\n<iframe width=\"552\" height=\"310\" src=\"https://www.youtube.com/embed/PjqSnUyCcM4?rel=0\" frameborder=\"0\" allow=\"autoplay; encrypted-media\" allowfullscreen></iframe>', 0),
(131, 'program-legenda-text', 'Přihlašování na další vlnu aktivit: <b>%PRISTI_VLNA_KDY|datum:FORMAT_ZACATEK_UDALOSTI%</b>', 0),
(133, 'pripravujeme', '#Letos připravujeme\r\n\r\n<style>\r\ntd {width: 80px; text-align: center; padding: 10px;}\r\ntr {border-bottom: 1px solid #bbb;}\r\ntable {border-collapse: collapse;}\r\n.aktivita {font-weight: bold; font-size: 12pt;}\r\n</style>\r\n\r\n<div style=\"height: 40px;\"></div>\r\n\r\nProgram GameConu je prozatím stále v přípravě a přihlašovat se na něj bude možné ve třech větších vlnách.\r\n\r\n##Důležitá data\r\n<table>\r\n<tr style=\"font-weight: bold;\">\r\n<td>14.5. </td><td>20:19</td><td>Zveřejnění programu</td><td style=\"width: 260px;\">50 % aktivit zveřejněno <span style=\"font-weight: normal; font-style: italic; color: #888;\"><br />(některé bez přiřazeného času)</span></td>\r\n</tr><tr>\r\n<td>21.5. </td><td>20:19</td><td>Přihlašování na aktivity</td><td></td>\r\n</tr>\r\n<tr>\r\n<td>11.6. </td><td>20:19</td><td>Druhá vlna aktivit</td><td>75 % aktivit zveřejněno</td>\r\n</tr>\r\n<td>30.6. </td><td>20:19</td><td>Třetí vlna aktivit</td><td>90 % aktivit zveřejněno</td>\r\n<tr>\r\n</tr>\r\n</table>\r\n\r\nPo těchto třech vlnách budou aktivity přibývat pouze jednotlivě.\r\n\r\n##Na co se letos těšit?\r\n<!----- AŽ BUDE JASNO ----\r\nProgram letošního GameConu je teprve v přípravách a v průběhu roku budeme do této sekce postupně doplňovat všechny programové novinky, které se na GameConu 2017 objeví. Prozatím můžeme alespoň něco z těch neprogramových:\r\n\r\nTou největší letošní změnou bude Parcon - nejstarší český con vůbec, který se zaměřuje na literaturu a přednášky. Letos se po mnoha letech vrátí do Pardubic v rámci spolupráce právě s GameConem.\r\n\r\nOpět vás čeká zajímavé zahájení, které se pokusíme vyladit do tématu letošního ročníku, kterým je Umělá inteligence a rádi bychom se více zaměřili i na celohru.\r\n---->\r\n\r\nZnovu se budeme snažit nabídnout snídaně pro všechny účastníky GameConu, nejen pro vypravěče. \r\n\r\nV rukávu toho máme samozřejmě mnohem víc, těšte se hlavně na program, který bude letos opět pěkně našlapný.\r\n\r\n<!--- ![](soubory/obsah/obrazky/pripravujeme-smak.jpg) --->', 0),
(134, 'drd/organizace', '#Organizace Mistrovství v DrD\r\n\r\n![](soubory/obsah/drd/web/2023/organizace.jpg)\r\n<div style=\"color: #666; margin-top: -20px; margin-right: 0px; font-size: 8pt; float: left;\">Obrázek z Pinterest.com od <a href=\"https://pin.it/5i5Sd3a\">(odkaz)</a></div>\r\n\r\n<!------------- DEFINICE STYLU MOŽNO PROMAZAT ----------------->\r\n\r\n<style>\r\n.description {min-height: 108px; max-width: 260px;}\r\n.link:hover {cursor: pointer}\r\n.name {font-size: 14pt; margin-bottom: 18px; font-weight: bold;}\r\n.about {margin-top: 12px;}\r\n.clear {clear: both;}\r\n.radek {margin-top: 6px; margin-bottom: 6px;}\r\n.odsaz {margin-left: 40px}\r\n\r\n@font-face {\r\n	font-family: \"Flaticon\";\r\n	src: url(\"soubory/obsah/fonty/pjove/flaticon.eot\");\r\n	src: url(\"soubory/obsah/fonty/pjove/flaticon.eot#iefix\") format(\"embedded-opentype\"),\r\n	url(\"soubory/obsah/fonty/pjove/flaticon.woff\") format(\"woff\"),\r\n	url(\"soubory/obsah/fonty/pjove/flaticon.ttf\") format(\"truetype\"),\r\n	url(\"soubory/obsah/fonty/pjove/flaticon.svg\") format(\"svg\");\r\n	font-weight: normal;\r\n	font-style: normal;\r\n}\r\n[class^=\"flaticon-\"]:before, [class*=\" flaticon-\"]:before,\r\n[class^=\"flaticon-\"]:after, [class*=\" flaticon-\"]:after {   \r\n	font-family: Flaticon;\r\n        font-size: 20px;\r\n        color: #800;\r\nfont-style: normal;\r\nmargin-left: 6px;\r\n}.flaticon-favourites7:before {\r\n	content: \"\\e000\";\r\n}\r\n\r\n</style>\r\n\r\n<!------------- DEFINICE STYLU ----------------->\r\n\r\n<!--TOTO JE KÓD ZPĚT DO SEKCE-->\r\n\r\n\r\n<table><tr>\r\n<td style=\"vertical-align: top;\">\r\n<img src=\"soubory/obsah/obrazky/arrow-back.png\" style= \"width: 24px;\">\r\n</td>\r\n<td>\r\n<div style=\"margin-top: 2px;\"><a href=\"drd\">zpět do sekce mistrovství v DrD</a></div></td>\r\n</tr></table>\r\n\r\n<!--KONEC KÓDU ZPĚT DO SEKCE-->\r\n\r\n\r\n<!-- SKRYTO \r\n###<span style=\"color: blue\">INFORMACE K ORGANIZACI TURNAJE 2023 PŘIPRAVUJEME</span>\r\n\r\n<!--KONEC KÓDU \r\n**Můžeš si stáhnout celý následující text** k organizaci Mistrovství a další užitečné soubory:\r\n\r\n\r\n- [Organizace Mistrovství v Dračím Doupěti](http://gamecon.cz/soubory/obsah/drd/web/2022/organizace_turnaje_mdrd.pdf) - pdf soubor (<span style=\"color: blue\">aktualizován 24.5.2022</span>).\r\n\r\nSKRYTO -->\r\n\r\n#Dračí doupě\r\nNajde se široko daleko vůbec někdo, kdo by o této legendě neslyšel? Je to možné a tak vám tuto legendu přiblížíme. Dračí doupě je nejstarší původní česká fantasy hra na hrdiny. Hry na hrdiny (známé pod zkratkou RPG z anglického roleplaying games) jsou “stolní” hry, ve kterých se ocitnete v kůži některé z fiktivních postav a společně se spoluhráči vytváříte unikátní příběh. Popisujete činy postav, mluvíte jejich ústy, veškeré prostředí však zůstává ve vaší fantazii, podobně, jako když čtete knihu. A v tomto Mistrovství je tomu nejinak. Fantasy v tomto případě znamená, že se ocitnete ve fiktivním světě, založeném na středověkých reáliích, s prvky magie a nadpřirozena. Jestli takový svět bude podobný spíše tomu z Pána Prstenů, Zaklínače, či třeba Zeměplochy (nebo zda to bude svět neotřelý) záleží na tvůrcích Mistrovství a najdete je v propozicích k [aktuálnímu ročníku](drd/dobrodruzstvi).\r\n\r\n#O Mistrovství\r\nJedná se o turnaj ve hře vycházející z tradic Dračího doupěte (verze 1.6). Projděte se svojí družinou pečlivě připraveným dobrodružstvím, poměřte důvtip a herní um s ostatními soutěžícími a vstupte do [Síně slávy](drd/sin-slavy) mezi legendy.\r\n\r\nSoutěžní dobrodružství tvoří dějově souvislý příběh, který je rozdělen do tří navazujících částí (čtvrtfinále, semifinále, finále). Hraje se vyřazovacím způsobem. **Mezi čtvrtfinále a semifinále vyřadíme 1/3 družin (dle celkového počtu přihlášených družin), do finále postupuje 4-5 nejlepších družin**. Vyhlášení vítězů a předání putovní trofeje probíhá na nedělním zakončení GameConu. Zde si také můžete vyslechnout celý soutěžní příběh a veselé historky z průběhu turnaje.  \r\n\r\nProč se hry zúčastnit? Není to jen soutěž o lákavé ceny a uznání. Jelikož soutěžní dobrodružství poctivě celý rok připravuje a na místě vede tým zkušených a ostřílených Pánů a Paní Jeskyně (PJ), hra bude pro příznivce RPG určitě i neopakovatelným zážitkem. Zúčastnit se mohou úplní nováčci i zkušení hráči. Na své si přijdou obě skupiny. Důležité je dobře se bavit při hraní soutěžního dobrodružství.   \r\n\r\nTak neváhejte a vydejte se do magického světa plného kouzel, fantaskních bytostí, zákeřných intrik a objevujte jeho tajemství a vychutnejte si jeho neopakovatelnou atmosféru.\r\n\r\n**S případnými dotazy** se obraťte [emailem](mailto:foo@example.com) na organizátora Mistrovství [Guffa](http://gamecon.cz/guff). \r\n\r\n#Novinky pro ročník 2023\r\nLetos už definitivně opouštíme svět Slověnů a míříme zpět do *\"klasické\"* fantasy, kde trpaslíci mají vousy, hobiti chlupaté nohy a elfové špičaté uši. Více o reáliích letošního příběhu naleznete v sekci [Informace k dobrodružství](http://gamecon.cz/drd/dobrodruzstvi). Základní parametry:\r\n\r\n- družina se skládá z 5-7 **předpřipravených postav**\r\n- předpřipravené postavy mají určené vše - od jména, rasy, povolání, atributů, přes zvláštní schopnosti, dovednosti, kouzla a vybavení\r\n- předpřipravené postavy mají určené základní motivace v příběhu\r\n- **v případě sporů mezi hráči a PJem či stížností na PJe** je možné se obrátit na [Guffa](http://gamecon.cz/guff), organizátora MDrD, který bude působit jako prostředník při řešení a to buď na místě či [mailem](mailto:foo@example.com).\r\n\r\n#Obecná pravidla\r\nHraje se podle pravidel  **DrD verze 1.6, edice E**. Hrajeme pouze s pravidly pro začátečníky (PPZ) a pokročilé (PPP). **Nelze používat nic z pravidel pro experty (PPE)**. Originální pravidla jsou dnes hůře k sehnání, proto jsme k jejich doslovným znalostem benevolentnější. \r\n\r\n##Hody kostkou a rozhodování o úspěchu akce\r\nFaktor náhody u důležitých událostí vynecháváme. Chceme, aby o postupu rozhodovala jen šikovnost hráčů. Obecně platí, že PJ uzná dobrý nápad, když bude správně hráči popsán. Cílem je budovat atmosféru, udržovat tempo hry a minimalizovat listování v příručkách jen proto, aby se určila správná výše bonusu apod. Vždy jde především o dohodu mezi hráči a PJ. PJ tu není od toho, aby hráče “přechytračil”, hlavním cílem je vždy to, aby hraní bylo příjemné, stejný přístup očekáváme i od hráčů. \r\n\r\n##Soubojový systém\r\nHraje se podle základního soubojového systému. Je na domluvě hráčů s PJem, zda-li pro souboj budou využívat nějaké pomůcky (mapový podklad, figurky atp.). **Při opravách na hod se bere v potaz rozdíl velikostí a bojeschopnost. Vliv naložení pouze v konkrétních případech, bude-li mít smysl**.\r\n\r\nPři soubojích se bere v potaz zranitelnost a odolnost nestvůr vůči různým útokům. Zranitelnost nestvůr se neřídí přesně podle příručky PJ, ale odpovídá reáliím dobrodružství. Neváhej se zeptat PJe, zda-li tvá postava o nestvůře něco neví, či se s ní dokonce někdy setkala.\r\n\r\nBoj pod širým nebem se snažíme hodnotit podle základního soubojového systému či pomocí hodů na past či pravděpodobnost, či dohodou mezi hráči a PJem.\r\n\r\n##A mimo boj\r\nPro **pohyb postav** mají PJové vlastní zjednodušená pravidla, která neodpovídají oficiálním pravidlům. Je tomu tak proto, aby hra plynula a více času se věnovalo důležitějším pasážím dobrodružství. Toto se týká jak pěšího pochodu, tak i při využití dopravních prostředků.\r\n\r\n**Únavu a čas nutný na odpočinek** posuzují PJové podle pravidel a zákonitostí daných dobrodružstvím. Opět z důvodu urychlení hry. Hráči by si měli uvědomit, že odpočinek či dokonce spánek pod širým nebem je velký risk i pro ostřílené dobrodruhy.\r\n\r\n**Vyjednávání s cizími postavami** bude vždy probíhat formou roleplayingu. Schopnosti dané povoláním jsou podpůrnými prostředky při vyjednávání a jejich použití je samozřejmě (kladně) hodnoceno. Nicméně od hráčů se očekává, že budou spoléhat při vyjednávání na svůj roleplaying a použití získaných informací a nikoliv na výsledek hodu kostkou.\r\n\r\n**Systém dovedností** nebude při hře uplatňován. Zda-li umí postava číst, psát, plavat se dozví ze svého osobního deníku. Pokud není tato dovednost v deníku zmíněna, platí, že danou dovednost postava neumí. \r\n\r\n#Družina\r\nTurnaje se neúčastníte jako jednotlivci, ale ve skupině **5-7 hráčů**, která tvoří družinu. Družiny soutěží mezi sebou o to, která lépe, podle daných hodnotících kritérií Mistrovství, projde soutěžním dobrodružstvím. **Větší počet hráčů ve skupině neposkytuje výhodu**.\r\n\r\nBěhem hry může dojít k příběhovému konfliktu mezi jednotlivými postavami v družině. Hráči by neměli zapomínat, že se jedná čistě o konflikt mezi postavami a nikoliv samotnými hráči (!).\r\n\r\nDoporučujeme zájemcům o turnaj v MDrD, kteří nemají vlastní družinu, aby kontaktovali Guffa [mailem](mailto:foo@example.com). Ze zkušenosti z předchozích ročníků turnaje jasně vyplývá, že většina družin se skládá z hráčů, kteří spolu pravidelně hrají, a kteří si chtějí užít turnaj tak, jak jsou zvyklí. Na druhou stranu se každý rok objeví 1-5 single hráčů, kteří při troše dobré vůle můžou vytvořit zajímavou družinu a turnaje se plnohodnotně zúčastnit i s šancí na vítězství.\r\n\r\n\r\n#Postavy\r\nHráč ve družině reprezentuje právě jednu postavu, kterou si vybíra z předem předpřipravených. Postavy č. 1 až č. 5 jsou povinné. Postava č. 6 se uplatní při hře v šestičlenné družině. Postava č. 7 se uplatní při hře v sedmičlenné družině.\r\n\r\n1. Kadir - člověk čaroděj\r\n2. Åge - trpaslík bojovník\r\n3. Tufik - elf sicco\r\n4. Fahim - barbar theurg\r\n5. Násim - hobit chodec\r\n6. Sagir - kudůk lupič\r\n7. Stig - trpaslík bojovník\r\n\r\nVíce informací k historii družiny najdete v osobních denících, dále v sekci  [Informace k dobrodružství](http://gamecon.cz/drd/dobrodruzstvi). Některé informace týkající se historie družiny budou zmíněné i v **Mořešumech** - viz sekce  [Informace k dobrodružství](http://gamecon.cz/drd/dobrodruzstvi).\r\n\r\n**Všechny postavy začínají dobrodružství na 8. úrovni.**\r\n\r\n**Přesvědčení při tvorbě postavy nepoužíváme**, počítáme, že si hráči vytvoří komplexnější charakter postav v souladu s roleplayingovými pravidly mistrovství. Je jen na vás, jak moc pečliví budete. Pokud si vytvoříte zajímavý charakter  a dokážete jej zahrát, hra bude pro vás i PJ o mnoho zábavnější. Oceníme, pokud uvidíme, že se svojí postavou doslova “dýcháte” a není to pro vás jen soubor abstraktních čísel v osobním deníku. Pravděpodobně pro vás potom bude i snažší získat klíčové informace, u kterých předpokládáme použití roleplayingu. Články [\"Mistrovství v DrD: O roleplayingu\"](http://gamecon.cz/blog/mistrovstvi-v-drd-o-rp) a [\"Mistrovství v DrD: Jak si (ne)vytvořit postavu\"](http://gamecon.cz/blog/mdrd-postava) vám mohou při tvorbě pomoci. **Charakter vytvořené postavy by však neměl být v rozporu s předpřipravenými informacemi**.\r\n\r\n##Válečník\r\n**Zastrašení** - uvítáme, když válečníci budou používat i když je pravděpodobnost úspěchu zastrašení nereálně nízká.\r\n\r\n**Poznávání artefaktů** - místo hodů preferujeme roleplaying.\r\n\r\n##Alchymista\r\n**Magenergie a suroviny** -  Během dobrodružství si je alchymista schopen obstarat suroviny za 10 zl. za každý den, který hledání naplno věnuje. Hledání musí probíhat mimo obydlené oblasti. Ve městě nelze suroviny obstarat jinak než nákupem.\r\n\r\nNa předměty vyráběné během dobrodružství se vztahují obvyklá pravidla. **Alchymista nemůže během hry vyrábět “trvalé” předměty z PPZ**.\r\n\r\n**Alchymista nemůže před začátkem dobrodružství** část svých magů a surovin využít k tvorbě alchymistických předmětů. Jakmile PJ dobrodružství uvede, je na alchymistovi, jak své magy a suroviny \"utratí\".\r\n\r\n##Zloděj\r\n**Zvláštní schopnosti zloděje** - uvítáme roleplaying před hodem kostkou tam, kde dochází k interakci s cizí postavou. Ale hráč může využití dané schopnosti určitě zmínit (Hráč oznámí PJi: \"Pokusím se získat důvěru toho strážného...\". A pak roleplayuje, jak se vlísává do přízně strážného).\r\n\r\n**Síť** (sicco) - je jen na hráči, zda-li bude budovat a využívat služeb sítě a kolik do ní investuje peněz. Síť funguje dle pravidel.\r\n\r\n\r\n#Zbraně, zbroj a vybavení\r\n\r\n**Peníze** - Každá postava má na začátku přidělený určitý obnost. Viz osobní deník.\r\n\r\n**Vybavení** - Každá postava má na začátku pevně dané vybavení. S tím vstupuje do hry. Po zahájení s ním může volně nakládat (předat některé vybavení jiné postavě v družině, atp.).\r\n\r\n**Zbraně a zbroj** - Každá postava má na začátku dobrodružství určené zbraně a zbroj. V průběhu dobrodružství může získat nové. Pro jejich použití platí omezení daná pravidly. Postavy mohou mít libovolné množství zbraní a zbroje, nicméně neobvyklé množství musí být hráči schopni obhájit.\r\n\r\n**Magické předměty** - Každá postava má na začátku dobrodružství jeden magický předmět. Viz osobní deník. \r\n\r\n\r\n#Hodnotící kritéria\r\nPři tvorbě dobrodružství se vždy snažíme stanovit objektivní kritéria, podle kterých určují PJové postupující, případně vítěze turnaje. Nicméně není to vždy jednoduché, zvláště, když si družiny vedou dobře. K základním kriteriím jsme napsali [blog](http://gamecon.cz/blog/mdrd-blog). \r\n\r\nNíže naleznete základní pilíře hodnocení:\r\n\r\n**1) Postup soutěžním příběhem (dobrodružstvím)**. Jak dobře postupuje družina příběhem na základě motivace jednotlivých postav a družiny. Zde se hodnotí především reakce družiny v klíčových momentech příběhu. Dále se zde hodnotí sběr a práce s informacemi. Jak si družina dokáže poskládat obrázek toho, o co se v dobrodružství jedná. Dále jak elegantně, efektivně a originálně překoná všechny problémy a překážky, které jí v průběhu hraní vyvstanou.\r\n\r\n**2) Hraní rolí, aneb roleplaying (RP)**. Kritéria, která bereme v potaz při hodnocení RP jsme sepsali v [\"RP pravidlech Mistrovství\"](http://gamecon.cz/blog/mistrovstvi-v-drd-o-rp). Letos jsme do dobrodružství vložili tzv. **roleplay výzvy**. Jedná se o herní scény, které budeme hodnotit na základě roleplaye hráčů.\r\n\r\n**3) Herní čas**. Herní bloky jsou časově omezeny. Jednotlivé části dobrodružství vždy končí určitou událostí (např. nalezením potřebné informace, předmětu), kterou je nutné stihnout za daný herní čas. Nesplnění cíle herního bloku nemusí být nutně důvodem nepostoupení, nicméně je bráno v potaz.\r\n\r\n**Ve čtvrtek od 17:00 proběhne přednáška \"Mistrovství DrD - Hodnocení družin, postupová kritéria a FAQ**, kde se můžou hráči dozvědět bližší informace, jak hodnocení probíhá a doptat se nejasnosti k dobrodružství.\r\n\r\n#Pánové Jeskyně (PJ)\r\nPři registraci si můžete kromě herního bloku zvolit i PJ pro základní kolo. Pro semifinále bude přidělen organizátory turnaje jiný PJ. Stejně jako loni si i letos budou moci družiny určit až dva PJe, se kterými NEchtějí hrát sobotní semifinále. Pokusíme se družinám vyhovět. Ve finále připadnou na každou družinu dva PJ. Informace a herní styl jednotlivých PJ naleznete v sekci [Pánové Jeskyně](drd/pj).\r\n\r\n\r\n\r\n#Kapacita turnaje a délka hry\r\nPředpokládaná maximální kapacita turnaje je 24 družin. Všechny družiny odehrají čtvrtfinálové kolo (čtvrtek, pátek). Do semifinálového kola (sobota) postoupí cca 2/3 nejlepších družin (dle celkového počtu přihlášených družin). K dispozici je 7 PJů na dopolední semifinále a 8 PJů na odpolední semifinále. Nedělního finále se pak zúčastní pouze 4-5 nejlepších družin, které nejlépe zvládly čtvrtfinálové a semifinálové kolo. Čtvrtfinále trvá 4 hodiny, semifinále 5 hodin a finále 4 hodiny.\r\n\r\n**Upozornění:** Vzhledem k omezené kapacitě PJů na jednotlivé semifinálové bloky může dojít k situaci, kdy do semifinále postoupí hůře hodnocená družina na úkor lépe hodnocené družiny. Tato situace může nastat v případě, kdy bude (výrazně) více lépe hodnocených družin chtít hrát v jednom semifinálovém bloku, kde tím pádem nebude dostatek PJů k dispozici. Této situaci nejsme schopni dopředu zabránit. Nevíme dopředu, jak které družiny budou ve čtvrtfinále úspěšné. Naším cílem je, aby do semifinále postoupilo maximum družin a všichni dostupní PJové na semifinále byli vytíženi.\r\n\r\n\r\n\r\n#S sebou\r\n- kostky (k6, k10, k%) - ideálně každý vlastní\r\n- pravidla PPZ, PPP - alespoň jedny na družinu\r\n- vyplněný osobní deník\r\n- psací potřeby a papíry\r\n- občerstvení\r\n\r\n#Ceny pro vítěze\r\nVítězové Mistrovství v Dračím Doupěti získají putovní pohár a zapíší se do [Síně slávy](drd/sin-slavy). Kromě toho získají hodnotné ceny, které dostanou i hráči družin umístěných na 2. a 3. místě.\r\n\r\n\r\n<!--TOTO JE KÓD ZPĚT DO SEKCE-->\r\n\r\n<table><tr>\r\n<td style=\"vertical-align: top;\">\r\n<img src=\"soubory/obsah/obrazky/arrow-back.png\" style= \"width: 24px;\">\r\n</td>\r\n<td>\r\n<div style=\"margin-top: 2px;\"><a href=\"drd\">zpět do sekce mistrovství v DrD</a></div></td>\r\n</tr></table>\r\n\r\n<!------------- NEMAZAT ------------->\r\n<script>\r\nfunction ukaz(id)\r\n{\r\n  $(id).animate({height: \'toggle\'});\r\n}\r\n</script>', 0),
(135, 'drd/prihlaseni', '#Návod na přihlášení\r\n\r\n![](soubory/obsah/drd/web/2023/prihlaseni.jpg)\r\n<div style=\"color: #666; margin-top: -20px; margin-right: 0px; font-size: 8pt; float: left;\">Obrázek z Pinterest.com od <a href=\"https://pin.it/1UhqI3l\">(odkaz)</a></div>\r\n\r\n<!--TOTO JE KÓD ZPĚT DO SEKCE-->\r\n\r\n<table><tr>\r\n<td style=\"vertical-align: top;\">\r\n<img src=\"soubory/obsah/obrazky/arrow-back.png\" style= \"width: 24px;\">\r\n</td>\r\n<td>\r\n<div style=\"margin-top: 2px;\"><a href=\"drd\">zpět do sekce mistrovství v DrD</a></div></td>\r\n</tr></table>\r\n\r\n<!--KONEC KÓDU ZPĚT DO SEKCE-->\r\n\r\n##Upozornění\r\nJakmile kliknete na přihlášení na turnaj v mDrD, je aktivita ve vybraném herním bloku a s vybraným PJem pro ostatní dočasně uzamčena. Zároveň vám začne běžet **72 hodinová lhůta** pro kompletní dokončení přihlášky. Pokud do té doby přihlášení nedokončíte (nekliknete na tlačítko *\"potvrdit\"*), systém přihlášku zruší a nabídne aktivitu v daném herním bloku znovu k dispozici ostatním zájemcům.\r\n\r\n**Během uzamčení můžete pokračovat v přihlašování na jiné aktivity.**\r\n\r\nV případě, že budete potřebovat jakoukoliv pomoc s přihlášením, kontaktuje prosím organizátora Mistrovství na <a href=\"mailto:foo@example.com\">foo@example.com</a>.\r\n\r\n\r\n##Úvodem\r\nMistrovství v DrD je týmová aktivita. Přihlašování týmu (družiny) provádí vždy jeden hráč z týmu - ten, který se jako první přihlásí do daného čtvrtfinálového bloku. **Přihlášení je možné na stránkách aktivity** - [zde](https://gamecon.cz/drd), **či na stránkách programu** - [zde](https://gamecon.cz/program).\r\n\r\n##Výběr PJe\r\nV daném čtvrtfinálovém herním bloku je většinou možné vybrat z vícero PJů. Stačí kliknout na odkaz *\"přihlásit\"* u bloku se jménem vybraného PJe. PJe můžete vybírat pomocí jeho charakteristiky, která je dostupná pro všechny PJe na stránce [Pánové jeskyně](https://gamecon.cz/drd/pj).\r\n\r\nPo zvolení herního bloku, PJe a kliknutí na odkaz *\"přihlásit*\" se objeví formulář k vyplnění. **Hráč má 72 hodin na to, aby formulář vyplnil a přihlášku na turnaj potvrdil**.\r\n\r\nCo je potřeba vyplnit a jak?\r\n\r\n##Název týmu\r\nOproti předchozím ročníkům je toto pole **povinné**. Volte si prosím takový název týmu, za který se nebudete stydět, až vás organizátoři vyvolají na stupně vítězů :-)\r\n\r\n##Výběr dalších kol\r\nSobotní **semifinále** se hraje v ranním a odpoledním bloku. Je potřeba jeden blok vybrat. Nedělní **finále** se hraje pouze v jeden čas.\r\n\r\n**Pozor!** Po zvolení semifinálového a finálového bloku a potvrzení přihlášky stisknutím tlačítka *\"přihlásit\"* již není možné volbu semifinálového bloku změnit!\r\n\r\n##Výběr spoluhráčů\r\nLetos mohou mít týmy (družiny) 5 - 7 členů. Členové se do polí zadávají tak, že se vyplní jejich jméno nebo přezdívka nebo ID. Systém vám bude při vyplňování pole *\"našeptávat\"*.\r\n\r\nPokud je vás v družině méně jak sedm, je potřeba přebytečná *\"místa\"* v družině odebrat v případě, že nechcete, aby se k vám přihlásil někdo cizí. To lze provést kliknutím na odkaz *\"odebrat\"* u posledních třech míst.\r\n\r\n**Poznámka** Po potvrzení přihlášku kliknutím na tlačítko *\"potvrdit\"* je stále možné velikost týmu změnit. Tuto změnu mohou provést všichni stávající členové týmu a to tak, že ve svém programu u příslušného čtvrtfinálového bloku kliknou na trojúhelníček *\"zvýšit/snížit\"* počet členů v družině. Zvýšení je možné jen tehdy, pokud družina má méně jak 7 míst. Zmenšení je možné jen tehdy jsou-li v družině více jak čtyři místa a rušená místa nejsou obsazena členy. **Nelze \"vyhodit\" z družiny jiného člena!**.\r\n\r\n**Pozor!**\r\n\r\n- týmoví spoluhráči musí být **registrováni a přihlášeni** na GameConu, aby mohli být vybráni do týmu.\r\n- členové týmu **nesmějí být přihlášení na jinou aktivitu** v době zvolených herních bloků čtvrtfinále, semifinále a finále Mistrovství v DrD\r\n\r\n##Tlačítko potvrdit\r\nJakmile \"*zakladatel*\" družiny vyplní název týmu, vybere čas semifinále a čtvrtfinále a určí zbývající členy družiny, může kliknout na tlačítko *\"potvrdit\"*. Tím  formálně přihlásí celou družinu na Mistrovství a všem spoluhráčům přijde email potvrzující členství v družině.\r\n\r\n**Poznámka**\r\nDokud hráč *\"zakladatel\"* neklikne na tlačítko potvrdit, může vyplňování formuláře přerušit a v jeho vyplňování pokračovat později. Tj. může se odhlásit z webu GameCon, může zavřít okno prohlížeče atp. Jím zvolený herní blok zůstane zablokován po dobu 72 hodin.\r\n\r\nPokud do té doby nestihne formulář řádně vyplnit a potvrdit, herní blok se opět zpřístupní ostatním zájemcům.\r\n\r\n##Tipy a triky\r\n1) Pokud nechcete v družině hrát s někým cizím ať už z důvodu, že jste dobře sehraná družina či před cizími lidmi se vám hůře hraje, **nikdy nenechávejte volná pole ve vaší družině**.\r\n\r\n2) Pokud rozšiřujete družinu s cílem přihlásit svého kamaráda, je dobré se dopředu domluvit a rozšíření a přihlášení provést v jeden okamžik. Pokud rozšíření družiny a přihlášení nového člena neproběhne bezodkladně, je tu reálná šance, že někdo neznámý se vám přihlásí do družiny na nové (neobsazené) místo. \r\n\r\n3) Před přihlášením družiny je dobré se mezi spoluhráči domluvit, kdy chcete hrát čtvrtfinále a semifinále. V opačném případě hrozí, že některý hráč se přihlásí na jinou aktivitu v době, kdy má hrát Mistrovství v DrD a tuto aktivitu bude muset kvůli Mistrovství zrušit.\r\n\r\n4) Pokud se vám do družiny přihlásí někdo *\"cizí\"* a vy nechcete hrát s někým cizím, je možné to řešit domluvou. Pošlete mi <a href=\"mailto:foo@example.com\">mail</a> a zkusíme to vyřešit.\r\n\r\n5) Pokud nemáte družinu a přesto byste si rádi zahráli turnaj v MDrD, je lepší kontaktovat <a href=\"mailto:foo@example.com\">Guffa</a>, který pak může zkusit dát dohromady všechny volné hráče do jedné družiny. Statisticky víme, že jen málo družin hledá volné hráče.\r\n\r\n<!--TOTO JE KÓD ZPĚT DO SEKCE-->\r\n\r\n<table><tr>\r\n<td style=\"vertical-align: top;\">\r\n<img src=\"soubory/obsah/obrazky/arrow-back.png\" style= \"width: 24px;\">\r\n</td>\r\n<td>\r\n<div style=\"margin-top: 2px;\"><a href=\"drd\">zpět do sekce mistrovství v DrD</a></div></td>\r\n</tr></table>\r\n\r\n<!--KONEC KÓDU ZPĚT DO SEKCE-->\r\n\r\n<!------------- NEMAZAT ------------->\r\n<script>\r\nfunction ukaz(id)\r\n{\r\n  $(id).animate({height: \'toggle\'});\r\n}\r\n</script>\r\n', 2);
INSERT INTO `stranky` (`id_stranky`, `url_stranky`, `obsah`, `poradi`) VALUES
(136, 'drd/archiv', '#Starší dobrodružství\r\n\r\n![](soubory/obsah/drd/web/2022/archiv.jpg)\r\n<div style=\"color: #666; margin-top: -20px; margin-right: -42px; font-size: 8pt; float: left;\">Obrázek z Pinterest.com <a href=\"https://pin.it/57nlHF3\">(odkaz)</a></div>\r\n\r\n\r\n\r\n\r\nNa této stránce si můžete stáhnout některá z dřívějších soutěžních dobrodružství, která se hrála na GameConu. Pracujeme i na zpřístupnění některých dalších, ale bohužel ta starší dobrodružství často nejsou v publikovatelné podobě, popřípadě doznala některých výrazných změn na samotném conu a potřebují upravit (což je po těch letech trochu těžký oříšek).\r\n\r\nDobrodružství si smíte stáhnout pro vlastní potřebu a hru s přáteli. Bez souhlasu autora nebo GameConu je však nesmíte jakkoli komerčně využívat, hromadně šířit nebo zpřístupňovat širší veřejnosti.\r\n\r\n##Osud rodu Zajíců - GameCon 2022##\r\n\r\n**Autoři:** Guff a kolektiv\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC22_Osud_rodu_Zajicu.zip\">dobrodružství Osud rodu Zajíců (.zip, 22,4 MB)</a>\r\n\r\n\r\n\r\n##Největší fuška kariéry - GameCon 2021##\r\n\r\n**Autoři:** Mrak a kolektiv\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC21_Nejvetsi_fuska_kariery.zip\">dobrodružství Největší fuška kariéry (.zip, 14,1 MB)</a>\r\n\r\n\r\n##Věrozvěstové - GameCon 2019##\r\n\r\n**Autoři:** Harry a kolektiv\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC19_Verozvestove.zip\">dobrodružství Věrozvěstové (.zip, 25,1 MB)</a>\r\n\r\n\r\n\r\n##Šepot z temnoty - GameCon 2018##\r\n\r\n**Autoři:** Barča a kolektiv\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC18_Sepot_z_temnoty.zip\">dobrodružství Šepot z temnoty (.zip, 19,7 MB)</a>\r\n\r\n\r\n##Návrat domů - GameCon 2017##\r\n\r\n**Autoři:** Jerry a kolektiv\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC17_Navrat_Domu.zip\">dobrodružství Návrat domů (.zip, 62,5 MB)</a>\r\n\r\n\r\n##Čára Zatmění – GameCon 2016##\r\n\r\n__Autoři:__ Lukáš Dvořáček\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC16_Cara_Zatmeni.pdf\">dobrodružství Čára Zatmění (.pdf, 6,7 MB)</a>\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC16_Cara_Zatmeni.zip\">přílohy k dobrodružství (.zip, 144 MB)</a>\r\n\r\n##Božako - město hříchu – GameCon 2015##\r\n\r\n__Autoři:__ Guff a kolektiv\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC15_Bozako_mesto_hrichu.pdf\">dobrodružství Božako - město hříchu (.pdf, 17,2 MB)</a>\r\n\r\n__Tiskoviny:__\r\n\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-15-01.pdf\">Sluncesvit 1, 15. 5.</a> - pdf, 1,3 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-15-02.pdf\">Sluncesvit 2, 29. 5.</a> - pdf, 0,4 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-15-03.pdf\">Sluncesvit 3, 10. 6.</a> - pdf, 0,4 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-15-04.pdf\">Sluncesvit 4, 26. 6.</a> - pdf, 0,3 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-15-05.pdf\">Sluncesvit 5, 1. 7.</a> - pdf, 0,7 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-15-06.pdf\">Sluncesvit 6, 8. 7.</a> - pdf, 0,6 MB\r\n\r\n\r\n\r\n##Umění kovářů – GameCon 2014##\r\n\r\n__Autoři:__ Jarik, Jerry, Fist, Wulf, Brony, Lukáš\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC14_umeni_kovaru.pdf\">dobrodružství Umění Kovářů (.pdf, 1,2 MB)</a>\r\n\r\n__Tiskoviny:__\r\n\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-14-01.pdf\">Sluncesvit 1, 26.6.</a> - pdf, 0,6 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-14-02.pdf\">Sluncesvit 2, 3.7.</a> - pdf, 0,94 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-14-03.pdf\">Sluncesvit 3, 14.7.</a> - pdf, 0,63 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-14-04.pdf\">Sluncesvit 4, 16.7.</a> - pdf, 0,34 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-14-05.pdf\">Sluncesvit 5, 16.7.</a> - pdf, 0,63 MB\r\n\r\n##Údolí – GameCon 2013##\r\n\r\n__Autor:__ Guff\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC13_udoli.zip\">dobrodružství Údolí (.zip, 14 MB)</a>\r\n\r\n\r\n\r\n__Tiskoviny:__\r\n\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-13-01.pdf\">Sluncesvit 1, 26.5.</a> - pdf, 1,0 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-13-02.pdf\">Sluncesvit 2, 3.6.</a> - pdf, 1,1 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-13-03.pdf\">Sluncesvit 3, 9.6.</a>- pdf, 1,0 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-13-04.pdf\">Sluncesvit 4, 16.6.</a>- pdf, 1,1 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-13-05.pdf\">Sluncesvit 5, 23.6.</a>- pdf, 1,0 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-13-06.pdf\">Sluncesvit 6, 30.6.</a>- pdf, 2,2 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-13-07.pdf\">Sluncesvit 7, 2.7.</a>- pdf, 2,2 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-13-08.pdf\">Sluncesvit 8, 4.7.</a>- pdf, 2,2 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-13-09.pdf\">Sluncesvit 9, 6.7.</a>- pdf, 2,2 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-13-10.pdf\">Sluncesvit 10, 6.7.</a>- pdf, 2,2 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-13-special.pdf\">Sluncesvit: Speciální edice, 6.9.</a>- pdf, 2,2 MB\r\n\r\n##Dotkni se draka – GameCon 2012##\r\n\r\n__Autor:__ Dodo\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC12_dotknete-se-draka.zip\">dobrodružství Dotkněte se draka (.zip, 4,5 MB)</a>\r\n\r\n__Tiskoviny:__\r\n\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-12-01.pdf\">Sluncesvit, 23.5.</a> - pdf, 3,0 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-12-02.pdf\">Sluncesvit, 22.6.</a> - pdf, 3,0 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-12-03.pdf\">Sluncesvit, 29.6.</a> - pdf, 3,0 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-12-04.pdf\">Sluncesvit,  4.7.</a> - pdf, 1,5 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-12-05.pdf\">Sluncesvit,  9.7.</a> - pdf, 1,6 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-12-06.pdf\">Sluncesvit, 13.7.</a> - pdf, 1,6 MB\r\n\r\n##Hurikán – Gamecon 2011##\r\n__Autor:__ Tari a kolektiv\r\n\r\n- _Připravujeme..._\r\n\r\n__Tiskoviny:__\r\n\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-11-01.pdf\">Sluncesvit, 1.5.</a> - pdf, 1,6 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-11-02.pdf\">Sluncesvit, 22.5.</a> - pdf, 1,5 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-11-03.pdf\">Sluncesvit, 25.5.</a> - pdf, 1,7 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-11-04.pdf\">Sluncesvit, 12.6.</a> - pdf, 1,7 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-11-05.pdf\">Sluncesvit, 21.6.</a> - pdf, 1,7 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-11-06.pdf\">Sluncesvit, 26.6.</a> - pdf, 1,8 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-11-07.pdf\">Sluncesvit, 30.6.</a> - pdf, 1,6 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-11-08.pdf\">Sluncesvit, 14.7.</a> - pdf, 1,7 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/mapa-vinneho-kraje.pdf\">Mapa Vinného kraje, 12.7.</a> - pdf, 2,4 MB _(dobrá kvalita)_\r\n- <a href=\"/soubory/obsah/drd/noviny/mapa-vinneho-kraje-low.pdf\">Mapa Vinného kraje, 12.7.</a> - pdf, 0,9 MB _(průměrná kvalita)_\r\n\r\n##Pravdonošové – GameCon 2010##\r\n\r\n__Autor:__ Tramis\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC10_pravdonosove.pdf\">dobrodružství Pravdonošové (.pdf, 29,3 MB)</a>\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC10_povolavaci-rozkaz.jpg\">povolávací rozkaz (.jpg, 0,3 MB)</a>\r\n\r\n__Tiskoviny:__\r\n\r\n\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-01.pdf\">Sluncesvit, 7.5.</a> - pdf, 1,7 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-02.pdf\">Sluncesvit, 18.5.</a> - pdf, 1,7 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-03.pdf\">Sluncesvit, 24.5.</a> - pdf, 1,5 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-04.pdf\">Sluncesvit, 31.5.</a> - pdf, 1,6 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-05.pdf\">Sluncesvit, 7.6.</a> - pdf, 1,6 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-06.pdf\">Sluncesvit, 14.6.</a> - pdf, 1,6 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-07.pdf\">Sluncesvit, 21.6.</a> - pdf, 1,6 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/sluncesvit-08.pdf\">Sluncesvit, 30.6.</a> - pdf, 1,7 MB\r\n- <a href=\"/soubory/obsah/drd/noviny/mapa-cisarstvi.pdf\">Mapa císařství, 5.7.</a> - pdf, 1,7 MB\r\n\r\n##Nájezdníci – GameCon 2009##\r\n\r\n__Autoři:__ Elden, Gandalf, John Jarik, Skála, Tari, Tramis, Wulf\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC09_najezdnici.pdf\">dobrodružství Nájezdníci (.pdf, 1,6 MB)</a>\r\n\r\n<!--  CHYBI SOUBORY NA FTP !!!\r\n- <a href=\"/drd/dobrodruzstvi-2009\">dobrodružství Nájezdníci (prohlédnout html)</a>\r\n-->\r\n\r\n##Invaze – GameCon 2008##\r\n\r\n__Autoři:__ Gandalf, Skála, Tramis\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC08_invaze.pdf\">dobrodružství Invaze (.pdf, 5,5 MB)</a>\r\n\r\n##O život – GameCon 2005##\r\n\r\n__Autor:__ Erric\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC05_o_zivot.pdf\">dobrodružství O život (.pdf, 4,5 MB)</a>\r\n\r\n##Alexandrova pomsta – GameCon 2003##\r\n\r\n__Autor:__ Lečo\r\n\r\n- <a href=\"/soubory/obsah/drd/starsi-dobrodruzstvi/GC03_alexandrova_pomsta.pdf\">dobrodružství Alexandrova pomsta (.pdf, 1,3 MB)</a>\r\n\r\n\r\n  \r\n\r\n<!--TOTO JE KÓD ZPĚT DO SEKCE-->\r\n\r\n<table><tr>\r\n<td style=\"vertical-align: top;\">\r\n<img src=\"soubory/obsah/obrazky/arrow-back.png\" style= \"width: 24px;\">\r\n</td>\r\n<td>\r\n<div style=\"margin-top: 2px;\"><a href=\"drd\">zpět do sekce mistrovství v DrD</a></div></td>\r\n</tr></table>', 4),
(137, 'drd/pj', '# Pánové jeskyně\r\n\r\n![](soubory/obsah/drd/web/2022/pj.png)\r\n<div style=\"color: #666; margin-top: -20px; margin-right: 170px; font-size: 8pt; float: left;\">Obrázek z Pinterest.com <a href=\"https://cz.pinterest.com/pin/111745634490574553/\">(odkaz)</a></div>\r\n\r\n<!--TOTO JE KÓD ZPĚT DO SEKCE-->\r\n\r\n<table><tr>\r\n<td style=\"vertical-align: top;\">\r\n<img src=\"soubory/obsah/obrazky/arrow-back.png\" style= \"width: 24px;\">\r\n</td>\r\n<td>\r\n<div style=\"margin-top: 2px;\"><a href=\"drd\">zpět do sekce mistrovství v DrD</a></div></td>\r\n</tr></table>\r\n\r\n<!-- Widget pro načtení PJ: PJ se načítají z aktivit z aktuálního roku (případně z minulého roku, pokud zatím žádné nejsou) -->\r\n(widget:drd-pj)\r\n\r\n<div style=\"height: 70px;\"></div>\r\n\r\n<!--TOTO JE KÓD ZPĚT DO SEKCE-->\r\n\r\n<table><tr>\r\n<td style=\"vertical-align: top;\">\r\n<img src=\"soubory/obsah/obrazky/arrow-back.png\" style= \"width: 24px;\">\r\n</td>\r\n<td>\r\n<div style=\"margin-top: 2px;\"><a href=\"drd\">zpět do sekce mistrovství v DrD</a></div></td>\r\n</tr></table>', 3),
(138, 'drd/dobrodruzstvi', '#Informace k dobrodružství\r\n\r\n![](soubory/obsah/drd/web/2023/dobrodruzstvi.jpg)\r\n<div style=\"color: #666; margin-top: -20px; margin-right: -0px; font-size: 8pt; float: left;\">Obrázek z Pinterst.com <a href=\"https://pin.it/3m1NAct\">(odkaz)</a></div>\r\n\r\n<!------------- DEFINICE STYLU MOŽNO PROMAZAT ----------------->\r\n\r\n<style>\r\n.description {min-height: 108px; max-width: 260px;}\r\n.link:hover {cursor: pointer}\r\n.name {font-size: 14pt; margin-bottom: 18px; font-weight: bold;}\r\n.about {margin-top: 12px;}\r\n.clear {clear: both;}\r\n.radek {margin-top: 6px; margin-bottom: 6px;}\r\n.odsaz {margin-left: 40px}\r\n.sirka {max-width:320px; margin-left: auto; margin-right: auto;}\r\n\r\n@font-face {\r\n	font-family: \"Flaticon\";\r\n	src: url(\"soubory/obsah/fonty/pjove/flaticon.eot\");\r\n	src: url(\"soubory/obsah/fonty/pjove/flaticon.eot#iefix\") format(\"embedded-opentype\"),\r\n	url(\"soubory/obsah/fonty/pjove/flaticon.woff\") format(\"woff\"),\r\n	url(\"soubory/obsah/fonty/pjove/flaticon.ttf\") format(\"truetype\"),\r\n	url(\"soubory/obsah/fonty/pjove/flaticon.svg\") format(\"svg\");\r\n	font-weight: normal;\r\n	font-style: normal;\r\n}\r\n[class^=\"flaticon-\"]:before, [class*=\" flaticon-\"]:before,\r\n[class^=\"flaticon-\"]:after, [class*=\" flaticon-\"]:after {   \r\n	font-family: Flaticon;\r\n        font-size: 20px;\r\n        color: #800;\r\nfont-style: normal;\r\nmargin-left: 6px;\r\n}.flaticon-favourites7:before {\r\n	content: \"\\e000\";\r\n}\r\n\r\n</style>\r\n<!------------- DEFINICE STYLU ----------------->\r\n\r\n<!--TOTO JE KÓD ZPĚT DO SEKCE-->\r\n\r\n<table><tr>\r\n<td style=\"vertical-align: top;\">\r\n<img src=\"soubory/obsah/obrazky/arrow-back.png\" style= \"width: 24px;\">\r\n</td>\r\n<td>\r\n<div style=\"margin-top: 2px;\"><a href=\"drd\">zpět do sekce mistrovství v DrD</a></div></td>\r\n</tr></table>\r\n\r\n<!--  KONEC KÓDU ZPĚT DO SEKCE-->\r\n\r\n**Můžeš si stáhnout následující dokumenty**:\r\n\r\n- [Informace k dobrodružství mDrD 2023](http://gamecon.cz/soubory/obsah/drd/web/2023/informace_k_dobrodruzstvi.pdf) - pdf soubor\r\n- [Deníky postav](http://gamecon.cz/soubory/obsah/drd/web/2023/osobni-deniky-2023.pdf) - pdf soubor\r\n- [Mořešum 1](soubory/obsah/drd/noviny/moresum-23-01.pdf) - Åge a Stig (pdf), 1. 6. 2023\r\n- [Mořešum 2](soubory/obsah/drd/noviny/moresum-23-02.pdf) - Novinky od velkovezíra Almira  (pdf), 7. 6. 2022\r\n- [Mořešum 3](soubory/obsah/drd/noviny/moresum-23-03.pdf) - Narab je blízko (pdf), 15. 6. 2022\r\n\r\n\r\n<!--PROZATÍM SKRYTÉ\r\n\r\n\r\n- [Mořešumy pohromadě](http://gamecon.cz/soubory/obsah/drd/web/2022/mesicsvit-22-light.pdf) - pdf soubor, 6. 7. 2022\r\n\r\n\r\n- [Mořešum 3](soubory/obsah/drd/noviny/moresum-23-03.pdf) - Problémy vladyky Jošta (pdf), 23. 6. 2022\r\n- [Mořešum 4](soubory/obsah/drd/noviny/moresum-23-04.pdf) - Příběh o Šumském Rubu (pdf), 6. 7. 2022\r\n- [Mořešum 5](soubory/obsah/drd/noviny/moresum-23-05.pdf) - Stručně z historie severních Čech (pdf), 6. 7. 2022\r\n- [Mořešum 6](soubory/obsah/drd/noviny/moresum-23-06.pdf) - Dopis Velimíra z Kročova (pdf), 7. 7. 2022\r\n\r\nPROZATÍM SKRYTÉ -->\r\n\r\n#Úvodem\r\nNa této stránce nalezneš informace k dobrodružství. Každá případná aktualizace stránky (nový obsah) bude vždy oznámena prostřednictvím [Facebooku](https://www.facebook.com/gamecon) a [novinek](http://gamecon.cz/novinky). Předpokládáme, že přibývat budou pouze tzv. **Mořešumy**, krátké texty, které vás ještě více uvedou do děje. Určitě jim věnujte pozornost, budou vám být při hře k užitku. \r\n\r\nNepřehlédněte též stránku [Organizace turnaje](http://gamecon.cz/drd/organizace), kde se dozvíte konkrétní pravidla pro tvorbu postavy a další náležitosti turnaje. **S případnými dotazy** se obraťte emailem na organizátora Mistrovství a zároveň autora dobrodružství [Guffa](mailto:foo@example.com).\r\n\r\n**Upozornění: Turnaje se lze zúčastnit i bez znalosti níže uvedených informací**. ALE váš postup dobrodružstvím bude značně zdržován vyptáváním se a doplňováním si informací o reáliích. Zcela jistě se budete hůře orientovat v příběhu a vaše šance na vítězství tak bude menší.\r\nPokud se ale specifických reálií chytnete, pomůžete budování atmosféry hry, budete příběhem a postavami více „žít“ a věříme, že dobrodružství tím bude zajímavější pro vás i PJe.\r\n\r\n#Před začátkem dobrodružství\r\nLetošní dobrodružství nenavazuje dějem na žádné předchozí dobrodružství posledních let. \r\n\r\n#Reálie\r\n##Al Qara\r\nCelé dobrodružství se bude odehrávat na Jižním kontinentu, který místní obyvatelé nazývají **Al Qara**. Kontinent je téměř neobyvatelný, protože se na něm z větší části nachází pouště. Ty jsou osypané ostrůvky oáz. Z jihu na sever proudí velká řeka **Shirya**, která se vlévá do moře **Bahr Azraq**. Vypadá jako jizva na tváři kontinentu. Nejvíce lidí žije v úrodném údolí Shirya či na pobřeží Bahr Azraq, kde se jak náhrdelník táhne pás měst. Na východě končí \"náhrdelník\" u skalnatých hor **Al Sukhur**, na západě pak velkou pouští **Al Sahrou**.\r\n\r\nNa západ od Al Qary leží nekonečný oceán **Ma\'kabir**. Na severu za mořem Bahr Azraq zcela jistě leží jiný kontinent, odkud často připlouvají *\"bílí lidé\"* a čas od času i *\"rudí obři\"*. Z východních skalisek Al Sukhur přichází karavany *\"malých\"* lidí. A z jihu? Jak říká staré přísloví: *\"Z jihu nepřichází nic dobrého\"*.\r\n\r\n![](soubory/obsah/drd/web/2023/alqara.png)\r\n\r\n##Obyvatelé Al Qary\r\nJak již bylo výše napsáno, Al Qaru tvoří z větší části poušť, která určuje veškeré žití. Jednoduše - tam, kde je zdroj vody, tam žijí lidé. Voda je naprosto klíčová a ovlivňuje veškeré dění na kontinentu.\r\n\r\nAsi 80% obyvatel žije v údolí velké řeky Shirya. Koryto řeky je široké a časté záplavy činí okolní půdu mimořádně úrodnou. Lze zde nalézt všechny rasy, nejčastěji pak lidi, elfy, kudůky a hobity. Téměř všichni se živí zemědělstvím - od pěstování plodin, přes chov domácích zvířat až po rybolov. Státní uspořádání je volné. Nikomu se nepodařilo sjednotit údolí Shirya do království, či císařství. Existují zde menší celky, emiráty, kterým vládnou emírové. Každý emír spravuje část řeky Shirya, drží odpovídající posádku ozbrojenců a stará se o pořádek jak na souši, tak na řece.\r\n\r\nDalších 10% obyvatel obývá jednotlivé oázy, které jsou rozeseté v poušti po celém kontinentu. Každou spravuje šejk. Šejk za úplatu poskytuje ochranu před pouštními nájezdníky a samozřejmě vodu. Většina šejků též rozvíjí obchod a nebo se účastní ozbrojených výpadů na jiné oázy. Typickými obyvateli oáz jsou lidé, elfové, hobité, kudůci a barbaři.\r\n\r\nDalších 5% obyvatel Al Qary žije v přístavních městech na pobřeží Bahr Azraq. Tato města jsou samostatnými státy, kterým vládnou sultáni. Jejich moc pramení převážně z obchodu,   řemeslné výroby (zbraně, nástroje, šperky, luxusní zboží atp.) a též pirátství.\r\n\r\nPosledních 5% obyvatel žije v horách Al Sukhur, které jsou bohaté nejen na rudy, drahé kovy, ale i sůl, síru či drahé kamení. Zde najdeme většinu trpaslíků, kudůků a krollů. \r\n\r\n##Náboženství\r\nStejně jak je Al Qara roztříštěná a život je koncentrován jen v určitých částech kontinentu, tak je roztříštěné i náboženství. Převládají různé kulty uctívající kde co. Od Slunce, přes vítr, po různá stvoření i nestvůry. Jeden aby se v těch kultech vyznal.\r\n\r\n##Otroctví\r\nNa Al Qaře je otroctví běžná součást koloběhu života. Člověk je velmi snadno obchodovatelný. Na lidská práva si nikdo nehraje. Chudé rodiny často prodávají své potomky do otroctví, aby se uživily. Levná pracovní síla se také vždy hodí, stejně jako předvoj dobře vycvičených vojáků v krvavých půtkách. Otrokem se člověk může stát velmi snadno. \r\n\r\n##Zločin a právo\r\nNeexistuje žádný právní kodex na Al Qaře. Soudci jsou většinou emíři, šejkové, sultáni či jimi pověření úředníci - vezíři.  Zhusta ve sporu rozhoduje úplatek, osobní prospěch či veřejné mínění než spravedlnost v našem civilizovaném podání. Ale záleží. Jsou šejkové oáz, kteří vidí v hledání Pravdy smysl. Jsou však spíše výjimkou.\r\n\r\nVzhledem k nehostinnosti Al Qary je každičký den svým způsobem boj o život. Proto se zločiny povětšinou trestají krutě. Usekávání paží, veřejné bičování či upalování je k vidění i u krádeží. U vražd platí pravidlo oko za oko, zub za zub do písmene. Pouze bohatí mají šanci se z trestu vykoupit.\r\n\r\n\r\n##Magie\r\nAl Qara je plná magie, nicméně ta je nerovnoměrně rozprostřená přes celý kontinent. Existují místa, kde magii cítí i obyčejný smrtelník, ale ta jsou povětšinou nedostupná a dostat se do nich vyžaduje mnoho peněz, sil a taky štěstí. \r\n\r\nMagie je považována za běžnou součást života na Al Qaře. Čarodějové a mágové mohou bez obav dávat svojí moc na odiv. Moc však přináší i odpovědnost, která se především projevuje výší trestu, pokud kouzelník použije magii k páchání zločinu.\r\n\r\n\r\n##Družina\r\nVaše družina je vznikla relativně nedávno. Většina z vás se navzájem neznala až do doby, než vás seznámila vaše mentorka **Aida**. Jako jednotlivci jste dobří ve svém povolání, jak družina to ještě občas drhne. Nicméně pár akcí již máte za sebou a do povědomí obyvatel města **Arkúš** se pomalu, ale jistě zapisujete jako schopná parta hrdinů.\r\n\r\nProč jste se vůbec jako družina dali dohromady? Téměř všichni máte společný motiv - dopadnou Naraba Hakshaka, který každému z vás nějakým způsobem ublížil. Více viz osobní deníky jednotlivých postav. Toho využila Aida, která má s Narabem taktéž nevyřízené účty. Doslova vás posbírala po celé Al Qaře a udělala z vás družinu, která má Naraba najít a donutit zaplatit za vše, co vám a Aidě udělal.\r\n\r\n##Aida\r\nModrooká světlovlasá žena jménem Aida je mentorkou naší družiny. Postavy o Aidě moc neví, svoji minulost si pečlivě stráží a družině řekla jen to, co potřebovala vědět. Postavy ví, že Aida touží dopadnout Naraba Hakshaka. Ostatně proto družinu dala dohromady a i tomu odpovídají její úkoly pro družinu. Dále postavy ví, že Aida není z Al Qary, ale z kontinentu za mořem Bahr Azraq, čemuž odpovídá její nevšední vzhled. \r\n\r\n##Narab Hakshak\r\nCíl naší družiny. Požírač lidského masa. Černý stín, který přichází v noci. Narab Hakshak. Ten, jehož jméno se ani za dne nevyslovuje nahlas. Nikdo si před ním nemůže být jistý. Ani otrok, ani žebrák, ani zlatník či bohatý kupec. Nečiní rozdíly, nevybírá si. Ačkoliv po něm pátráte již nějakou dobu, stále vám uniká. Ale nevzdáváte se, nemůžete to vzdát...\r\n\r\n\r\n\r\n\r\n\r\n<!--TOTO JE KÓD ZPĚT DO SEKCE-->\r\n\r\n<table><tr>\r\n<td style=\"vertical-align: top;\">\r\n<img src=\"soubory/obsah/obrazky/arrow-back.png\" style= \"width: 24px;\">\r\n</td>\r\n<td>\r\n<div style=\"margin-top: 2px;\"><a href=\"drd\">zpět do sekce mistrovství v DrD</a></div></td>\r\n</tr></table>\r\n\r\n<!--KONEC KÓDU ZPĚT DO SEKCE-->\r\n\r\n<!------------- NEMAZAT ------------->\r\n<script>\r\nfunction ukaz(id)\r\n{\r\n  $(id).animate({height: \'toggle\'});\r\n}\r\n</script>', 1),
(139, 'drd/sin-slavy', '#Síň slávy\r\n\r\n![](soubory/obsah/drd/pohar.jpg)\r\n\r\n<!--TOTO JE KÓD ZPĚT DO SEKCE-->\r\n\r\n<table><tr>\r\n<td style=\"vertical-align: top;\">\r\n<img src=\"soubory/obsah/obrazky/arrow-back.png\" style= \"width: 24px;\">\r\n</td>\r\n<td>\r\n<div style=\"margin-top: 2px;\"><a href=\"drd\">zpět do sekce mistrovství v DrD</a></div></td>\r\n</tr></table>\r\n\r\nJiž od roku 1995 se na GameConu každoročně koná mistrovství České republiky v Dračím doupěti. Na následujících řádcích naleznete zvěčněna jména těch, jež dosáhli až na stupně nejvyšší.\r\nOd roku 2014 je u nich uvedena i jejich přezdívka.\r\n\r\n##Rok 2022\r\n1. **Rumové víly** -  Luboš \"Bellg\" Kosour, Stanislav Šmerda, Pavel \"Semyon\" Kosour, Martin \"Jurba\" Jurek, Jan \"Kut\" Kutálek, Václav \"KliKli\" Kosour, Maruška \"Tripunc\" Novotná\r\n2. **Hoši od Zlobří řeky** - Jakub \"Slupkowitz\" Kosina, Matouš \"Arco\" Kotek, Ondřej \"Bambivs\" Petrus, Petr \"AJR\" Maška, Milan \"Milmo\" Danda, Vladimír \"Valda\" Hons, Bohumil \"Theofil\" Kurka\r\n3. **Kdesi cosi kamisi** - Radka \"Šarlota Slüčná\" Havlíčková, Marek \"Marcus IV\" Zmeškal, Robin \"Kammi\" Hudcovič, Michal \"Pegusian\" Pekárek, Jiří \"ZloŘepa\" Kučera, Michaela \"Sandriel\" Hájková\r\n\r\n\r\nCelkové pořadí družin naleznete [zde](http://gamecon.cz/soubory/obsah/drd/web/2022/Vysledky-MDrD-2022.pdf)\r\n\r\n<a href=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2022.jpg\" target=\"_blank\"><img src=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2022.jpg\" width=\"480px\" style=\"box-shadow: 3px 3px 10px rgba(0,0,0,0.5);\"></a>\r\n\r\n##Rok 2021\r\n1. **Družina bez nukleárního krolla** - Marej \"Marat\" Bradávka, Václav Dorazil, Petr \"Youda\" Plášil, Martin \"Tomi\" Toman, Jaroslav \"Cromer\" Umlášek\r\n2. **Starší braši a sestra** - Michal \"Balzak\" Balák, Karel \"Chen Wu\" Černohorský, Petr \"d_k\" Tomaník, Vojtěch \"Wild\" Vild, Helena \"Ree-ali\" Vildová\r\n3. **Hodíme tam fireball!** - Michal \"Lastovička\" Capko, Marek \"Chlapik\" Krizka, Petr \"Nathan\" Melka, Tomáš \"Nox\" Nox, Jakub \"Trorn\" Petr, Tomáš \"Zantur\" Stejskal, Roman \"Myrn\" Vereš\r\n\r\nCelkové pořadí družin naleznete [zde](http://gamecon.cz/soubory/obsah/drd/web/2021/Vysledky-MDrD-2021.pdf)\r\n\r\n<a href=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2021.jpg\" target=\"_blank\"><img src=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2021.jpg\" width=\"480px\" style=\"box-shadow: 3px 3px 10px rgba(0,0,0,0.5);\"></a>\r\n\r\n\r\n##Rok 2019\r\n1. **Rumové víly** - Luboš \"Bellg\" Kosour, Oldřich Havlíček, Stanislav Šmerda, Pavel \"Semyon\" Kosour, Martin Jurek, Jan \"Kut\" Kutálek, Václav \"KliKli\" Kosour\r\n2. **Poslední hlídka** - Magdaléna \"Mirelaridon\" Holendová, Petr \"Peepa\" Holenda, Kateřina \"Sat\" Levínská, Vojtěch \"Vojta\" Kopecký, Lukáš \"Šuky\" Fauler, Martina Sládková, Jan \"Cishak\" Kovář\r\n3. **EDB** - Stanislav \"Deshi\" Strmeň, Bára \"Lai\" Strmeňová, Vít \"Kasumi\" Kučera, Ondrej \"Udunai\" Onačila, Jan \"Orsman\" Orsák, Bára \"BarčaO\" Orsáková, Eliška \"EliškaO\" Orsáková\r\n\r\nCelkové pořadí družin naleznete [zde](http://gamecon.cz/soubory/obsah/drd/web/2019/Vysledky-MDrD-2019.pdf)\r\n\r\n<a href=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2019.jpg\" target=\"_blank\"><img src=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2019.jpg\" width=\"480px\" style=\"box-shadow: 3px 3px 10px rgba(0,0,0,0.5);\"></a>\r\n\r\n##Rok 2018\r\n1. **Odinovi chachaři** - Rostislav \"Alkazar\" Novák, Petr \"Hobit006\" Falek, Jana \"Jainah\" Pipková, Dominika \"Pikachu\" Kovarovičová, Vojtěch \"Alakadar\" Troup, Hana \"Nezodpovědník\" Lauerová, Michal \"Beny\" Beneš\r\n2. **EDB** - Stanislav \"Deshi\" Strmeň, Bára \"Lai\" Strmeňová, Vít \"Kasumi\" Kučera, Jan \"Orsman\" Orsák, Pavel \"Owen\" Skoda, Bára \"BarčaO\" Orsáková, Eliška \"EliškaO\" Orsáková\r\n3. dvě družiny: **Jezevcova motyka** - Jan \"Zelenylistecek\" Blahut, Jakub \"Jezevec\" Hrubý, Emil \"Kremilek\" Černý, David \"Garudas\" Brych, Milan \"Olbin\" Brych, Jan \"Ardo300\" Moravec. **Co si kde si** - Radka \"Išava\" Havlíčková, Marek \"Marcus IV\" Zmeškal, Robin \"Kammi\" Hudcovič, Jindra \"Sabaothen\" Dušek, David \"Swen\" Strádal, Michal \"Pegusian\" Pekárek, Jiří \"ZloŘepa\" Kučera\r\n\r\n<a href=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2018.jpg\" target=\"_blank\"><img src=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2018.jpg\" width=\"480px\" style=\"box-shadow: 3px 3px 10px rgba(0,0,0,0.5);\"></a>\r\n\r\n##Rok 2017\r\n1. Jaromír \"Suchance\" Suchánek, Martin \"Tomi\" Toman, Václav Dorazil, Petr \"Youda\" Plášil, Marek \"Marat\" Bradávka, Jaroslav \"Cromer\" Umlášek\r\n2. Pavel \"Maverick\" Vladik, Marie \"Sojka\" Štefanidesová, Jan \"Rex\" Kmuníček, Stanislava \"Elanor\" Pilková\r\n3. Jan \"Kut\" Kutálek, Václav \"Klikli\" Kosour, Martin Jurek, Pavel \"Semyon\" Kosour, Stanislav Šmerda, Oldřich Havlíček, Luboš \"Bellg\" Kosour\r\n\r\n<a href=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2017.jpg\" target=\"_blank\"><img src=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2017.jpg\" width=\"480px\" style=\"box-shadow: 3px 3px 10px rgba(0,0,0,0.5);\"></a>\r\n\r\n\r\n##Rok 2016\r\n1. Michal \"Balzak\" Balák, Petr Tomaník, Helena \"Re-ali\" Vildová, Karel \"Strachkvas Pírko\" Černohorský, Petr \"Tchezz\" Vavřena, Vojtěch \"Wild\" Vild\r\n2. Bára \"Barča\" Orsáková, Stanislav \"Deshi\" Strmeň, Eliška Orsáková, Vít \"Kasumi\" Kučera, Bára \"Lai\" Strmeňová, Jan \"Orsman\" Orsák, Pavel \"Owen\" Škoda\r\n3. Martin \"Melfi\" Iš, Ondřej \"Horin\" Vaněk, Martin \"Gron\" Hanák, Martin \"Phosphoros\" Žák, Adam \"Seph\" Bábík\r\n\r\n<a href=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2016.jpg\" target=\"_blank\"><img src=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2016.jpg\" width=\"480px\" style=\"box-shadow: 3px 3px 10px rgba(0,0,0,0.5);\"></a>\r\n\r\n##Rok 2015\r\n1. Stanislav \"Lumík\" Kamenský, Lukáš \"Zayl\" Dubský, Jakub \"Trorn\" Petr, Tomáš \"Zantur\" Stejskal, Ladislav \"Kwon\" Bartoš, Roman \"Myrn\" Vereš, Pavel \"Garry\" Novák, Blanka \"Blanka\" Moravcová.\r\n2. Vlastimil \"Pazda\" Pazderka, Martin \"Melfi\" Iš, Martin \"Gron\" Hanák, Martin \"Phosphoros\" Žák, Jakub \"Mr.Kyslik\" Navrátil\r\n3. Daniel \"Dodo\" Mentlík, Eva \"Peva\" Pesková, Břetislav \"KHS\" Nevrkla, Jakub \"Cleo\" Tobiáš, Petr \"Reformic\" Fomenko, Martin \"Muf\" Sokol, Bára \"Lai\" Strmeňová\r\n\r\n<a href=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2015.jpg\" target=\"_blank\"><img src=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2015.jpg\" width=\"480px\" style=\"box-shadow: 3px 3px 10px rgba(0,0,0,0.5);\"></a>\r\n\r\n##Rok 2014\r\n1. Bohumil „Theofil“ Kurka, Tomáš „Pajaro“ Růžek, Jakub „Slupkowitz“ Kosina, Matouš „Arco“ Kotek, Tomáš „Peterson“ Peterka, ondřej „PMD“ petrus, Petr „AJR“ Maška\r\n2. Jan „zelenylistecek“ Blahut, Jakub „Jezevec“ Hrubý, Emil „Kremilek“ Černý, Jenda „Loid“ Tochor, David „Garudas“ Brych, Jan „Meller“ Raděj\r\n3. Daniel „sidon“ Petráš, Peter „Sid“ Tkačov, Martin „MackO“ Tkačov, Samuel „sa3xxx“ Kovacik, Marek „frog“ Kováčik, Jozef „skauter1“ Kleberc\r\n\r\n<a href=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2014.jpg\" target=\"_blank\"><img src=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2014.jpg\" width=\"480px\" style=\"box-shadow: 3px 3px 10px rgba(0,0,0,0.5);\"></a>\r\n\r\n##Rok 2013\r\n1. Marek Bradávka, Martina Novotná Buršíková, Václav Dorazil, Petr Plášil, Jaromír Suchánek, Martin Toman, Jaroslav Umlášek \r\n2. Rostislav Novák, Petr Falek, Dominika Kovarovičová, Jan Starý, Vojtěch Troup, Lucie Čiháková, Tomáš Ottl, Martin Šrom\r\n3. Jan Blahut, Milan Brych, David Brych, Emil Černý, Jenda Tochor, Jan Raděj, Jana Prošková, Milan Jarolím\r\n\r\n<a href=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2013.jpg\" target=\"_blank\"><img src=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2013.jpg\" width=\"480px\" style=\"box-shadow: 3px 3px 10px rgba(0,0,0,0.5);\"></a>\r\n\r\n##Rok 2012\r\n1. Filip Dvořák, Eva Konířová, Martin Tyla, Václav Razim, Vojtěch Kovařík, Jiří Mrkva, Jarda Ryšavý, Jan Foldyna\r\n2. Patrik Serej, Filip Nguyen, Michal Navrátil, David Urbánek, Teodor Vybíral, Jan Pospíšil, Sára Hrádková, Mojmír Jílek.\r\n3. Martin Jurek, Luboš Kosour, Pavel Kosour, Václav Kosour, Stanislav Šmerda, Jirka Havlík\r\n\r\n<a href=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2012.jpg\" target=\"_blank\"><img src=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2012.jpg\" width=\"480px\" style=\"box-shadow: 3px 3px 10px rgba(0,0,0,0.5);\"></a>\r\n\r\n##Rok 2011\r\n1. Marek Bradávka, Martina Novotná Buršíková, Václav Dorazil, Rostislav Macek, Petr Plášil, Jaromír Suchánek, Martin Toman, Jaroslav Umlášek \r\n2. Marek Andráši, Ondřej Bittner, Radka Havlíčková, Hana Homsi, Eva Mayerová, Jan Saturka, Michal Vitásek, Magdaléna Vitásková \r\n3. Martin Jurek, Luboš Kosour, Pavel Kosour, Václav Kosour, Oldřich Havlíček, Stanislav Šmerda\r\n\r\n## Rok 2010\r\n1. Stanislav Strmeň, Markéta Dušková, Lucie Hromádková, Josef Tourek, Vladimíř Škrna, Jan Chvojka, Jan Soukup \r\n2. Jindřich Schovanec, Míla Luňáček, Martin Špánek, Jaromír Muller, Jan Hájek, Jarča Luňáčková, Petr Kudlák \r\n3. Lenka Kabeláčová, Vašek Křapáček, Jana Sigmundová, Jakub Zykl, Ondřej Burian, Vít Bogačík\r\n\r\n## Rok 2009\r\n1. Lenka Kabeláčová, Jana Sigmundová, Jakub Zykl, Vít Bogačík, Václav Křapáček \r\n2. Lukáš Nekvinda, Martin Jurek, Pavel Kosour, Stanislav Šmerda, Oldřich Havlíček, Luboš Kosour, Milan Neuwirth \r\n3. Dan Kadlec, Jan Krahulec, Jan Kadlec, Marian Remiš, Šimon Bureš, Pavol Kosnáč, Jan Smetana\r\n\r\n## Rok 2008\r\n1. Pavel Dušek, Markéta Dušková, Lucie Hromádková, Jan Saitz, Jan Soukup, Stanislav Strmeň, Josef Tourek, Karel Voldřich \r\n2. Ondřej Froemmer, Filip Kostelňák, Antonín Novák, Tomáš Pitron, Jiří Trávníček, Miloslav Zaoral \r\n3. Martin Hanák, Martin Iš, Petr Jarolím, Vlastimil Pazderka, Patrik Petřík, Alena Skokaničová, Josef Tomšej, Ondřej Vaněk\r\n\r\n## Rok 2007\r\n1. Martina Buršíková, Václav Dorazil, Rostislav Macek, Petr Plášil, Martin Sokol, Jaromír Suchánek, Jakub Tobiáš, Martin Toman \r\n2. Jan Hájek, Vojtěch Horký, Petr Kudlák, Miloslav Luňáček, Jaroslava Luňáčková, Jan Rohlena, Martin Špánek, Ondřej Zahálka \r\n3. Martin Korger, Daniel Kozák, Tomáš Kutálek, Jan Láska, Jan Návrat, Barbora Návratová, Jakub Strouhal\r\n\r\n## Rok 2006\r\n1. Ondřej Bittner, Radka Havlíčková, Hana Homsi, Eva Kubartová, Vladimír Lazárek, Jan Saturka, Michal Vitásek, Magdaléna Vitásková \r\n2. Richard Böhm, Pavlína Böhmová, Lubomír Gerloch, Ladislav Guľa, Markéta Hrušková, Tomáš Kozel, Zuzana Malcová, Michal Malec \r\n3. Táňa Binarová, David Brančík, Michal Faldyna, Jan Foldyna, Ivan Haška, Jiří Mrkva, Jaroslav Ryšavý, František Slepánek\r\n\r\n<a href=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2006.jpg\" target=\"_blank\"><img src=\"/soubory/obsah/drd/vyherci/vyherci-mdrd2006.jpg\" width=\"480px\" style=\"box-shadow: 3px 3px 10px rgba(0,0,0,0.5);\"></a>\r\n\r\n## Rok 2005\r\n1. Jakub Doležal, Michaela Hradecká, Lukáš Jandura, Daniel Mentlík, Břetislav Nevrkla, Tomáš Rynekr, Jakub Tobiáš, Jaroslav Víšek \r\n2. Adam Bábík, Martin Hanák, Martin Iš, Josef Novák, Vlastimil Pazderka, Patrik Petřík, Alena Skokaničová, Ondřej Vaněk \r\n3. Martin Bitman, Lenka Herrmannová, Tomáš Kos, Pavel Ludvík, Veronika Maderová, David Manda, Aleš Vokálek\r\n\r\n## Rok 2004\r\n1. Jan Chmelař, Filip Hobl, Adéla Kyselová, René Nekuda, Klára Nováková, Jakub Vaněk, Anna Vaňková, Marie Vaňková \r\n2. Martin Bitman, Lenka Herrmannová, Tomáš Kos, Jakub Ludvík, Pavel Ludvík, David Manda, Aleš Vokálek \r\n3. Zdeněk Böhm, Jakub Hušek, Čeněk Jirsák, Petr Jirsák, Martin Otava, Radek Otava, Jan Rameš, Aleš Richter\r\n\r\n## Rok 2003\r\n1. Jiří Bláha, Martin Bláha, Miroslav Havel, Martin Poláček, Pavel Poláček, Martin Sazima, Martin Zahradil, Pavel Zahradil \r\n2. Václav Dorazil, Jan Kutra, Petr Kadlec, Rostislav Macek, Petr Plášil, Jaromír Suchánek, Martin Toman, Jiří Vyhlídka \r\n3. Jan Kohoutek, Jan Macháč, Oldřich Mikula, Aleš Plšek, Ladislav Šídlo, Alžběta Trojanová, Bořek Zelinka\r\n\r\n## Rok 2002\r\n1. Jan Buchta, Jakub Jandák, Zdeněk Jurečka, Dušan Slezáček, Roman Slezáček, Jakub Vojta, Tomáš Zahradníček \r\n2. Marek Bradávka, Michal Fejks, Marek Pavlík, Šimon Procházka, Ondřej Stehlík, Jan Stoklásek, Jaroslav Umlášek, Michal Vlach \r\n3. Daniel Hanslik, Tomáš Juřík, Erika Pekárková, Pavel Polák, Adam Rambousek, Luděk Šrubař, Lenka Ticháková, Ondřej Zeman\r\n\r\n## Rok 2001\r\n1. Tomáš Kouřil, Petr Pouchlý, Petra Pikartová, Radek Šmíd, Radim Vítek, Josef Zifčák \r\n2. Miloslav Javorský, Rostislav Macek, Petr Medek, Petr Plášil, Martin Toman, Bronislav Tomek, Antonín Suchánek, Rejštejn \r\n3. Martin Andrešič, Robert Blahynka, Martin Blahynka, Petr Gottfried, Petr Jakubíček, Milan Lunga, Jiří Novák, Michal Řihánek\r\n\r\n## Rok 2000\r\n1. Ivo Brejšek, Miroslav Kodrla, Jan Stoklásek, Zdeněk Stošek, Petr Šimůnek, Jaroslav Umlášek \r\n2. Martin Hanák, Martin Iš, Petr Jarolím, Matouš Ježek, Patrik Petřík, Vít Procházka, Josef Straka, Ondřej Vaněk \r\n3. Vladan Rychtařík, Radek Adamec, Tomáš Kouřil, Petra Pikartová, Petr Pouchlý, Radim Vítek\r\n\r\n## Rok 1999\r\n1. Josef Beránek, Jiří Culek, Oldřich Dvořák, Michal Hrabí, Karel Novák, Jiří Peloušek, Jiří Pertl, Martin Vojáček \r\n2. Jan Barna, Viktor Hladký, Lukáš Osvald, Vít Osvald, Tomáš Prát, Šárka Sahulová, Milan Šlaj, Libor Žižka \r\n3. Martin Hynek, Zdeněk Kratochvíl, Jan Lichý, Tomáš Lukačina, Vladimír Morčinko, Jan Obdržálek, Zdeněk Pozděna, Lukáš Volhejn, Dalibor Vrba (coby kouzelníkův přítel)\r\n\r\n## Rok 1998\r\n1. Jiří Dobrý, Lukáš Fiala, Michal Novotný, Pavel Schiffner, Stanislav Strmeň, Vladimír Škrna, Ondřej Tišler, Tomáš Vodička \r\n2. Martin Hynek, Jan Lichý, Tomáš Lukačina, Vladimír Morčinko, Jan Obdržálek, Zdeněk Pozděna, Lukáš Volhejn, Dalibor Vrba \r\n3. Jaroslav Hajn, Lukáš Hladeček, Jiří Hlaváček, Jiří Kučera, Petr Kulda, Vlasta Lohrová, Jana Lončáková, Karel Váňa\r\n\r\n## Rok 1997\r\n1. Jiří Culek, Oldřich Dvořák, Lukáš Hurt, Tomáš Korejtko, Karel Novák, Jiří Peloušek, Jiří T. Pertl, Jiří Ulip \r\n2. Antonín Buček, Michael Franěk, Jan Gregorovič, Přemysl Oprchal, Michal Picka, Václav Picka, Ladislav Svoboda, Radek Tomášek \r\n3. Jan Brhel, Aleš Knápek, Michal Kopecký, Petr Krčmář, Martin Matoška, David Palán, František Paťava, Ondřej Vlček\r\n\r\n## Rok 1996\r\n1. Michal Balák, Jan Böhm, Martin Krečmer, Pavel Kutina, Viktor Novotný, Petr Tomaník, Vojta Vild, Helena Vildová \r\n2. Libor Grůza, Jaroslav Hajn, Jiří Hlaváček, Jiří Klouda, Vlasta Lohrová, Jitka Polášková, Adam Rambousek, Michal Veselovský \r\n3. Jiří Culek, Oldřich Dvořák, Lukáš Hurt, Tomáš Korejtko, Karel Novák, Jiří Peloušek, Jiří T. Pertl, Jiří Ulip\r\n\r\n## Rok 1995\r\n1. Vendula Čechurová, Ivana Janová, Petra Lindová, Martin Krupička, Martin Lapšanský, Marek Průcha, Vladan Rychtařík \r\n2. Jan Boháč, Jan Kotůlek, Hana Pacáková, Ladislav Šídlo, Stanislav Škarpa, Josef Vávra, Bořek Zelinka \r\n3. Michal Boleček, Tomáš Česal, Michal Grepl, Richard Ploskonka, Jan Přidal, Ivo Válka\r\n\r\n<!--TOTO JE KÓD ZPĚT DO SEKCE-->\r\n\r\n<table><tr>\r\n<td style=\"vertical-align: top;\">\r\n<img src=\"soubory/obsah/obrazky/arrow-back.png\" style= \"width: 24px;\">\r\n</td>\r\n<td>\r\n<div style=\"margin-top: 2px;\"><a href=\"drd\">zpět do sekce mistrovství v DrD</a></div></td>\r\n</tr></table>', 5),
(141, 'legendy/fate', '#Příběhy Impéria a Fate\r\n\r\n![](soubory/obsah/legendy/PIFate.jpg)\r\n\r\n## Příběhy Impéria\r\n\r\nPříběhy Impéria (dále PI) jsou českou hrou na hraní rolí (RPG) od bratrů Ecthelionů, Jonáše a Kryštofa Ferencových. PI jsou jednou z mnoha her, které využívají RPG systém Fate (viz níže) a pojednávají o steampunkové a magické  Viktoriánské Anglii popřípadě jiných částech světa v dobách největšího rozmachu Britského Impéria.\r\n\r\nProstředí hry je jejich velkou předností pro začátečníky, protože vychází z obecně známých a představitelných, mnohokrát filmově, seriálově či knižně ztvárněněných reálií skutečné historie, k nimž pak přidává fantastické popř. steampunkové prvky. Kdo zná [Johnatana Strange a pana Norrella](https://www.youtube.com/watch?v=iE1nsOoTJos), bude si připadat jako doma.\r\n\r\nV PI lze hrát libovolnou postavu, od lidí přes elfy či skřety, od dělníků v docích po nejvyšší šlechtice a politiky. V Legendách hrajeme příslušníky zvláštního klubu, Klubu Dobrodruhů, což je spolek individuí z mnoha míst zabývajících se cestováním, zkoumáním, řešením potíží a vyšetřováním podivností. \r\nTedy spolek, za kterým jdou s žádostí o pomoc ti, kteří už nemají kam jinam jít – ať už jde o obyčejné lidi či příslušníky tajné služby.\r\n\r\n- Recenzi Příběhů Impéria naleznete [ZDE](http://www.d20.cz/clanky/produkty/recenze-sote.html) \r\n- Oficiální web příběhů na webu Mytaga  [ZDE](http://imperium.mytago.cz/), popis hlavní knihy [zde](http://imperium.mytago.cz/?p=39)\r\n- Oficiální demo verze k volnému stažení je [ZDE]( https://www.dropbox.com/s/qdbdn55ao7xi6oq/Pribehy_Imperia_zjednodusena_pravidla.pdf?dl=0) \r\n\r\n## Fate\r\n\r\nPředností systému Fate je jednoduchost, stručnost, zároveň ale dokáže pokrýt velké množství situací. Řadí se mezi univerzální systémy (je nezávislý na žánru a prostředí) a také mezi dovednostní systémy. Mezi hráči RPG patří k jedněm z nejoblíbenějších a nejlépe hodnocených.\r\n\r\nFate využívá jednoduché mechaniky součtu dovednosti s hodem kostkami, který lze dále upravit pomocí bodů osudu a aspektů. Aspekty jsou krátké hráči samotnými nadefinované fráze či hesla, která jejich postavu popisují (může jít o cokoliv od vlastnosti přes popis až po oblíbený citát). Body osudu jsou zvláštní zdroj, za který můžete hru příběhově ovlivňovat a který získáváte, když vám vaše aspekty zkomplikují život.\r\n\r\nLegendy hrajeme podle druhé edice Fate, kterou využívají Příběhy Impéria. Nemusíte se bát, pokud Fate neznáte, velmi rychle jej pochopíte.\r\n\r\n- Souhrn pravidel Fate: [Fate v Kostce]( http://www.d20.cz/clanky/pravidla/Fate-a-fae-v-kostce.html)\r\n- Překlad čtvrté edice Fate [ZDE](http://www.d20.cz/clanky/pravidla/preklad-fate-4e-core-system.html), online verze (SRD) je [ZDE](http://fatesrd.d20.cz/)', 1),
(143, 'legendy/prihlaseni', '# Návod na přihlášení\r\n\r\n![](soubory/obsah/legendy/Door.jpg)\r\n\r\n##Obecný postup\r\nLKD se hrají na dvě kola ve dvou bězích. První běh je čtvrtek večer a pátek odpoledne, druhý pak v pátek večer a sobotu odpoledne – oba běhy spadají do stejného příběhu, takže se sice teoreticky můžete přihlásit na oba (jednotlivé hry jsou různé), ale nedává to moc smysl. **Přihlašujete se pouze na první kolo** za cenu u něj uvedenou – do patřičného druhého kola vás systém přihlásí automaticky. \r\n\r\n## Upozornění\r\n\r\n**(Co je ta ikonka zámku?)**\r\n\r\nJakmile kliknete na přihlášení do Legend, je vámi zvolená aktivita pro ostatní dočasně uzamčena. S tím vám začne běžet **3 denní lhůta** pro kompletní dokončení přihlášky (přihlášení vašich spoluhráčů). Pokud do té doby přihlášení nedokončíte (nekliknete na tlačítko \"**Potvrdit**\"), systém přihlášku zruší a nabídne aktivitu v daných herních blocích znovu k dispozici ostatním. \r\n\r\n**Pokud na \"Potvrdit\" nekliknete, aktivita zůstane blokována - pokud neplánujete hlásit své kamarády, prosíme nezapomeňte kliknout a aktivitu tak uvolnit pro ostatní!**\r\n\r\nV případě, že budete jakoukoliv pomoc, kontaktuje prosím organizátory Legend na <a href=\"mailto:foo@example.com\">foo@example.com </a> nebo <a href=\"mailto:foo@example.com\">foo@example.com</a>.\r\n\r\n##Vyber si návod\r\n\r\n<a href=\"#\" onclick=\"ukaz(volba1); return false;\">Chci přihlásit kompletní herní skupinu</a>\r\n\r\n<div  id=\"volba1\" style=\"display: none;\">\r\nNež se pustíš do přihlášení celé své skupiny, ujisti se, že ty i všichni tví spoluhráči splňujete všechny předpoklady pro úspěšné přihlášení:\r\n<ul>\r\n   <li>Všichni jste registrováni na GC,</li>\r\n   <li>jste dohodnutí na tom, který běh (čt+pá / pá+so) chcete hrát a kterou jeho konkértní hru chcete hrát v prvním kole</li>\r\n   <li>nikdo z vás není v dohodnutých herních blocích (pro první i druhé kolo daného běhu) přihlášen na jinou aktivitu.</li>\r\n</ul>\r\n\r\n<p>Pokud všechny body splňujete, proběhne celé přihlášení skupin bez problémů. Postupuj následovně:</p>\r\n\r\n<ul>\r\n   <li>Přihlaš se na stránkách GC bod svým uživatelským jménem,</li>\r\n   <li>Vyber aktivitu Legendy Klubu Dobrodruhů</li>\r\n   <li>Z aktivit které jsou nabídnuty v daném běhu (mají to vepsáno ve jménu aktivity) si vyber tu, kterou chcete hrát v prvním kole a klikni na \"<b>Přihlásit</b>\".</li>\r\n</ul>\r\n\r\n<p>V tento moment je herní blok uzamčen a běží 3 denní lhůta na dokončení přihlášky. Pokud se chceš registrovat na jiné aktivity, můžeš dokončení přihlášení skupiny přerušit a pokračovat v registraci na jiné aktivity. Pokud chceš pokračovat v přihlášení skupiny na LKD, čti dále:</p>\r\n\r\n<ul>\r\n   <li>Pokračuj výběrem svých spoluhráčů. Do volných políček buď vepiš jejich jména, přezdívky či číselné GC ID (systém ti napoví). Všem spoluhráčům, které přidáš do skupiny, přijde informační e-mail, že byli na aktivitu přihlášeni.</li>\r\n   <li>Pokud vás je méně jak 5 a chcete hrát sami bez jiných hráčů, pak je nutné přebytečná místa odebrat (tlačítko \"<b>Odebrat</b>\"). Pokud tak neučiníš, může se po potvrzení přihlášky kdokoliv přihlásit na neodebraná místa. Prosím dobře rozvažte, že skutečně chcete hrát sami.</li>\r\n   <li>Nyní si vše raději ještě jednou překontroluj (zvolený čas herních bloků, jména spoluhráčů, odebraná místa).</li>\r\n   <li>Nakonec stačí potvrdit přihlášení kliknutím na \"<b>Přihlásit</b>\" a je hotovo.</li>\r\n</ul>\r\n\r\n</div>\r\n\r\n\r\n\r\n<!--- VOLBA 2 --->\r\n<a href=\"#\" onclick=\"ukaz(volba2); return false;\">Chci přihlásit jen sebe či nekompletní skupinu</a>\r\n\r\n\r\n<div  id=\"volba2\" style=\"display: none;\">\r\nPokud jsi sám a nebo s kamarády netvoříte kompletní skupinu (jste méne, než tři), postupuj při přihlášení následovně:\r\n\r\n<ul>\r\n   <li>Přihlaš se na stránkách GC bod svým uživatelským jménem,</li>\r\n   <li>Vyber aktivitu Legendy Klubu Dobrodruhů,</li>\r\n   <li>Z aktivit které jsou nabídnuty v daném běhu (mají to vepsáno ve jménu aktivity) si vyber tu, kterou chcete hrát v prvním kole a klikni na \"<b>Přihlásit</b>\".</li>\r\n   <li>Pokračuj výběrem známých spoluhráčů. Do volných políček buď vepiš jejich jména, přezdívky či číselné GC ID (systém ti napoví). Všem spoluhráčům, které přidáš do skupiny přijde informační e-mail, že byli na aktivitu přihlášeni.</li>\r\n   <li>Pokud chceš, můžeš omezit počet hráčů v skupině tím, že odebereš až dvě místa (tlačítko \"<b>Odebrat</b>\"). Prosím dobře se rozmyslete, zda opravdu ostatním zrušíte možnost se na aktivitu přihlásit.</li>\r\n   <li>Nyní si vše raději ještě jednou překontroluj (zvolený čas herních bloků, jména spoluhráčů, odebraná místa).</li>\r\n   <li>Nakonec stačí potvrdit přihlášení kliknutím na \"<b>Přihlásit</b>\" a je hotovo.</li>\r\n</ul>\r\n\r\n<b>Pozor!</b>\r\n<br>Pokud neznáš své spoluhráče, je potřeba pravidelně kontrolovat naplněnost skupiny. Mohlo by se stát, že se z skupiny postupem času někteří spoluhráči odhlásí, a skupina se stane pro LKD nekompletní (min. 4 hráči).</br>\r\n\r\n</div>\r\n\r\n\r\n<!--- VOLBA 3 --->\r\n<a href=\"#\" onclick=\"ukaz(volba3); return false;\">Chci se přihlásit do již existující skupiny</a>\r\n\r\n<div  id=\"volba3\" style=\"display: none;\">\r\nV zásadě existují dvě možnosti. Buď je v existující skupině místo a pak stačí kliknout na \"<b>Přihlásit</b>\" na stránce aktivity LKD nebo v Programu. Pokud již není ve zvolené skupince místo, je třeba doufat, že se třeba někdo odhlásí nebo se přihlásit do skupiny u jiné hry daného běhu.\r\n</div>\r\n\r\n\r\n<!--- VOLBA 4 --->\r\n<a href=\"#\" onclick=\"ukaz(volba4); return false;\">Chci přidat/odebrat místo ve skupině</a>\r\n\r\n<div  id=\"volba4\" style=\"display: none;\">\r\nSkupinu, která nemá pět členů, je možné rozšiřovat. A naopak, u ne zcela obsazených skupin je možné jedno místo zrušit a hrát tak ve čtyřech. Přidávání či odebíraní míst lze provést následovně, ale prosíme dobře se rozmyslete, že opravdu chcete místa na hře pro ostatní vyrušit.\r\n\r\n<ul>\r\n   <li>Přihlaš se na stránkách GC bod svým uživatelským jménem.</li>\r\n   <li>Vyber aktivitu Legendy Klubu Dobrodruhů.</li>\r\n   <li>V seznamu her najdi tu, na kterou jsi přihlášen.</li>\r\n   <li>Pod blokem je uveden seznam hráčů ve skupině a počet volných míst.</li>\r\n   <li>Tlačítky \"<b>odebrat místo</b>\" a \"<b>přidat místo</b>\" je možné měnit počet míst ve skupině v rozsahu 4-5 hráčů.</li>\r\n</ul>\r\n\r\n<b>Poznámka</b>\r\n<br>Pokud chceš, aby nové místo ve skupině obsadil konkrétní člověk, je nutné se s ním dopředu domluvit, aby přihlášení na volné místo provedl bez otálení. Jakmile se totiž skupina rozšíří, je nové místo okamžitě k dispozici všem účastníkům GameConu.</br>\r\n\r\n</div>\r\n\r\n\r\n<!--- VOLBA 5 --->\r\n<a href=\"#\" onclick=\"ukaz(volba5); return false;\">Chci se odhlásit ze skupiny</a>\r\n\r\n<div  id=\"volba5\" style=\"display: none;\">\r\nOdhlášení ze skupiny probíhá jako odhlášení každé jiné aktivity. Stačí u aktivity kliknout na tlačítko \"<b>odhlásit</b>\".\r\n<br></br>\r\n\r\n<b>Poznámka</b>\r\n<br>Pokud bys chtěl, aby bylo po tvém odhlášení místo ve skupině zrušeno, je nutné se domluvit s někým ze skupiny. Ten může provést odebrání uvolněného místa, tak jak je popsáno výše. Samozřejmě platí, že skupinu lze zmenšit pouze o jedno místo na minimum 4 míst.</br>\r\n\r\n</div>\r\n\r\n\r\n<!--- VOLBA 6 --->\r\n<a href=\"#\" onclick=\"ukaz(volba6); return false;\">Chci se přihlásit, ale není volno / volná místa jsou zamčená</a>\r\n\r\n<div  id=\"volba6\" style=\"display: none;\">\r\n\r\n<p>K tomuhle bohužel není žádné přímé řešení. V zásadě můžete:\r\n<ul>\r\n <li>počkat, až se aktivita opět odemkne (viz výše, uzamčení trvá jen omezenou dobu) a pokud tam budou volná místa, přihlásti se na ty</li>\r\n <li>zkusit si to ohlídat v druhé / třetí vlně programu nebo brzy před GC - lidé občas změní svůj program, čímž se uvolní nějaká místa</li>\r\n <li>pokud je někde skupina která snížila počet hráčů (z 5 na 4) zeptat se Apophise nebo Mgr_Holgera co to je za skupinu a zkusit se s nimi dohodnout, zda se k nim můžete přidat</li>\r\n</ul>\r\n\r\n</div>\r\n\r\n<p></p>\r\n\r\n<!-- nemazat -->\r\n\r\n<script>\r\nfunction ukaz(e) {\r\n    e.style.display = e.style.display == \'none\' ? \'block\' : \'none\'\r\n}\r\n</script>', 3);
INSERT INTO `stranky` (`id_stranky`, `url_stranky`, `obsah`, `poradi`) VALUES
(148, 'organizacni-vypomoc', '# Chci pomoct s GameConem\r\n\r\nGameCon by nebyl takový, jaký je, bez obrovského množství dobrovolníků, kteří se na jeho organizaci podílí. Ať už se jedná o přípravy během roku, výpomoc na místě nebo vypravěče, kteří připravují všechny hry. \r\nChceš taky přiložit ruku k dílu? Čti dál! \r\n\r\n## Dobrovolník\r\nZa to, že je GameCon takový jaký je, vděčíme nejen vypravěčům a organizátorům, ale i dobrovolníkům, kteří pomáhají vybudovat jeho zázemí. Pomoc potřebujeme především s přípravou prostor (nošení stolů, lepení plakátů apod), Infopultem a hermanováním v deskoherně.\r\n\r\n###Jak se přihlásit:\r\n- Zapiš se na konkrétní aktivitu v Programu v sekci Organizační výpomoc   \r\nnebo\r\n- vyplň v přihlášce, s čím chceš pomoci a my se ti ozveme\r\nnebo\r\n- se rovnou ozvi na [foo@example.com](mailto:foo@example.com).\r\n\r\n###Co za to?\r\n\r\n- Pokud dorazíš už ve středu a pomůžeš nám s přípravou budovy, budeš mít ubytování ze středy na čtvrtek zdarma a drobné občerstvení.\r\n- Jako poděkování za pomoc získáš slevu na GameCon.\r\n\r\n\r\n## Zdravotník\r\n\r\n- Jsi lékař, zdravotní sestra, záchranář nebo máš alespoň kurz ZZA či jeho ekvivalent? Měl/a bys zájem vypomoct s pár bloky na GameConu na pozici zdravotníka a získat tak slevu na GameCon? Ozvi se Jarikovi na [foo@example.com](mailto:foo@example.com).\r\n\r\n\r\n## Vypravěč\r\n\r\nVypravěč je jednotný pojem, který GameCon používá pro všechny, kteří vedou některou z aktivit – ať už se jedná o deskovku, RPG, larp či jinou hru. Jen díky hráčům, kteří jsou ochotní si připravit hru pro ostatní, může být program na GameCon tak bohatý! Chtěl bys uvést nějakou aktivitu? Ozvi se přímo šéfovi [příslušné sekce](kontakty).\r\n\r\n###Co za to?\r\n\r\n- Jako poděkování za vyprávění aktivity získáš slevu na GameCon a možnost koupit si se slevou modré vypravěčské tričko.\r\n\r\n## Organizátor\r\n\r\nMáš organizační talent, nebo tě napadá konkrétní věc, se kterou bys nám v organizaci mohl pomoct? Spíš než profesionály hledáme samostatné, aktivní jedince, kteří se rádi budou podílet na chodu středně velké organizace. \r\n\r\nAktuálně by se nám hodil někdo ochotný vypomoct s rozpočtem, granty, účetnictvím a podobnými \"zábavnostmi\", pokud by tě tedy zajímalo, jak se řeší **finance** takto velké akce, určitě se nám ozvi. Vždy se také hodí pomocné ruce do **zázemí** nebo do našeho **IT týmu**.\r\n\r\n###Co za to?\r\n\r\n- GameCon organizujeme ve svém volném čase, protože jej máme rádi a chceme, aby se konal i další rok.\r\n- I z celoroční organizace ale plynou výhody. Dle míry zapojení můžeš mít až celý GC zdarma a další benefity.\r\n- Stát se součástí týmu je příležitost nahlédnout do organizace festivalu pro téměř tisíc lidí, naučit se používat profesionální organizační nástroje, a možnost učit se od zkušenějších, ať už tě zajímá grafika, IT, hry, zázemí, dotace nebo cokoliv jiného. Rádi tě zasvětíme do všech tajů organizace a naučíme tě používat programy a metody, se kterými pracujeme.\r\n\r\n\r\n_Pokud se chceš stát součástí týmu, napiš na [foo@example.com](mailto:foo@example.com) a my se ti ozveme zpátky. Pokud přesně nevíš, jak bys mohl/a pomoci, napiš nám, co umíš nebo co by tě zajímalo a společně určitě přijdeme na způsob, jak tě zapojit._\r\n\r\n## Sponzor nebo Partner\r\n\r\nChcete propagovat svou značku na festivalu pro více než 900 lidí? Podpořit GameCon (nejen) finančně, či mít přímo na festivalu stánek? Pro více informací se, prosím, ozvěte [Pavlu Zahradilovi](mailto:foo@example.com), který má na starosti sponzoring, nebo [hlavnímu organizátorovi](kontakty).\r\n', 0),
(149, 'o-doprovodnem-programu', '# Doprovodný program\r\n\r\nGameCon se hodí na začátek zahájit, na závěr zakončit a v mezičase si ho hlavně užít. Jste unavení z deskovek nebo rpgček? Přijďte se odreagovat na improshow, poslechnout si hudbu nebo se zapojit do celohry, která se nese v duchu tématu ročníku. Nic z toho nejsou hry, ale všechno to máme rádi a doufáme, že vy budete mít taky.\r\n', 0),
(150, 'rpg/jak-si-vybrat-hru', '# Jak si vybrat hru\r\n\r\n![](soubory/obsah/rpg/jak-si-vybrat-hru.jpg)\r\n\r\n\r\nVybírejte pečlivě - nejen kvůli sobě\r\n------------------------------------\r\n\r\nHraní na GC má různá specifika. Kromě těch daných formátem akce (čas,\r\nprostory…) mezi ně patří i fakt, že hráči často neznají vypravěče,\r\nostatní hráče a ani systém či prostředí, který si jdou zahrát - a to je\r\ndobře! GameCon tu je (i) od toho, abyste vyzkoušeli něco nového,\r\nnetradičního či nezvyklého a abyste si mohli zahrát s někým novým a\r\nvyzkoušet si, jak hrají ostatní.\r\n\r\nMožná, že víte předem, co si chcete zahrát a jen to hledáte. Nebo možná,\r\nže jste se na něco přihlásili, protože vás to zaujalo (nebo protože na\r\nto jde váš kamarád, protože chcete zaplnit volnou chvíli v programu\r\natp.). **V obou případech je dobré mít co nejlepší představu, o jakou\r\nhru jde** - v prvním případě abyste určitě dostali to, co hledáte, ve\r\ndruhém abyste předem tušili, co od hry očekávat. Je to dobré i pro\r\nostatní hráče, protože zábava se u RPG tvoří společně, takže když hra\r\nnakonec někoho nebaví, pocítí to všichni.\r\n\r\nI když si vyberete dobře, neměli byste zapomínat, že RPG (tak jako\r\nzbytek GC) jsou interaktivní a zábava nepřichází sama, ale podílíte se\r\nna ní i vy a vaši spoluhráči. Zajímavé věci vznikají spoluprací a\r\nskládáním toho, co všichni dohromady do hry vloží - nezapomínejte tedy\r\nbýt otevření i k tomu, jak věc vnímají ostatní a nebojte se případně\r\npřímo zeptat (nejlépe co nejdříve, když dostanete nějaké pochybnosti).\r\n\r\nAby byl váš výběr co nejlepší (nebo předchozí tušení co nejvěrnější),\r\nnabízíme vám několik způsobů, jak se ve hrách zorientovat:\r\n\r\nAnotace\r\n-------\r\n\r\nAnotace hry říká, co je hra zač a o čem bude. Má tři části, z nichž\r\nkaždá vám o hře dává trochu jinou informaci:\r\n\r\n**První odstavec** anotace je **stylizační** a říká něco o atmosféře,\r\nžánru a stylu hry. Roli hraje nejen to, co v něm je napsáno, ale i to,\r\njak to je napsáno. Samozřejmě, nehrajeme si nutně na světové\r\nspisovatele, ale i tak by vám měl tento odstavec ukázat, jak bude hra\r\npůsobit.\r\n\r\n**Druhý odstavec** je psaný příměji a pojednává o **faktickém obsahu\r\nhry** - co konkrétně se v ní bude řešit popřípadě jakým způsobem, jaké\r\nprvky v ní budou přítomné, na které prvky hraní se bude soustředit a tak\r\npodobně.\r\n\r\n**Třetí odstavec** vám krátce představí systém (a případně prostředí,\r\nje-li toto nějak specifické), který hra využívá.\r\n\r\n**Čtvrtý odstavec** může a nemusí být přítomen a případně obsahuje další\r\ndodatečné infomrace, odkazy na pravidla (pro zájemce, *nemusíte* je\r\nznát, pokud není výjimečně uvedeno jinak), na krátké materiály k\r\npřečtení před hrou atp.\r\n\r\nŠtítky\r\n------\r\n\r\nŠtítky naleznete v záhlaví aktivity a obsahují heslovité informace o\r\nrůzných věcech, které se hry týkají. \r\n\r\nMůže jít o informaci, kterou naleznete i v anotaci a která je štítkem\r\nještě více zdůrazněna. Pokud u večerní hry s hororovou anotací najdete\r\nštítek *Horor*, počítejte s tím, že se hra bude na horor opravdu silně\r\nsoustředit.\r\n\r\nDruhá možnost je, že jde o nějakou specifickou informaci. Nenechte se\r\npřípadně zmást tím, že vám štítek nic neříká! Takové štítky jsou určeny\r\nk rychlé orientaci lidí, kteří vědí, o co jde a hledají to (aby to\r\nviděli ihned a nemuseli to hledat uvnitř anotací), ale pokud mezi ně\r\nnepatříte, pak vás to nemá odradit - typicky může jít např. o zkratky\r\npoužitých systémů (WoD, GUMSHOE, WHFR…).\r\n\r\nVypravěči\r\n---------\r\n\r\nA nakonec, ale určitě ne v poslední řadě, si jsme plně vědomi, že\r\nzábavnost hry závisí z velké části i na “chemii” mezi hráči samotnými.\r\nNemůžeme vám sice zprostředkovat profily spoluhráčů, můžeme vám však\r\nalespoň z části představit vypravěče, který hru vede.\r\n\r\nPokud kliknete na jméno vypravěče, přenese vás web na stránku s\r\nprofilem. Ten obsahuje fotku, ale zejména krátké osobní i herní\r\npředstavení, které vám řekne něco o tom, kdo dotyčný je a jak na RPG\r\nhraní nahlíží.\r\n\r\nA samozřejmě, profil obsahuje i seznam všech aktivit, které vypravěč na\r\nGC vede - takže pokud se vám rok předtím s někým velmi dobře hrálo,\r\ntakto můžete snadno najít hry, které povede letos.\r\n\r\n**Pokud si něčím na hře nejste jistí, nebojte se zeptat.** Můžete se\r\nzeptat jejího vypravěče soukromě, můžete se zeptat šéfa OR RPG linie\r\nnebo se můžete zeptat na našem FB. Tak nebo tak odpověď zajisté\r\ndostanete a může to hru hodně ujasnit nejen vám, ale i ostatním.\r\n\r\nObecně vypravěče podporujeme v tom, aby s lidmi ještě před GC o hrách\r\nkomunikovali (obvykle e-mailem), protože jsme zjistili, že to velmi\r\ndobře přispívá ke vzájemnému pochopení - proto vás prosíme, abyste\r\npřípadně věnovali chvíli nějaké té odpovědi, ta 4 a více hodinová hra za\r\ntěch pár minut určitě stojí.', 1),
(151, 'rpg/jak-si-hrani-co-nejvice-uzit', '# Jak si hraní co nejvíce užít\r\n\r\n![](soubory/obsah/rpg/jak-si-hrani-co-nejvice-uzit.jpg)\r\n\r\n\r\nPotřebujeme vaši pomoc!\r\n-----------------------\r\n\r\nDlouhé roky se snažíme systematicky zlepšovat celou linii i jednotlivé\r\nhry, které ji tvoří. Děláme rozsáhlou zpětnou vazbu, sami si děláme\r\nspoustu poznámek a každý rok jsme měli něco, co jste kritizovali a co\r\njsme další rok udělali lépe. Vaší kritiky bylo napříč lety mnoho a my za\r\nní byli rádi, protože jejím výsledkem byla každý další rok lepší a lepší\r\nprogramová linie.\r\n\r\nNedávno jsme ale narazili na problém. U her s nižším hodnocením přestaly\r\nbýt jako důvody uváděny problémy na straně vypravěčů nebo nás\r\norganizátorů a začaly se více a více objevovat problémy s hráči, kteří\r\nsi při hře vzájemně nesedli. Hráči samotní se na GC podle všeho příliš\r\nnezměnili, takže nás potěšilo, že jsme se postupně zbavili všech výtek\r\nna naší adresu - na druhou stranu nás to postavilo před problém: jak dál\r\nzlepšovat hry, když klíč k jejich dalšímu zlepšení není v našich rukou?\r\n\r\nVšichni se chceme na GC bavit co nejvíce a hrát co nejlepší hry - další\r\nkrok ke zlepšení teď ale podle všeho už není na naší straně, ale na\r\nstraně vás, hráčů.\r\n\r\nKdo se chce bavit, vybírá\r\n-------------------------\r\n\r\nKaždá hra je jiná a GC nabízí velmi širokou paletu her jak co do\r\nsystémů, tak co do stylů, kterým jsou hrány. Každého také baví hrát něco\r\njiného - a každého naopak něco nebaví. Stává se, že si hráči občas\r\nomylem vyberou jinou hru, než jakou by chtěli, a proto jsme se letos\r\nzaměřili na usnadnění a zkvalitnění vašeho vlastního výběru:\r\n\r\nDál jsme vybrousili anotace, abyste se z nich dozvěděli co nejvíce.\r\nŠtítky, které doteď sloužily jen k rychlé orientaci v pár věcech\r\n(systémy), jsme se rozhodli použít v širším pojetí a dodat do nich\r\ninformace o stylu, na nějž se bude hra zaměřovat. A v neposlední řadě\r\ndále pracujeme na profilech našich vypravěčů.\r\n\r\nProsím věnujte svému výběru pozornost. Když víte, co chcete, tak vám to\r\nusnadní to skutečně najít. Když zkoušíte něco nového, tak vám to dá\r\npředem mnohem lepší představu, o čem to bude. A pokud jdete na hru kvůli\r\nkamarádům nebo prostě protože jen máte zrovna volno, tak vám to řekne,\r\nna co se “naladit”.\r\n\r\nZ mnoha vlastních i GameConových zkušeností víme, že očekávání dělají\r\nopravdu hodně a že tatáž hra může vyvolat “super” nebo “meh” dojem jen\r\npodle toho, jak se k ní z kraje postavíte a jak moc nakonec odpovídá\r\ntomu, co jste od ní čekali, takže výběr určitě nezanedbávejte.\r\n\r\nJak jsme již uvedli, mnoho, loni už většina, her s nižším hodnocením ve\r\nzpětné vazbě byly hry, které samy o sobě nebyly nijak špatné, ale hry,\r\nna nichž se bohužel sešli hráči, kteří si vzájemně nesedli. Samozřejmě,\r\nne všichni si nutně vždy “sednou” - ale někdy to není o osobní chemii,\r\nale o věcech, které je možné ovlivnit:\r\n\r\nKomunikujte\r\n-----------\r\n\r\nZaprvé, když si hry vyberete pečlivě, zmenší se šance, že se na hře\r\nsejdou lidé, co od ní čekají něco úplně jiného. Stále samozřejmě zůstává\r\nprostor pro různý výklad mnoha věcí - ten se snažíme eliminovat před-GC\r\nkomunikací o hře. Zkušenost i zpětná vazba ukazují, že komunikace o hře\r\npřed GC mezi hráči a vypravěčem - a i mezi hráči samotnými - velmi\r\npomáhá tvořit lepší a zábavnější hry.\r\n\r\n**Pokud od hry něco konkrétního očekáváte / chcete**, dejte to vědět -\r\nnejlépe i ostantím hráčům, ale alespoň vypravěči. Pokud jste si hru\r\nvybrali ze specifického důvodu (např. chcete si zkusit systém - nebo\r\ndokonce něco konkrétního v daném systému), řekněte to. Zaprvé vypravěč\r\nmůže hru uzpůsobit, abyste to skutečně dostali, zadruhé ostatní budou\r\nvědět, že o to stojíte. Pokud u hry ale naopak něco nechcete (např. jste\r\nsi jí vybrali právě protože vypadá, že pravidla moc řešit nebude),\r\nřekněte to také - možná ještě víc. Hra je jen jedna a pokud by byly\r\npreference hráčů v něčem různé, tak její vypravěč ujasní, na kterou\r\nstranu zájmu se hra svým pojetím přiklání.\r\n\r\n**Pokud si něčím nejste jistí**, zeptejte se na to. Zcela vážně. Zní to\r\ntriviálně, ale lidé mají často různé zábrany někoho oslovit a zeptat se\r\n- prosím překonejte je. Lze se ptát vypravěče, šéfa RPG sekce nebo třeba\r\nna GC FB stránce, nicméně ta vazba mezi otázkou a odpovědí je důležitá a\r\nopravdu pomáhá.\r\n\r\n**Nebojte se komunikovat i během hry**. Pokud vám něco není jasné,\r\nnebojte se zeptat. Co je důležitější - pokud v průběhu hry zjistíte, že\r\nse hra ubírá trochu někam jinam, než by vás bavilo, tak to ve vhodnou\r\nchvíli sdělte - ať už protože byste chtěli přidat trochu akce nebo\r\nnaopak trochu zpomalit a odehrát víc interakcí mezi postavami nebo když\r\nvám přijde, že by hra mohla trochu zrychlit tempo, neváhejte to říct. I\r\nvypravěči jsou jen lidé a ne vždy odehrají vše dokonale - podobná krátká\r\ndiskuse o stavu hry a jejím vývoji určitě není nějakým útokem na\r\nvypravěče, je naopak účastí na hře a na tom, aby všechny bavila co\r\nnejvíce. Samozřejmě, může se stát, že se představy mezi hráči budou\r\nlišit - bez diskuse si to ale nevyjasníte. Vždy platí:\r\n\r\nHrajte s ostatními, ne se sebou\r\n-------------------------------\r\n\r\nČas od času se to stane kdekomu: přihlásíte se na hru, od níž něco\r\nočekáváte, hrozně se na to těšíte a pak se na hře potkáte s hráči, kteří\r\nonu hru vidí trošku jinak. Chyba nemusí být u nikoho - to co se zamýšlí\r\na to co se odehraje nejsou nikdy zcela totožné věci. Problém nastane,\r\nkdyž jedna strana začne dál slepě razit svou představu a ignorovat to,\r\njak hru vidí ostatní.\r\n\r\nRPG nemají do kamene tesanou formu, která by byla naplněna. Jeden a\r\ntentýž scénář hraný různými skupinami vždy vytvoří různé příběhy, které\r\nse soustředí na různé věci, které hra nabízí. To, jak hra nakonec vypadá\r\nje souhrnem toho, co do ní všichni dohromady vloží. Když různí lidé\r\nprotěžují různé věci, tak to není na škodu - právě naopak zkušenost celé\r\nherní komunity říká, že ty nejlepší hry vznikají právě tehdy, když různí\r\nhráči vyzdvihují různá témata. Ale aby to fungovalo, hráči nesmí hrát\r\n“slepě” - i když protěžují to své, tak aby to bylo ku prospěchu, tak je\r\nstále potřeba, aby vnímali i ostatní - a to jak ve smyslu toho aby\r\nreflektovali ostatní témata ve hře, tak ve smyslu toho aby poznali, kdy\r\nse svým tématem zase na chvíli trochu ustoupit do pozadí.\r\n\r\nPíšeme zde “téma”, ale nemusí se to týkat jen herních - příběhových -\r\ntémat. To samé platí i pro různé přístupy ke hře (více pravidel / více\r\ndramatu) nebo samotnému ukázkovému hraní (více vysvětlování / více volné\r\nzábavy). Odkážeme se zpátky k již napsanému: nebojte se komunikovat.\r\nPokud máte dojem, že intuice selhává - ať už u jiných hráčů, nebo u vás\r\nsamotných - nebojte se zahájit krátkou výměnu o tom, jakým způsobem ve\r\nhře pokračovat.\r\n\r\nZábava u RPG je v podstatě synergie - čím více se baví jednotliví lidé,\r\ntím více se baví všichni a tím lepší hra je. Tj. čím více se bavíte\r\nsami, tím více se mohou bavit i vaši spoluhráči - ale i vy sami se\r\nbudete bavit lépe, pokud se necháte ovlivnit tím, jak (a čím) se baví\r\nostatní.\r\n', 2),
(152, 'o-deskoherne', '# Deskoherna \r\n\r\n\r\nDeskoherna znamená volné hraní moderních deskových a karetních her. Na GameConu jich najdete doslova stovky. Neznáte hru? Místní hermani (lidé v oranžových tričkách s nápisem \"herman\") vám ji rádi vysvětlí. Nemáte spoluhráče? Nebojte se oslovit lidi kolem - i oni si chtějí zahrát.\r\n\r\nDeskoherna je otevřena __od čtvrtka 14:00 do neděle 15:00__ (zavřeno máme jen denně od 3:00 do 8:00). __Vstupné je dobrovolné__. Jste-li náruživější hráči, nezapomeňte prozkoumat také sekci [epických deskovek](http://gamecon.cz/epic) či [turnajů](http://gamecon.cz/turnaje). \r\n', 0),
(153, 'manual-vypravece', '## Manuál vypravěče\r\n\r\n__Před GC__\r\n\r\n1. __Nepoužíváme hromadné e-maily__  \r\n Pokud je potřeba využít hromadný e-mail, tak použij vždy skrytou kopii.\r\n\r\n__Na GC__\r\n\r\n1. __Dostav se na shromaždiště - u maskota__  \r\n15 minut před začátkem aktivity, kde na tebe bude čekat organizátor (spojka). Nezapomeň propisku. :-) \r\n<!- Jarik-poznámky ... příp. na Infopult (platí pro Wargaming, Epic, Deskovky, Přednášky a Workshopy) ->\r\n1. __Vyzvedni prezenčku__  \r\nneboli seznam přihlášených hráčů, kterou pro tebe spojka má. Na prezenčce najdeš číslo místnosti, blok a patro, kde se aktivita koná.\r\n1. __Čekej u maskota__  \r\na eviduj docházku. Odšrktej hráče na prezenčce.\r\n1. __Vyzvedni náhradníky__  \r\nPokud nějaký hráč nedorazil, je vhodné se s ním telefonicky spojit. Pokud nějací hráči chybí, pět minut před začátkem vyzvedni náhradníky. Připiš náhradníky na prezenčku&nbsp;–&nbsp;jménem, příjmením a nickem.\r\n1. __Dej prezenčku spojce__  \r\na to ideálně v čas oficiálního začátku aktivity. \r\n1. __Po skončení zkontroluj místnost__  \r\nMístnost uveď do původního stavu. Dodržuj prosím plánovanou délku aktivity.\r\n\r\n\r\n\r\n<img src=\"files/design/warning.png\" style=\"position:absolute;margin:-1px 0 0 -4px\">\r\n<p style=\"margin-left:21px\">Všechny případné změny aktivity (místa, času, zpoždění...) a potíže prosím řeš s MODem <b>(tel: +420 735 531 899)</b>, ten ti rád pomůže, ideálně i se šéfem tvé sekce</p>', 0),
(155, 'celohra', '# Celohra\r\n\r\n## Co je to Celohra?\r\n\r\nCelohra je jediná hra, která se ti neokouká. Každý rok je psaná na aktuální téma GameConu, má nový příběh i herní mechaniky. Je to ideální volnočasová aktivita pro chvíle, kdy zrovna nejsi na programu žádné z hlavních linií. Lze ji začít hrát kdykoliv. Hraj dokud je čas, příští rok už na tebe zase bude čekat něco zbrusu nového.\r\n\r\n\r\n## Téma letošního ročníku\r\n\r\nVěříme, že na GameConu najdete spoustu aktivit, které vám umožní bojovat proti drakům. Jak ale taková hra vypadá z pohledu draků?\r\n\r\nVyklubej se z vejce, sežer pár ovcí a odnes si zlato do své jeskyně. Život draka zní lákavě. Do prvního setkání s někým, kdo by chtěl prodat jeho pařáty nebo ocas na nejbližším trhu. \r\n\r\nVe volných chvílích se může skupinka draků porozhlédnout po okolí své jeskyně. Většinou tam potkají trpaslíky, elfy, barbary či jiné hrdiny, kteří umí ozvláštnit jídelníček jinak plný ovcí.\r\n\r\n\r\n## Letošní pravidla<sup>[1](/celohra#fn:footnote)</sup>\r\n\r\nBudou zveřejněna později.\r\n\r\n## FAQ aneb otázky a odpovědi\r\n\r\n### Jaká bude letos hra?\r\n\r\nTento rok je hra čistě kooperativní. Všichni hráči Celohry se stávají draky a snaží se dohromady sehnat co nejvíce zlata. Plnění jednotlivých stanovišť může být strategicky výhodné v menších skupinách hráčů.\r\nHráči mohou během hry draky vylepšovat v jejich základních vlastnostech či pro ně mohou získat nové dovednosti. Své síly pak mohou poměřit s hrdiny (tzn. nepřáteli) v některém z gamebooků.\r\n\r\n### Jak začít hrát?\r\n\r\n- Verze „Čtvrtek večer“: Ve čtvrtek večer bude vypsána hromadná aktivita pro existující hráče a hráče, kteří by se chtěli přidat. Nejlepší možnost, pokud se nestihneš přidat dřív.\r\n- Verze „Chci si na to přijít sám“: Vyhledej některé ze <span style=\"color:green\">zelených</span> stanovišť. Většina z nich by tě měla popostrčit správným směrem.\r\n- Verze „Rychle a efektivně“: Vyhledej některého z již hrajících hráčů. Obvykle už ví, jak hra funguje, a nové síly umí dostat do hry „Rychle a efektivně“. \r\n\r\n\r\nZmatené (i nezmatené) otázky k Celohře lze pokládat na adrese <foo@example.com>.\r\n\r\n---\r\n<ol>\r\n<li id=\"fn:footnote\">do začátku Gameconu se mohou drobně měnit</li>\r\n</ol>\r\n<img src=\"https://segmentation-fault.cz/hit?action_name=CelohraPravidla\" style=\"border:0\" alt=\"\" />', 0),
(156, 'larpy/bozi-larp', '# Jak si zahrát boží larp\r\n\r\n![](soubory/obsah/larpy/bozi-larp.jpg)\r\n\r\n\r\nZamyslete se, jaká hra by vás lákala. \r\n--------------\r\n\r\n- Vážná nebo odlehčená, vztahovka nebo argumentační, dobrodružná nebo komediální, improvizační nebo skriptovaná? Je pravděpodobné, že vám nesednou úplně všechny larpy, které GC nabízí, ale díky anotacím, si můžete vybrat ten, jehož téma a styl hry vás osloví. \r\n\r\n- Pokud je váš vysněný larp již obsazený, nebuďte smutní a klikněte u hry na **tlačítko “sledovat”**. Můžete sledovat i více her ve stejném čase. Jakmile se uvolní nějaké místo, systém vám pošle e-mail a vy se budete moci přihlásit (pozor - systém vás nepřihlásí automaticky, musíte být tedy rychlí). \r\n\r\n- **Larpový mor** (vážné infekční onemocnění s výrazným dopadem na společnost; zdroj: wikipedia.org): časté onemocnění postihující hráčskou populaci krátce před herní událostí způsobující uvolnění míst na jinak zcela nedostupných hrách. Pokud sledujete volná místa, následujte prosím bod 6. Buďte na příjmu - můžeme vám zavolat na začátku bloku, že se náhle uvolnilo místo a budeme vás na rukou nosit, pokud nám zvednete telefon a přijdete si zahrát - win-win.\r\n\r\nKomunikujte s vypravěčem.\r\n------------\r\n\r\n- Od svého vypravěče dostanete před Gameconem e-mail, ve kterém vám napíše informace o hře, jaký je vhodný kostým a možná se vás bude ptát, jestli si chcete zahrát raději Jeníčka nebo Mařenku (nebo možná i jiné postavy, pokud ve hře jsou), odpovězte mu, prosím, co nejdříve. Pokud máte otázky ke hře nebo si nejste jistí, jestli jste si vybrali správně, využijte toho a zeptejte se.\r\n\r\nNachystejte si kostým.\r\n--------\r\n\r\n- Asi neexistuje larp, který by s kostýmem nebyl lepší než bez kostýmu, i když se hodně z nich dá hrát i v civilu. Nemusíte se bát, že byste doma ve skříni nenašli nic vhodného - i košile a černé kalhoty udělají úplně jinou atmosféru než tričko s potiskem a šortky. Protože co? Atmosféra je základ božího larpu!\r\n\r\n- Pokud sledujete volná místa na více hrách, nebo tušíte, že si budete chtít zahrát larp, kdyby se něco uvolnilo, v zásadě nic nezkazíte, pokud si s sebou na Gamecon vezmete košili a kalhoty případně halenku a sukni; tento “základ” kostýmu se dá využít téměř na jakýkoliv larp.\r\n\r\n- Pokud přijdete na hru jako náhradník a žádný kostým s sebou nemáte, nemusíte se bát, budeme mít letos nějaké kostýmy v zásobě a v případě potřeby přiskočíme a něco vám půjčíme.\r\n\r\nNeodhlašujte se! A když už musíte, tak prosím co nejdříve.\r\n-------------\r\n\r\n- U většiny larpů platí, že aby se mohly uskutečnit, je potřeba plný počet hráčů. Pokud tedy na poslední chvíli vyměníte larp za workshop žonglování s míčky, je to pro nás velký problém (byť rozumíme, že žonglování je super). Není totiž vůbec jisté, že se na poslední chvíli na vaše místo někdo přihlásí a bez vás - tedy v neúplném počtu - se hra nedá hrát. \r\n\r\n- Chápeme, že jsou situace, kdy se člověk odhlásit musí, pak vás ale prosíme, abyste tak učinili ihned, jakmile zjistíte, že nemůžete hrát. Velmi tím zvýšíte šanci, že se na vaše místo ještě někdo přihlásí. Nejnešťastnější situace, která se však bohužel stále stává, je, že nemůžete dorazit, ale neodhlásíte se v systému. Shánění náhradníků na začátku herního bloku je pro nás skutečně otravná a stresující práce. Pokud nás jí dokážete ušetřit, budeme vás milovat a organizovat pro vás jen ty nejlepší larpy světa. =)\r\n\r\nPřijďte včas na sraz.\r\n--------\r\n\r\n- Může se zdát, že drobné zdržení u stánku s kafem (víme, bývá tam pekelná fronta) nehraje roli, ale vězte, že v napěchovaném gameconním programu se každých 5 minut počítá. Minimálně je to 5 minut růstu žaludečních vředů vypravěče, který už žhaví všechny telefonní dráty ve stresu, že mu chybí hráč a hra se nebude dát hrát.\r\n\r\nBuďte na příjmu\r\n----------\r\n\r\n- Pokud jste přihlášení na nějaký larp nebo sledujete volná místa, buďte prosím na příjmu na svém telefonním čísle, které jste zadali při registraci. Pokud se zdržíte u stánku s kafem (což se vám již určitě stávat nebude, neboť jste četli bod 5) nebo pokud někdo na hru nebude moci dorazit a uvolní se místo pro náhradníka, budeme vám volat! Buďte na to připravení. Je frustrující mít na seznamu 5 náhradníků a žádnému se nedokázat dovolat.\r\n\r\nPoslouchejte vypravěče\r\n------\r\n\r\n- Vypravěč vás má připravit na hru, kterou se právě chystáte hrát. Řekne vám, jak zacházet s informacemi ve hře, jak probíhají interakce mezi postavami a také jak reagovat ve specifických situacích. Možná si některé mechaniky či situace vyzkoušíte už v předherních workshopech. Věnujte této přípravě náležitou pozornost, i když máte dojem, že jste to už slyšeli tisíckrát. Každá hra je trošku jiná.\r\n- **Ptejte se před hrou**. Něco vám není jasné už během vysvětlování? Zeptejte se. Žádná otázka není hloupá.\r\n\r\nA teď už k hraní!\r\n--------\r\n\r\n- **Buďte aktivní**. Žádný boží larp se ještě neodehrál tak, že každý seděl v koutě a s nikým neinteragoval.\r\n- **Pozorně si přečtěte svoji postavu** - všechno, co je napsané ve vaší postavě, je důležité! Tajemství, informace a případně i předměty jsou obvykle myšleny jako náboje, které hru rozpohybují. Většinou tedy není opravdovým “cílem” je za každou cenu udržet, ale mnohem zajímavější může být je ve správnou chvíli vypustit do světa. Kdy je ta správná chvíle už závisí na vás jako hráči, vaší postavě i průběhu té konkrétní hry. \r\n- Myslete na to, že **děláte hru boží nejen pro sebe, ale i pro ostatní hráče**.  Pokud máte něco řešit se třemi postavami ve hře a vy se rozhodnete jednu z nich úplně ignorovat, může se stát, že tím onen hráč přijde o důležitou část své hry. \r\n- Pokud během hry v něčem tápete, nudíte se nebo nevíte, co máte dělat, **zeptejte se vypravěče**, rád vás nasměruje nebo poradí, co dělat dál nebo jakou linku byste ještě mohli rozehrát. Nejlépe učiníte, když se zeptáte někde v ústraní, ideálně tak, aby to ostatní hráči neslyšeli.\r\n- **Nevystupujte z role**. V komorním larpu není zvykem mluvit mimo roli, všechno byste měli vyřešit “v roli”. Pokud se vás jiný hráč zeptá na něco, co nemáte napsáno v postavě, ale pravděpodobně by to vaše postava věděla - např. “Kam jsi chodil na základní školu?” - klidně si něco vymyslete, pokud to není napsáno v postavě, pravděpodobně to není nijak důležité. Stejně tak pokud si ostatní hráči do hry nějakou informaci vymyslí, hrejte s tím, jako by to byla pravda. Např. pokud někdo řekne “Hele pamatuješ, jak jsme spolu byli tehdy na rybách?” a vy nemáte tušení o čem to mele, vezměte to do hry a nadhoďte třeba něco jako “Jóó, myslíš, jak jsme tenkrát chytili tu obrovskou štiku?”, ale můžete říct třeba i “Prosímtě, tos byl určitě s nějakou tou svou cuchtou, ty a ta tvoje skleróza!”, záleží na vás, jak se vám to zrovna hodí do hry.\r\n\r\nDíky, že jste dočetli až sem a těšíme se na všechny boží hry, které si s vámi zahrajeme!\r\n', 1),
(157, 'test4', '', 0),
(158, 'info-po-gc', '# Co po GameConu\r\n\r\nBudeme moc rádi, když se s námi podělíš o své __zážitky a fotky__ na <a href=\"https://www.facebook.com/gamecon/\" target=\"_blank\">Facebookové stránce GameConu</a>, <a href=\"https://discord.gg/hwfyqDYB2h\" target=\"_blank\">Discordu</a> nebo na <a href=\"https://www.instagram.com/gamecon_cz/\" target=\"_blank\">Instagramu</a> pod _#gamecondovasirodiny_\r\n\r\nPokud tě GameCon bavil a měl(a) bys zájem příští rok tuhle akci spoluorganizovat nebo odvyprávět nějakou hru, všechno potřebné info k tomu najdeš [zde](https://gamecon.cz/organizacni-vypomoc).\r\n\r\n## Dotazníky\r\n\r\nV tomto dotazníku se ptáme co se ti na GameConu líbilo, případně nelíbilo nebo ti tu něco nezbytně chybí? Napiš nám to!\r\n\r\n\r\nTady můžeš organizátorům a vypravěčům říct, jak se ti líbila každá jednotlivá hra.\r\n\r\n\r\n\r\n\r\nPředem moc děkujeme za vyplnění zpětné vazby, skutečně jsou to pro nás klíčové informace. Do příštího roku se pak pokusíme festival vyladit a realizovat tvoje nápady. Případně můžeš GameCon zlepšovat rovnou zevnitř jako organizátor nebo vypravěč, více informací k tomu najdeš [zde](https://gamecon.cz/organizacni-vypomoc).\r\n\r\n## Další akce:\r\n\r\n- Pražský <a href=\"http://zizcon.cz/\" target=\"_blank\">ŽižCon</a>, obvykle v půlce září.\r\n- Pravidelná <a href=\"http://www.d20.cz/skupina/186/diskuze/51750.html\" target=\"_blank\">otevřená hraní DnD v Brně</a> pod záštitou <a href=\"http://www.d20.cz\" target=\"_blank\">Kostky</a>\r\n- Pravidelné hraní larpů v Brně <a href=\"https://hrajularpy.cz/\" target=\"_blank\">Hraju larpy</a>\r\n', 0),
(159, 'celohra/maxitrajler', '# Maxitrajler Kosmické gildy\r\n\r\n_Maxitrajler momentálně zeje prázdnotou, zkus jej navštívit později._', 1),
(160, 'celohra/duna', '# Celohra\r\n\r\n## Hlas lidu\r\n\r\n### K čemu je papírek z Infopultu -- Hlas lidu\r\n\r\nOba velkorody na Duně spolu soupeří jak o koření, tak o moc v Landsraadu.\r\nKaždý rod je ovšem pouze tak silný, jak silní jsou lidé, kterým vládne.\r\n\r\n#### Celohry se chci zúčastnit\r\n\r\nPomocí Hlasu lidu si lze zajistit nějaké pěkné místo v jednom z velkorodů.\r\nKaždý hlas může rodu přinést velkou výhodu ve hře, Hlas mi slouží jako protiváha při vyjednávání.\r\nSvou hodnotu mohu ještě zvýšit, pokud se mi podaří sehnat nějaké další Hlasy od jiných lidí.\r\n\r\n#### Celohru hraji a již mám své místo v rodě\r\n\r\nSvému rodu mohu zajistit ještě větší moc a slávu tím, že budu aktivně hledat další stoupence.\r\nPokud budu dobře vyjednávat, mohu do našeho rodu přijmout nové pomocníky a třeba od nich získat i nějaký ten Hlas, který můžeme použít v některém z hlasování.\r\n\r\n#### Celohra mne nezajímá, nechci ji hrát\r\n\r\nSvůj Hlas mohu věnovat tomu rodu, který mi přijde sympatičtější nebo třeba tomu, kdo mi za něj napíše hezčí básničku.\r\nKaždý Hlas má svou cenu a představivosti se meze nekladou.\r\nPozor! I můj hlas má šanci ovlivnit celkový výsledek Celohry.\r\n\r\n### Jak Hlas lidu využít\r\n\r\nV posledním cyklu pátečního i sobotního dne (tj. ve 23:15) proběhne v Landsraadu velké hlasování.\r\nRod, který hlasování vyhraje, získá odměnu, která mu může pomoci zvrátit misky vah v souboji o nadvládu na Duně.\r\n\r\nKaždé hlasování vyhraje ten rod, který do hlasovací obálky umístí více Hlasů lidu, druhé místo neexistuje.\r\nOdměnou v pátečním hlasování bude blíže neurčené (ale podstatné) množství koření, v sobotu se hlasuje o bodech vlivu.\r\nKaždý Hlas lidu lze použít pouze v jednom z hlasování.\r\n\r\n\r\n## Co je to Celohra?\r\n\r\nCelohra je jediná hra, která se ti neokouká. Každý rok je psaná na aktuální téma GameConu, má nový příběh i herní mechaniky. Je to ideální volnočasová aktivita pro chvíle, kdy zrovna nejsi na programu žádné z hlavních linií. Lze ji začít hrát kdykoliv. Hraj dokud je čas, příští rok už na tebe zase bude čekat něco zbrusu nového.\r\n\r\n\r\n## Téma letošního ročníku\r\n\r\nPíše se rok 9850, 78. padišáh Vutier Corrino II., imperátor Známého vesmíru, má nelehký úkol. Musí rozhodnout, kterému rodu přidělí správu imperiálního léna na Arrakis. Vzhledem k okolnostem se rozhodne pro unikátní experiment. Pro tentokrát správou pověří dva velké rody najednou a doufá, že se tím podaří situaci s kořením nějak stabilizovat. Těmito rody nejsou žádné jiné než rod Igal a rod Spokan.\r\n\r\nPro ty, co u sebe zrovna nemají šigafilament s encyklopedií, Celohra se odehrává na Duně (Arrakis). V čase dávno předtím, než by mohli nastat události popisované ve filmu či knize Duna (pro představu, Paul Atreides se narodí až za 325 let).\r\n\r\n\r\n## Letošní pravidla<sup>[1](/celohra#fn:footnote)</sup>\r\n\r\n- Celohra začíná ve čtvrtek po zahájení a končí v neděli (přesný čas bude upřesněn).\r\n- Stanoviště Celohry je možné navštívit a plnit na nich úkoly samostatně nebo ve skupině.\r\n  Doporučujeme prohlédnout si herní mapu u infopultu.\r\n- <span style=\"color:green\">Zelená</span> stanoviště si může přečíst a splnit kdokoliv.\r\n  Ostatní stanoviště smíš navštívit pouze, pokud splňuješ uvedenou podmínku pro vstup na stanoviště.\r\n  Stanoviště označená omezením na příslušnost k rodu nesmíš navštěvovat, pokud nejsi členem daného rodu, ani se nesmíš zdržovat v jejich blízkosti.\r\n- Některé z dalších barev stanovišť se ti mohou otevřít na základě tvého postupu hrou a v důsledku voleb, které během hry uděláš.\r\n- Pokud se nejedná o stanoviště cizího rodu, smíš si přečíst zadání úkolu na stanovišti bez herních následků a dle něho se rozhodnout, zda stanoviště smíš/chceš plnit.\r\n  Okukování těchto informací a zjišťování co by se kde dalo splnit, aby ti to pomohlo, je součást <strike>života na Duně</strike> hry, ale pozor na další bod.\r\n- Jakmile se rozhodneš, že stanoviště chceš splnit, nelze už couvnout zpět.\r\n  Obzvláště, pokud si již provedl některé z kroků souvisejících s plněním stanoviště (odevzdání materiálu, otevření obálky, započetí plnění úkolu, vzetí pomůcky k plnění stanoviště do ruky apod.).\r\n  Pokud má neúspěšný pokus o splnění stanoviště nějaký herní efekt, plně se aplikuje.\r\n- Žádný z hráčů se nesmí vrátit na stejné stanoviště dříve než za půl hodiny.\r\n- Nemusíš si příliš lámat hlavu s volbou rodu. Z pohledu pravidel a herních mechanik se neliší, rozdíl může být v tom, jak rody sami sebe prezentují (roleplaying).\r\n\r\nŽe v těch pravidlech nevidíš tu strategii? Dlouhá pravidla pokrývající všechny možné herní situace by přece nikdo nečetl. Všechno, co potřebuješ vědět, bude napsáno přímo na stanovišti. Stačí si vždy přečíst text stanoviště, které tě hrou provede. Hra není lineární. Kam dál po splnění jednoho stanoviště je na tobě a tvé úvaze „kterou odměnu za splnění bys tak potřeboval“.\r\n\r\n\r\nHra funguje na principu fair-play. Realizaci některých herních situací plně vkládá do rukou hráčů a budou takové, jaké si je navzájem (ve svém rodě) uděláte.\r\nCelohra je hodnocená aktivita a bude možné v ní získat drobné výhry. Hlavní složkou hodnocení je pozitivní přínos pro svůj rod, viditelnost v týmu a Celohrě jako takové a celkové zapojení do hry.\r\n\r\n\r\n## FAQ aneb otázky a odpovědi\r\n\r\n### Proč nehrajeme za Atreidy a Harkoneny?\r\n\r\nVzhledem ke známosti a pověsti těchto rodů by hráči Celohry měli příliš rozdílné podmínky hry za jednotlivé rody a hra by pro ně byla nevyvážená. Navíc by vlastnictví takového jména mohlo být pro hráče příliš svazující. Proto jsme se rozhodli dát šanci některým z méně známých rodů a dát možnost hráčům, kteří se do Celohry přihlásí před GameConem, image rodu výrazně ovlivnit.\r\n\r\n\r\n### Jaká bude letos hra?\r\n\r\nBudou se stavět a vylepšovat kombajny na těžbu koření. Proti červům je budou chránit ornitoptéry a karyóly. Rodová garda bude chránit vaše koření před ostatními rody, nebo se možná raději pokusí nějaké získat.\r\nŽe vojenské strategie nejsou nic pro tebe? Láká tě spíše učení Bene Gesseritu? Nebo si snad přeješ konečně zazářit v matematice a stát se mentatem nebo navigátorem? Tyto a další specializace bude možné získat po přidání se na stranu některého z rodů, který nadějným studentům může uhradit vzdělání na renomovaných školách.\r\n\r\nFormálním zařazením by hra pravděpodobně zapadala mezi semi-kooperativní (ekonomické) strategie. Hra uvnitř zvoleného rodu je (měla by být) silně kooperativní, nicméně si jistě budete přát druhý rod porazit, nebo alespoň snížit šance na jeho vítězství.\r\n\r\n\r\n### Jak začít hrát?\r\n\r\n- Verze „Čtvrtek večer“: Ve čtvrtek večer je vypsaná hromadná aktivita pro členy rodů a hráče, kteří by se chtěli k některému z rodů přidat. Nejlepší možnost, pokud se nestihneš přidat dřív. „Zde“ se později objeví zápis ze čtvrteční prezentace rodů.\r\n- Verze „Chci si na to přijít sám“: Vyhledej některé ze <span style=\"color:green\">zelených</span> stanovišť. Většina z nich by tě měla nasměrovat k volbě rodu.\r\n- Verze „Rychle a efektivně“: Vyhledej některého z již hrajících hráčů. Obvykle už ví, jak hra funguje, a nové síly pro svůj rod umí dostat do hry „Rychle a efektivně“. Pozor! Volbou hráče, kterého o pomoc požádáš, pravděpodobně přímo ovlivňuješ svůj budoucí rod.\r\n\r\n\r\n### Jak se zapojit do hry ještě před GameConem?\r\n\r\nZkušení hráči již tuší, že před samotným GameConem bývá vypsána výzva, jejíž splnění ti umožní zapojit se do hry ještě před samotným GameConem a získat drobnou herní výhodu do začátku.\r\nCo jsme na tebe připravili letošní rok? Tentokrát nebudeme předepisovat _CO_ máš udělat. Je jen na tobě, zda pošleš uměleckou fotografii, vyrobíš šperk, natočíš film nebo vymyslíš novou cvičební sestavu.\r\nDůležité však je, že tvoje dílo musí obsahovat koření, písek, modrou barvu a maximálně tři kapky vody (více je samozřejmě lépe, ale plýtvání vodou je přísně zakázáno).\r\nHráči, kteří se zapojí do hry před GameConem, mohou mít možnost pro svou postavu získat „tu správnou” krev a nemusí rodu „jen“ sloužit.\r\n\r\nPrezentaci svého díla pošli **do 30.6.2022** na adresu <foo@example.com>. Zpráva musí obsahovat tvoje jméno, příjmení a GameCon ID (variabilní symbol z financí).\r\nZasláním e-mailu souhlasíš s případným zveřejněním svého díla na stránkách či Facebooku GameConu. Na stejné e-mailové adrese lze pokládat zmatené (i nezmatené) otázky k Celohře.\r\n\r\n\r\n---\r\n<ol>\r\n<li id=\"fn:footnote\">do začátku Gameconu se mohou drobně měnit</li>\r\n</ol>', 0),
(161, 'celohra/hospoda/stul-u-okna', '# Hospoda\r\n\r\n## Stůl u okna\r\n\r\n_Na rozdíl od ostatních stolů, je u tohoto o poznání světleji. Čím větší světlo, tím větší hluk. U stolku sedí hlouček mladších lidí a o něčem se hlasitě dohadují._\r\n\r\nZrzka v modrém svetru: „Já jsem se přihlásila na ten nový LARP.“  \r\nBlonďák s chapadlem na triku: „No jo, ale ten je až večer. Co budem dělat odpoledne?“  \r\nTýpek v roztrhaných džínách: „Můžeme zkusit okouknout tu Hlavňohru.“  \r\nRoztomilá brunetka: „Celohru?“  \r\nTýpek v roztrhaných džínách: „Jo, přesně tu.“  \r\nZrzka v modrém svetru: „A nezabere nám moc času?“  \r\nBlonďák s chapadlem na triku: „No tak můžeme ji jenom tak okouknout a uvidíme. Nemusíme to moc hrotit, ne?“  \r\nBlonďák s chapadlem na triku: „Stejně ji prej hrajem tak jako tak.“  \r\nRoztomilá brunetka: „A za koho budem hrát?“  \r\nTýpek v roztrhaných džínách: „Nějak si asi budeme muset někdy vybrat.“  \r\nRoztomilá brunetka: „A co když bude zrovna příjem do frakce do které chci, zavřený?“  \r\nBlonďák s chapadlem na triku: „Nemůžeme chtít všichni zachránit svět. Někdo musí být \r\ntaky na druhé straně.“  \r\nRoztomilá brunetka: „A nešlo by si místo nějak zarezervovat?“  \r\nBlonďák s chapadlem na triku: „Víš co, zkusíme se zeptat v rohu, tam by mohli něco vědět.“\r\n\r\n[Přisednout si jinam…](/celohra/hospoda)', 1),
(162, 'celohra/hospoda/stul-v-rohu', '# Hospoda\r\n\r\n## Stůl v rohu\r\n\r\n_Pár od okeního stolu se vmáčkne na volnou lavici v rohu, kde již sedí jiná dvojice, pravděpodobně kolegů z práce._\r\n\r\nTýpek v roztrhaných džínách: „Co víš o té …“  \r\nRoztomilá brunetka: „… celohře?“  \r\nProgramátor od pohledu: „Chcete ji hrát?“  \r\nBlonďák s chapadlem na triku: „Chtěli bychom o ní něco zjistit.“  \r\nRoztomilá brunetka: „Jak si můžem vybrat frakci?“  \r\nProgramátor od pohledu: „Pravidla můžete najít na oficiální vývěsce.“  \r\nTýpek v roztrhaných džínách: „No, tu jsme četli, nevíš o tom něco víc?“  \r\nKlučina v brýlích: „Prý by se už mělo jít zapojit.“  \r\nProgramátor od pohledu: „To jsou jen ničím nepodložené drby.“  \r\nKlučina v brýlích: „Když se zapíšete do knihy tváří a zveřejníte svůj portrét, můžete se do hry dostat již teď.“  \r\nProgramátor od pohledu: „Neposlouchejte ho, snaží se vás jen oblbnout.“  \r\nKlučina v brýlích: „Hej, je to tak jak to říkám, musí samozřejmě ještě zanechat zprávu na tajném místě…“  \r\nProgramátor od pohledu: „Jo a obětovat kozla, to víš že jo…“  \r\n\r\n---\r\n\r\n_Drby říkají, že do Celohry je již možné se zapojit, „zarezervovat“ si místo ve frakci a získat drobnou herní výhodu do začátku hry. Do 7.7.2021 lze zanechat zprávu v tajné schránce [foo@example.com](mailto:foo@example.com?subject=Foto%20pro%20Celohru&body=Jm%C3%A9no%20a%20p%C5%99%C3%ADjmen%C3%AD%3A%0AVariabiln%C3%AD%20symbol%3A%0AZam%C3%BD%C5%A1len%C3%A1%20frakce%3A%0A%0AFotografie%20v%20kost%C3%BDmu%20p%C5%99ilo%C5%BEena%20v%20p%C5%99%C3%ADloze.). Zpráva musí obsahovat jméno, příjmení, variabilní symbol účastníka gameconu a jeho fotografii v kostýmu, ze které bude zřejmé, ke které herní frakci (kultisté nebo vyšetřovatelé) se chce připojit. Zasláním fotografie souhlasíte s jejím zveřejněním na sociálních sítích. Pro účast na Celohře není potřeba ublížit žádnému kozlovi. Případné dotazy vyřizuje výše zmíněná tajná schránka._\r\n\r\n<!-- Matomo Image Tracker-->\r\n<img src=\"https://pw.gamecon.cz/matomo.php?idsite=1&rec=1&action_name=CelohraInformace\" style=\"border:0\" alt=\"\" />\r\n<img src=\"https://segmentation-fault.cz/hit?action_name=CelohraInformace\" style=\"border:0\" alt=\"\" />\r\n<!-- End Matomo -->\r\n\r\n[Přisednout si jinam…](/celohra/hospoda)\r\n', 2),
(163, 'celohra/hospoda/kulaty-stul', '# Hospoda\r\n\r\n## Kulatý stůl vzadu:\r\n\r\n_U stolu vzadu sedí tři muži. Soudě dle jejich vzhledu a hantýrky zřejmě policisté mimo službu, kteří sem zašli na skleničku po práci. Jeden z nich má výrazný orlí nos, druhý zas dobře pěstěný mroží knír. Třetí z nich je takový, no vlastně nijaký. Nedá se na něm najít absolutně nic zajímavého. Možná právě to je na něm zajímavé._\r\n\r\nMuž s orlím nosem: „…tak jsem jí donesl zase zpátky ty složky. Ty samý, který jí předtím strašlivě překáželi na stole.“  \r\nNenápadný muž: „A to jí to fakt nedojde?!“  \r\nMuž s orlím nosem: „No, já nevim, asi ne, no.“  \r\nNenápadný muž: „Všude je něco.“  \r\nMuž s knírem: „Podařilo se ti zjistit něco víc o tom případu?“  \r\nMuž s orlím nosem: „Ne moc. A rozhodně ne díky ní. Ale došel mi [dopis](soubory/obsah/celohra/dopis.pdf) z Plzně. To co se v něm píše mě však nepotěšilo.“  \r\nNenápadný muž: „Je jich víc? Ví o sobě?“  \r\nMuž s knírem: „Nemůže to být jen jeden pachatel?“  \r\nMuž s orlím nosem: „Zkusím zjistit, kam chodili před…“\r\n\r\n[Přisednout si jinam…](/celohra/hospoda)', 3),
(164, 'celohra/hospoda/salonek', '# Hospoda\r\n\r\n## Salonek\r\n\r\n_Stranou od ostatních se z malého salonku ozývá opatrný rozhovor několika mužů. Starší muž, pravděpodobně kolem padesátky, s nezapáleným doutníkem v jednom koutku, se baví s jiným podobně starým, ale plešatým mužem. Občas jim přitakává třetí, podsaditější, pod kterým židle až nebezpečně vrže._\r\n\r\nMuž s doutníkem: „…a pak jsem pořídil svíčky a myrthu.“  \r\nPlešatý muž: „Máme už vyrobenou pečeť?“  \r\nMuž s doutníkem: „Tadeáš se o ni postará, čeká jen na úplněk.“  \r\nTlustý pán: „Takže se uvidíme až v sobotu.“  \r\nMuž s doutníkem: „Nikoliv. Tadeáš mi poslal [zprávu](/soubory/obsah/celohra/zprava.pdf), že si přeje provést čtvrteční rituál.“  \r\nTlustý pán: „Ale naše místo bylo odhaleno. Nemůžeme riskovat, že rituál bude přerušen…“\r\n\r\n[Přisednout si jinam…](/celohra/hospoda)', 4),
(165, 'o-aktivite-bez-typu', 'Každá aktivita by měla mít typ - to že má tento je špatně. Toto je pseudo typ existující jen proto, aby se systém nehroutil. Pokud nevíš tak zřejmě hledáš typ \"technická\"', 0),
(166, 'wargaming/malovaci-vyzva', '# Předveď své malířské umění\r\n \r\nMáme vitrínu! A máme do ní osvětlení! Jediné, co jí chybí k dokonalosti, jsou výtvory návštěvníků GameConu, které v ní vystavíme!\r\n \r\nUž v minulých letech jste si na GameConu mohli zasoutěžit s figurkami, které jste si namalovali na našich workshopech, letos to ale posouváme dál. Namalujte figurky doma (nebo vezměte ty, co jste si v minulých letech namalovali na workshopech), přivezte je s sebou na GameCon a pochlubte se s nimi v jedné ze dvou našich soutěží!\r\n \r\nSoutěž č. 1\r\n--------------\r\nNezáleží na tom, jestli to bude sci-fi robot, elegantní steampunkový gentleman nebo barbarský válečník, pokud bude model alespoň částečně splňovat zařazení do sci-fi/fantasy, je vše v naprostém pořádku.\r\n \r\nKomisi budou tvořit samotní návštěvníci a vítězové se můžou těšit na ceny v podobě deskovek.  \r\n \r\nSoutěž č. 2\r\n--------------\r\nChcete ještě o něco větší výzvu? Není problém!\r\n \r\nPřineste svůj model, který bude nějakým způsobem připomínat GameCon, ať už použitými barvami, motivem oblíbené sekce nebo něčím úplně jiným.\r\n \r\nInspirovat se můžete vizuální identitou GameConu (juk na obrázky níže), využít naše typické barvy (červená a bílá, případně šedá a černá), ale kreativitě se rozhodně meze nekladou, je to jen a jen na vás! Pro inspiraci se můžete podívat, do čeho se už v rámci výzvy pustili sami vypravěči.\r\n \r\nPorotou budou samotní účastníci GameConu a i v tomto případě si vítězové odnesou ceny v podobě deskovek.\r\n\r\nZúčastnit se můžete obou soutěží, ale přihlásit můžete celkem maximálně tři modely na celkovou plochu 10 × 10 cm.\r\n \r\n*Tak popadněte štětce a vzhůru na figurky!*\r\n\r\nGrafická inspirace\r\n--------------\r\n\r\n![](soubory/obsah/wargaming/wargaming-graficka-inspirace.png)', 1);

-- --------------------------------------------------------

--
-- Struktura tabulky `systemove_nastaveni`
--

CREATE TABLE `systemove_nastaveni` (
  `id_nastaveni` bigint(20) UNSIGNED NOT NULL,
  `klic` varchar(128) NOT NULL,
  `hodnota` varchar(255) NOT NULL DEFAULT '',
  `vlastni` tinyint(1) DEFAULT 0,
  `datovy_typ` varchar(24) NOT NULL DEFAULT 'string',
  `nazev` varchar(255) NOT NULL,
  `popis` varchar(1028) NOT NULL DEFAULT '',
  `zmena_kdy` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `skupina` varchar(128) DEFAULT NULL,
  `poradi` int(10) UNSIGNED DEFAULT NULL,
  `pouze_pro_cteni` tinyint(1) DEFAULT 0,
  `rocnik_nastaveni` int(11) NOT NULL DEFAULT -1
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Vypisuji data pro tabulku `systemove_nastaveni`
--

INSERT INTO `systemove_nastaveni` (`id_nastaveni`, `klic`, `hodnota`, `vlastni`, `datovy_typ`, `nazev`, `popis`, `zmena_kdy`, `skupina`, `poradi`, `pouze_pro_cteni`, `rocnik_nastaveni`) VALUES
(18, 'AKTIVITA_EDITOVATELNA_X_MINUT_PRED_JEJIM_ZACATKEM', '20', 1, 'int', 'Kolik minut před začátkem lze už aktivitu editovat', 'Kolik minut před začátkem aktivity už může vypravěč editovat přihlášené', '2023-05-11 18:28:12', 'Aktivita', NULL, 0, -1),
(21, 'AUTOMATICKY_UZAMKNOUT_AKTIVITU_X_MINUT_PO_ZACATKU', '45', 1, 'int', 'Po kolika minutách se aktivita sama zamkne', 'Po jaké době běžící aktivitu uzamkne automat, pokud to někdo neudělá ručně - může to být se zpožděním, automat se pouští jen jednou za hodinu', '2023-05-11 18:28:12', 'Aktivita', NULL, 0, -1),
(4, 'BONUS_ZA_STANDARDNI_3H_AZ_5H_AKTIVITU', '280', 1, 'integer', 'Bonus za vedení 3-5h aktivity', 'Kolik dostane vypravěč standardní aktivity, která trvala tři až pět hodin', '2023-05-11 18:28:12', 'Finance', 4, 0, -1),
(34, 'DRUHA_VLNA_KDY', '2023-06-22 13:50:17', 1, 'datetime', 'Začátek druhé vlny aktivit', 'Kdy se podruhé hromadně změní aktivity Připravené k aktivaci na Aktivované', '2023-06-22 11:50:17', 'Časy', 21, 0, -1),
(10, 'GC_BEZI_DO', '2022-07-01 00:00:00', 0, 'datetime', 'Konec Gameconu', 'Datum a čas, kdy končí Gamecon', '2023-06-21 17:31:30', 'Časy', 6, 0, -1),
(9, 'GC_BEZI_OD', '2023-06-21 19:33:05', 0, 'datetime', 'Začátek Gameconu', 'Datum a čas, kdy začíná Gamecon', '2023-06-21 17:34:08', 'Časy', 5, 0, -1),
(45, 'HROMADNE_ODHLASOVANI_1', '', 0, 'datetime', 'První hromadné odhlašování', 'Kdy budou poprvé hromadně odhlášeni neplatiči', '2023-06-13 09:03:56', 'Časy', 23, 0, -1),
(46, 'HROMADNE_ODHLASOVANI_2', '', 0, 'datetime', 'Druhé hromadné odhlašování', 'Kdy budou podruhé hromadně odhlášeni neplatiči', '2023-06-13 09:03:56', 'Časy', 24, 0, -1),
(47, 'HROMADNE_ODHLASOVANI_3', '', 0, 'datetime', 'Třetí hromadné odhlašování', 'Kdy budou potřetí hromadně odhlášeni neplatiči', '2023-06-13 09:03:56', 'Časy', 25, 0, -1),
(26, 'JIDLO_LZE_OBJEDNAT_A_MENIT_DO_DNE', '2023-07-16', 0, 'date', 'Ukončení prodeje jídla na konci dne', 'Datum, do kdy ještě (včetně) lze v přihlášce měnit jídlo, než se zamkne', '2023-05-11 18:28:23', 'Časy', 14, 0, -1),
(48, 'KOLIK_MINUT_JE_ODHLASENI_AKTIVITY_BEZ_POKUTY', '5', 1, 'integer', 'Kolik minut je odhlášení aktivity bez pokuty', 'Když se účastník přihlásí na aktivitu a do několika minut se zase odhlásí, tak mu nebudeme počítat storno ani pár hodin před jejím začátkem', '2023-06-05 14:44:08', 'Aktivita', 26, 0, -1),
(1, 'KURZ_EURO', '22.4', 1, 'number', 'Kurz Eura', 'Kolik kč je pro nás letos jedno €', '2023-05-11 18:28:12', 'Finance', 1, 0, -1),
(16, 'NEPLATIC_CASTKA_POSLAL_DOST', '1000', 1, 'number', 'Už dost velká částka proti odhlášení', 'Kolik kč musí letos účastník poslat, abychom ho nezařadili do neplatičů', '2023-05-11 18:28:12', 'Neplatič', NULL, 0, -1),
(15, 'NEPLATIC_CASTKA_VELKY_DLUH', '200', 1, 'number', 'Ještě příliš velký dluh neplatiče', 'Kolik kč je pro nás stále tak velký dluh, že mu hrozí odhlášení jako neplatiči', '2023-05-11 18:28:12', 'Neplatič', NULL, 0, -1),
(17, 'NEPLATIC_POCET_DNU_PRED_VLNOU_KDY_JE_CHRANEN', '7', 1, 'integer', 'Počet dní od registrace před hromadným odhlašováním kdy je chráněn', 'Kolik nejvýše dní od registrace do odhlašovací vlny neplatičů je nový účastník ještě chráněn, aby nebyl brán jako neplatič', '2023-05-11 18:28:12', 'Neplatič', NULL, 0, -1),
(44, 'POSILAT_MAIL_O_ODHLASENI_A_UVOLNENEM_UBYTOVANI', '0', 1, 'boolean', 'Poslat nám e-mail o uvolněném ubytování', 'Když se účastník odhlásí z GC a měl objednané ubytování, tak nám o tom přijde email na info@gamecon.cz', '2023-05-13 08:38:43', 'Notifikace', 23, 0, -1),
(27, 'PREDMETY_BEZ_TRICEK_LZE_OBJEDNAT_A_MENIT_DO_DNE', '2023-07-09', 0, 'date', 'Ukončení prodeje předmětů (vyjma oblečení) na konci dne', 'Datum, do kdy ještě (včetně) lze v přihlášce měnit předměty, než se zamknou', '2023-05-11 18:28:23', 'Časy', 15, 0, -1),
(20, 'PRIHLASENI_NA_POSLEDNI_CHVILI_X_MINUT_PRED_ZACATKEM_AKTIVITY', '10', 1, 'int', 'Kolik minut před začátkem aktivity je \"na poslední chvíli\"', 'Nejvíce před kolika minutami před začátkem aktivity se účastník přihlásí, aby Moje aktivity ukázaly varování, že je nejspíš na cestě a ať na něj počkají', '2023-05-11 18:28:12', 'Aktivita', NULL, 0, -1),
(36, 'PRUMERNE_LONSKE_VSTUPNE', '113.993650793', 1, 'number', 'Průměrné loňské vstupné', 'Abychom mohli zobrazit kostku na posuvníku dobrovolného vstupného', '2023-05-11 18:28:13', 'Finance', 22, 1, 2016),
(37, 'PRUMERNE_LONSKE_VSTUPNE', '122.379518072', 1, 'number', 'Průměrné loňské vstupné', 'Abychom mohli zobrazit kostku na posuvníku dobrovolného vstupného', '2023-05-11 18:28:13', 'Finance', 22, 1, 2017),
(38, 'PRUMERNE_LONSKE_VSTUPNE', '126.543026706', 1, 'number', 'Průměrné loňské vstupné', 'Abychom mohli zobrazit kostku na posuvníku dobrovolného vstupného', '2023-05-11 18:28:13', 'Finance', 22, 1, 2018),
(39, 'PRUMERNE_LONSKE_VSTUPNE', '114.132394366', 1, 'number', 'Průměrné loňské vstupné', 'Abychom mohli zobrazit kostku na posuvníku dobrovolného vstupného', '2023-05-11 18:28:13', 'Finance', 22, 1, 2019),
(40, 'PRUMERNE_LONSKE_VSTUPNE', '81.578828828', 1, 'number', 'Průměrné loňské vstupné', 'Abychom mohli zobrazit kostku na posuvníku dobrovolného vstupného', '2023-05-11 18:28:14', 'Finance', 22, 1, 2020),
(41, 'PRUMERNE_LONSKE_VSTUPNE', '0.0', 1, 'number', 'Průměrné loňské vstupné', 'Abychom mohli zobrazit kostku na posuvníku dobrovolného vstupného', '2023-05-11 18:28:14', 'Finance', 22, 1, 2021),
(42, 'PRUMERNE_LONSKE_VSTUPNE', '122.881132075', 1, 'number', 'Průměrné loňské vstupné', 'Abychom mohli zobrazit kostku na posuvníku dobrovolného vstupného', '2023-05-11 18:28:14', 'Finance', 22, 1, 2022),
(43, 'PRUMERNE_LONSKE_VSTUPNE', '164.42', 1, 'number', 'Průměrné loňské vstupné', 'Abychom mohli zobrazit kostku na posuvníku dobrovolného vstupného<hr><i>výchozí hodnota</i>: <i>&gt;&gt;&gt;není&lt;&lt;&lt;</i>', '2023-05-11 18:28:14', 'Finance', 22, 1, 2023),
(12, 'PRVNI_VLNA_KDY', '2023-05-18 20:23:00', 0, 'datetime', 'Začátek první vlny aktivit', 'Kdy se poprvé hromadně změní aktivity Připravené k aktivaci na Aktivované', '2023-06-22 11:50:10', 'Časy', 20, 0, -1),
(29, 'REG_GC_DO', '2023-06-21 19:31:40', 1, 'datetime', 'Ukončení registrací přes web', 'Do kdy se lze registrovat na Gamecon přes přihlášlu na webu', '2023-06-21 17:34:23', 'Časy', 17, 0, -1),
(11, 'REG_GC_OD', '2023-05-11 20:43:00', 1, 'datetime', 'Začátek registrací účastníků', 'Od kdy se mohou začít účastníci registrovat na Gamecon', '2023-05-11 18:33:54', 'Časy', 7, 0, -1),
(32, 'ROCNIK', '2023', 1, 'integer', 'Ročník', 'Který ročník GC je aktivní', '2023-05-11 18:28:12', 'Časy', 19, 1, -1),
(24, 'TEXT_PRO_SPAROVANI_ODCHOZI_PLATBY', 'vraceni zustatku GC ID:', 0, 'text', 'Text pro rozpoznání odchozí GC platby', 'Přesné znění \"Zpráva pro příjemce\", za kterém následuje ID účastníka GC, kterému odesíláme z banky peníze, abychom podle něj spárovali odchozí platbu (stačí nalými písmeny a bez diakritiky)', '2023-05-11 18:28:23', 'Finance', 12, 0, -1),
(35, 'TRETI_VLNA_KDY', '2023-06-22 14:05:06', 1, 'datetime', 'Začátek třetí vlny aktivit', 'Kdy se potřetí hromadně změní aktivity Připravené k aktivaci na Aktivované', '2023-06-22 12:05:06', 'Časy', 22, 0, -1),
(28, 'TRICKA_LZE_OBJEDNAT_A_MENIT_DO_DNE', '2023-06-23', 0, 'date', 'Ukončení prodeje potištěných triček a tílek na konci dne', 'Datum, do kdy ještě (včetně) lze v přihlášce měnit trička a tílka, než se zamknou', '2023-06-21 17:31:23', 'Časy', 16, 0, -1),
(25, 'UBYTOVANI_LZE_OBJEDNAT_A_MENIT_DO_DNE', '2023-05-10', 0, 'date', 'Ukončení prodeje bytování na konci dne', 'Datum, do kdy ještě (včetně) lze v přihlášce měnit ubytování, než se zamkne', '2023-05-12 18:23:25', 'Časy', 13, 0, -1),
(31, 'UCASTNIKY_LZE_PRIDAVAT_X_DNI_PO_GC_U_NEUZAVRENE_PREZENCE', '30', 1, 'integer', 'Do kolika dní po GC lze přidat účastníka', 'Kolik dní po konci GC lze ještě přidávat účastníky na Neuzavřenou aktivitu', '2023-05-11 18:28:12', 'Časy', 18, 0, -1),
(19, 'UCASTNIKY_LZE_PRIDAVAT_X_MINUT_PO_KONCI_AKTIVITY', '60', 1, 'int', 'Kolik minut po konci aktivity lze potvrzovat účastníky', 'Kolik minut může ještě vypravěč zpětně přidávat účastníky a potvrzovat jejich účast od okamžiku jejího skončení. Neplatí pro odebírání účastníků.', '2023-05-11 18:28:12', 'Aktivita', NULL, 0, -1),
(22, 'UPOZORNIT_NA_NEUZAMKNUTOU_AKTIVITU_X_MINUT_PO_KONCI', '60', 1, 'int', 'Kdy vypravěče upozorníme že nezavřel', 'Po jaké době od konce aktivity odešleme vypravěčům mail, že aktivitu neuzavřeli - může to být se zpožděním, automat se pouští jen jednou za hodinu', '2023-05-11 18:28:12', 'Aktivita', NULL, 0, -1);

-- --------------------------------------------------------

--
-- Struktura tabulky `systemove_nastaveni_log`
--

CREATE TABLE `systemove_nastaveni_log` (
  `id_nastaveni_log` bigint(20) UNSIGNED NOT NULL,
  `id_uzivatele` int(11) DEFAULT NULL,
  `id_nastaveni` bigint(20) UNSIGNED NOT NULL,
  `hodnota` varchar(256) DEFAULT NULL,
  `vlastni` tinyint(1) DEFAULT NULL,
  `kdy` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Struktura tabulky `texty`
--

CREATE TABLE `texty` (
  `id` int(11) NOT NULL COMMENT 'hash',
  `text` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_czech_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `ubytovani`
--

CREATE TABLE `ubytovani` (
  `id_uzivatele` int(11) NOT NULL,
  `den` tinyint(4) NOT NULL,
  `pokoj` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `rok` smallint(6) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `uzivatele_hodnoty`
--

CREATE TABLE `uzivatele_hodnoty` (
  `id_uzivatele` int(11) NOT NULL,
  `login_uzivatele` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `jmeno_uzivatele` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `prijmeni_uzivatele` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `ulice_a_cp_uzivatele` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `mesto_uzivatele` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `stat_uzivatele` int(11) NOT NULL,
  `psc_uzivatele` varchar(20) COLLATE utf8_czech_ci NOT NULL,
  `telefon_uzivatele` varchar(100) COLLATE utf8_czech_ci NOT NULL,
  `datum_narozeni` date NOT NULL,
  `heslo_md5` varchar(255) CHARACTER SET ucs2 COLLATE ucs2_czech_ci NOT NULL COMMENT 'přechází se na password_hash',
  `funkce_uzivatele` tinyint(4) NOT NULL,
  `email1_uzivatele` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `email2_uzivatele` varchar(255) COLLATE utf8_czech_ci NOT NULL,
  `jine_uzivatele` text COLLATE utf8_czech_ci NOT NULL,
  `nechce_maily` datetime DEFAULT NULL COMMENT 'kdy se odhlásil z odebírání mail(er)u',
  `mrtvy_mail` tinyint(4) NOT NULL,
  `forum_razeni` varchar(1) COLLATE utf8_czech_ci NOT NULL,
  `random` varchar(20) COLLATE utf8_czech_ci NOT NULL,
  `zustatek` int(11) NOT NULL COMMENT 'zbytek z minulého roku',
  `pohlavi` enum('m','f') COLLATE utf8_czech_ci NOT NULL,
  `registrovan` datetime NOT NULL,
  `ubytovan_s` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL,
  `skola` varchar(255) COLLATE utf8_czech_ci DEFAULT NULL,
  `poznamka` varchar(4096) COLLATE utf8_czech_ci NOT NULL,
  `pomoc_typ` varchar(64) COLLATE utf8_czech_ci NOT NULL,
  `pomoc_vice` text COLLATE utf8_czech_ci NOT NULL,
  `op` varchar(4096) COLLATE utf8_czech_ci NOT NULL COMMENT 'zašifrované číslo OP',
  `potvrzeni_zakonneho_zastupce` date DEFAULT NULL,
  `potvrzeni_proti_covid19_pridano_kdy` datetime DEFAULT NULL,
  `potvrzeni_proti_covid19_overeno_kdy` datetime DEFAULT NULL,
  `infopult_poznamka` varchar(128) COLLATE utf8_czech_ci NOT NULL DEFAULT '',
  `typ_dokladu_totoznosti` varchar(16) COLLATE utf8_czech_ci NOT NULL DEFAULT '',
  `statni_obcanstvi` varchar(64) COLLATE utf8_czech_ci DEFAULT NULL,
  `z_rychloregistrace` tinyint(1) DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `uzivatele_hodnoty`
--

INSERT INTO `uzivatele_hodnoty` (`id_uzivatele`, `login_uzivatele`, `jmeno_uzivatele`, `prijmeni_uzivatele`, `ulice_a_cp_uzivatele`, `mesto_uzivatele`, `stat_uzivatele`, `psc_uzivatele`, `telefon_uzivatele`, `datum_narozeni`, `heslo_md5`, `funkce_uzivatele`, `email1_uzivatele`, `email2_uzivatele`, `jine_uzivatele`, `nechce_maily`, `mrtvy_mail`, `forum_razeni`, `random`, `zustatek`, `pohlavi`, `registrovan`, `ubytovan_s`, `skola`, `poznamka`, `pomoc_typ`, `pomoc_vice`, `op`, `potvrzeni_zakonneho_zastupce`, `potvrzeni_proti_covid19_pridano_kdy`, `potvrzeni_proti_covid19_overeno_kdy`, `infopult_poznamka`, `typ_dokladu_totoznosti`, `statni_obcanstvi`, `z_rychloregistrace`) VALUES
(1, 'SYSTEM', 'SYSTEM', 'SYSTEM', 'SYSTEM', 'SYSTEM', 1, 'SYSTEM', 'SYSTEM', '2023-01-27', '', 0, 'system@gamecon.cz', 'system@gamecon.cz', '', '2023-01-27 00:00:00', 1, '', '2e3012801cdebf6db162', 0, 'm', '2023-01-27 00:00:00', NULL, NULL, '', '', '', '', NULL, NULL, NULL, '', '', 'ČR', 0),
(10000, 'localAdmin', 'local', 'Admin', '', '', 1, '', '', '0001-00-00', '$2y$10$KYv2m7yoT2OBDUYmH3oK4uaeM6wgQECy6/uiSYvJt9yIfAWQRfwi6', 0, 'localAdmin.gamecon.cz', '', '', '2019-05-08 00:00:00', 0, '', '8666b8a380d284add268', 0, 'm', '2019-05-08 00:00:00', NULL, NULL, '', '', '', '', NULL, NULL, NULL, '', '', NULL, 0);

-- --------------------------------------------------------

--
-- Struktura tabulky `uzivatele_role`
--

CREATE TABLE `uzivatele_role` (
  `id_uzivatele` int(11) NOT NULL,
  `id_role` int(11) NOT NULL,
  `posazen` timestamp NULL DEFAULT NULL,
  `posadil` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

--
-- Vypisuji data pro tabulku `uzivatele_role`
--

INSERT INTO `uzivatele_role` (`id_uzivatele`, `id_role`, `posazen`, `posadil`) VALUES
(10000, 2, '2019-05-08 13:57:22', NULL),
(10000, 20, '2019-05-08 13:57:22', NULL);

-- --------------------------------------------------------

--
-- Struktura tabulky `uzivatele_role_log`
--

CREATE TABLE `uzivatele_role_log` (
  `id_uzivatele` int(11) NOT NULL,
  `id_role` int(11) NOT NULL,
  `id_zmenil` int(11) DEFAULT NULL,
  `zmena` varchar(128) COLLATE utf8_czech_ci NOT NULL,
  `kdy` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `uzivatele_url`
--

CREATE TABLE `uzivatele_url` (
  `id_url_uzivatele` bigint(20) UNSIGNED NOT NULL,
  `id_uzivatele` int(11) NOT NULL,
  `url` varchar(255) COLLATE utf8_czech_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura tabulky `_vars`
--

CREATE TABLE `_vars` (
  `name` varchar(64) COLLATE utf8_czech_ci NOT NULL,
  `value` varchar(4096) COLLATE utf8_czech_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_czech_ci;

-- --------------------------------------------------------

--
-- Struktura pro pohled `platne_role`
--
DROP TABLE IF EXISTS `platne_role`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`%` SQL SECURITY DEFINER VIEW `platne_role`  AS SELECT `role_seznam`.`id_role` AS `id_role`, `role_seznam`.`kod_role` AS `kod_role`, `role_seznam`.`nazev_role` AS `nazev_role`, `role_seznam`.`popis_role` AS `popis_role`, `role_seznam`.`rocnik_role` AS `rocnik_role`, `role_seznam`.`typ_role` AS `typ_role`, `role_seznam`.`vyznam_role` AS `vyznam_role`, `role_seznam`.`skryta` AS `skryta`, `role_seznam`.`kategorie_role` AS `kategorie_role` FROM `role_seznam` WHERE `role_seznam`.`rocnik_role` in ((select `systemove_nastaveni`.`hodnota` from `systemove_nastaveni` where `systemove_nastaveni`.`klic` = 'ROCNIK' limit 1),-1) OR `role_seznam`.`typ_role` = 'ucast''ucast'  ;

-- --------------------------------------------------------

--
-- Struktura pro pohled `platne_role_uzivatelu`
--
DROP TABLE IF EXISTS `platne_role_uzivatelu`;

CREATE ALGORITHM=UNDEFINED DEFINER=`root`@`%` SQL SECURITY DEFINER VIEW `platne_role_uzivatelu`  AS SELECT `uzivatele_role`.`id_uzivatele` AS `id_uzivatele`, `uzivatele_role`.`id_role` AS `id_role`, `uzivatele_role`.`posazen` AS `posazen`, `uzivatele_role`.`posadil` AS `posadil` FROM (`uzivatele_role` join `platne_role` on(`uzivatele_role`.`id_role` = `platne_role`.`id_role`))  ;

--
-- Indexy pro exportované tabulky
--

--
-- Indexy pro tabulku `akce_import`
--
ALTER TABLE `akce_import`
  ADD UNIQUE KEY `id_akce_import` (`id_akce_import`),
  ADD KEY `google_sheet_id` (`google_sheet_id`),
  ADD KEY `FK_akce_import_to_uzivatele_hodnoty` (`id_uzivatele`);

--
-- Indexy pro tabulku `akce_instance`
--
ALTER TABLE `akce_instance`
  ADD PRIMARY KEY (`id_instance`),
  ADD KEY `FK_akce_instance_to_akce_seznam` (`id_hlavni_akce`);

--
-- Indexy pro tabulku `akce_lokace`
--
ALTER TABLE `akce_lokace`
  ADD PRIMARY KEY (`id_lokace`),
  ADD UNIQUE KEY `nazev_rok` (`nazev`,`rok`);

--
-- Indexy pro tabulku `akce_organizatori`
--
ALTER TABLE `akce_organizatori`
  ADD PRIMARY KEY (`id_akce`,`id_uzivatele`),
  ADD KEY `id_uzivatele` (`id_uzivatele`);

--
-- Indexy pro tabulku `akce_prihlaseni`
--
ALTER TABLE `akce_prihlaseni`
  ADD PRIMARY KEY (`id_akce`,`id_uzivatele`),
  ADD KEY `id_uzivatele` (`id_uzivatele`),
  ADD KEY `id_stavu_prihlaseni` (`id_stavu_prihlaseni`);

--
-- Indexy pro tabulku `akce_prihlaseni_log`
--
ALTER TABLE `akce_prihlaseni_log`
  ADD PRIMARY KEY (`id_log`),
  ADD KEY `typ` (`typ`),
  ADD KEY `id_zmenil` (`id_zmenil`),
  ADD KEY `FK_akce_prihlaseni_log_to_akce_seznam` (`id_akce`),
  ADD KEY `FK_akce_prihlaseni_log_to_uzivatele_hodnoty` (`id_uzivatele`),
  ADD KEY `zdroj_zmeny` (`zdroj_zmeny`);

--
-- Indexy pro tabulku `akce_prihlaseni_spec`
--
ALTER TABLE `akce_prihlaseni_spec`
  ADD PRIMARY KEY (`id_akce`,`id_uzivatele`),
  ADD KEY `id_uzivatele` (`id_uzivatele`),
  ADD KEY `id_stavu_prihlaseni` (`id_stavu_prihlaseni`);

--
-- Indexy pro tabulku `akce_prihlaseni_stavy`
--
ALTER TABLE `akce_prihlaseni_stavy`
  ADD PRIMARY KEY (`id_stavu_prihlaseni`);

--
-- Indexy pro tabulku `akce_seznam`
--
ALTER TABLE `akce_seznam`
  ADD PRIMARY KEY (`id_akce`),
  ADD UNIQUE KEY `url_akce_rok_typ` (`url_akce`,`rok`,`typ`),
  ADD KEY `rok` (`rok`),
  ADD KEY `patri_pod` (`patri_pod`),
  ADD KEY `lokace` (`lokace`),
  ADD KEY `typ` (`typ`),
  ADD KEY `stav` (`stav`),
  ADD KEY `popis` (`popis`);

--
-- Indexy pro tabulku `akce_sjednocene_tagy`
--
ALTER TABLE `akce_sjednocene_tagy`
  ADD PRIMARY KEY (`id_akce`,`id_tagu`),
  ADD KEY `FK_akce_sjednocene_tagy_to_sjednocene_tagy` (`id_tagu`);

--
-- Indexy pro tabulku `akce_stav`
--
ALTER TABLE `akce_stav`
  ADD PRIMARY KEY (`nazev`),
  ADD UNIQUE KEY `id_stav` (`id_stav`);

--
-- Indexy pro tabulku `akce_stavy_log`
--
ALTER TABLE `akce_stavy_log`
  ADD UNIQUE KEY `akce_stavy_log_id` (`akce_stavy_log_id`),
  ADD KEY `FK_akce_stavy_log_to_akce_seznam` (`id_akce`),
  ADD KEY `FK_akce_stavy_log_to_akce_stav` (`id_stav`);

--
-- Indexy pro tabulku `akce_typy`
--
ALTER TABLE `akce_typy`
  ADD PRIMARY KEY (`id_typu`),
  ADD KEY `FK_akce_typy_to_stranka_o` (`stranka_o`);

--
-- Indexy pro tabulku `google_api_user_tokens`
--
ALTER TABLE `google_api_user_tokens`
  ADD PRIMARY KEY (`user_id`,`google_client_id`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexy pro tabulku `google_drive_dirs`
--
ALTER TABLE `google_drive_dirs`
  ADD PRIMARY KEY (`dir_id`),
  ADD UNIQUE KEY `id` (`id`),
  ADD UNIQUE KEY `user_and_name` (`user_id`,`original_name`),
  ADD KEY `tag` (`tag`);

--
-- Indexy pro tabulku `hromadne_akce_log`
--
ALTER TABLE `hromadne_akce_log`
  ADD UNIQUE KEY `id_logu` (`id_logu`),
  ADD KEY `akce` (`akce`),
  ADD KEY `FK_hromadne_akce_log_to_uzivatele_hodnoty` (`provedl`);

--
-- Indexy pro tabulku `kategorie_sjednocenych_tagu`
--
ALTER TABLE `kategorie_sjednocenych_tagu`
  ADD PRIMARY KEY (`nazev`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `FK_kategorie_sjednocenych_tagu_to_kategorie_sjednocenych_tagu` (`id_hlavni_kategorie`);

--
-- Indexy pro tabulku `log_udalosti`
--
ALTER TABLE `log_udalosti`
  ADD UNIQUE KEY `id_udalosti` (`id_udalosti`),
  ADD KEY `metadata` (`metadata`),
  ADD KEY `FK_log_udalosti_to_uzivatele_hodnoty` (`id_logujiciho`);

--
-- Indexy pro tabulku `medailonky`
--
ALTER TABLE `medailonky`
  ADD PRIMARY KEY (`id_uzivatele`);

--
-- Indexy pro tabulku `migrations`
--
ALTER TABLE `migrations`
  ADD PRIMARY KEY (`migration_code`),
  ADD UNIQUE KEY `migration_id` (`migration_id`);

--
-- Indexy pro tabulku `mutex`
--
ALTER TABLE `mutex`
  ADD PRIMARY KEY (`akce`),
  ADD UNIQUE KEY `id_mutex` (`id_mutex`),
  ADD UNIQUE KEY `klic` (`klic`),
  ADD KEY `FK_mutex_to_uzivatele_hodnoty` (`zamknul`);

--
-- Indexy pro tabulku `novinky`
--
ALTER TABLE `novinky`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url` (`url`),
  ADD KEY `FK_novinky_to_texty` (`text`);

--
-- Indexy pro tabulku `obchod_bunky`
--
ALTER TABLE `obchod_bunky`
  ADD PRIMARY KEY (`id`),
  ADD KEY `FK_obchod_bunky_to_obchod_mrizky` (`mrizka_id`);

--
-- Indexy pro tabulku `obchod_mrizky`
--
ALTER TABLE `obchod_mrizky`
  ADD PRIMARY KEY (`id`);

--
-- Indexy pro tabulku `platby`
--
ALTER TABLE `platby`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `fio_id` (`fio_id`),
  ADD KEY `id_uzivatele_rok` (`id_uzivatele`,`rok`);

--
-- Indexy pro tabulku `prava_role`
--
ALTER TABLE `prava_role`
  ADD PRIMARY KEY (`id_role`,`id_prava`),
  ADD KEY `id_prava` (`id_prava`);

--
-- Indexy pro tabulku `reporty`
--
ALTER TABLE `reporty`
  ADD PRIMARY KEY (`skript`),
  ADD UNIQUE KEY `id` (`id`);

--
-- Indexy pro tabulku `reporty_log_pouziti`
--
ALTER TABLE `reporty_log_pouziti`
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `report_uzivatel` (`id_reportu`,`id_uzivatele`),
  ADD KEY `id_uzivatele` (`id_uzivatele`);

--
-- Indexy pro tabulku `reporty_quick`
--
ALTER TABLE `reporty_quick`
  ADD PRIMARY KEY (`id`);

--
-- Indexy pro tabulku `role_seznam`
--
ALTER TABLE `role_seznam`
  ADD PRIMARY KEY (`id_role`),
  ADD UNIQUE KEY `nazev_role` (`nazev_role`),
  ADD UNIQUE KEY `kod_role` (`kod_role`),
  ADD KEY `typ_zidle` (`typ_role`),
  ADD KEY `vyznam` (`vyznam_role`);

--
-- Indexy pro tabulku `r_prava_soupis`
--
ALTER TABLE `r_prava_soupis`
  ADD PRIMARY KEY (`id_prava`);

--
-- Indexy pro tabulku `shop_nakupy`
--
ALTER TABLE `shop_nakupy`
  ADD UNIQUE KEY `id_nakupu` (`id_nakupu`),
  ADD KEY `rok_id_uzivatele` (`rok`,`id_uzivatele`),
  ADD KEY `id_predmetu` (`id_predmetu`),
  ADD KEY `id_uzivatele` (`id_uzivatele`),
  ADD KEY `id_objednatele` (`id_objednatele`);

--
-- Indexy pro tabulku `shop_nakupy_zrusene`
--
ALTER TABLE `shop_nakupy_zrusene`
  ADD KEY `FK_zrusene_objednavky_to_shop_predmety` (`id_predmetu`),
  ADD KEY `FK_zrusene_objednavky_to_uzivatele_hodnoty` (`id_uzivatele`),
  ADD KEY `datum_zruseni` (`datum_zruseni`),
  ADD KEY `zdroj_zruseni` (`zdroj_zruseni`);

--
-- Indexy pro tabulku `shop_predmety`
--
ALTER TABLE `shop_predmety`
  ADD PRIMARY KEY (`id_predmetu`),
  ADD UNIQUE KEY `UNIQ_nazev_model_rok` (`nazev`,`model_rok`),
  ADD KEY `kategorie_predmetu` (`kategorie_predmetu`);

--
-- Indexy pro tabulku `sjednocene_tagy`
--
ALTER TABLE `sjednocene_tagy`
  ADD PRIMARY KEY (`nazev`),
  ADD UNIQUE KEY `id` (`id`),
  ADD KEY `FK_sjednocene_tagy_to_kategorie_sjednocenych_tagu` (`id_kategorie_tagu`);

--
-- Indexy pro tabulku `slevy`
--
ALTER TABLE `slevy`
  ADD PRIMARY KEY (`id`),
  ADD KEY `id_uzivatele` (`id_uzivatele`),
  ADD KEY `provedl` (`provedl`);

--
-- Indexy pro tabulku `stranky`
--
ALTER TABLE `stranky`
  ADD PRIMARY KEY (`id_stranky`),
  ADD UNIQUE KEY `url_stranky` (`url_stranky`);

--
-- Indexy pro tabulku `systemove_nastaveni`
--
ALTER TABLE `systemove_nastaveni`
  ADD PRIMARY KEY (`klic`,`rocnik_nastaveni`),
  ADD UNIQUE KEY `id_nastaveni` (`id_nastaveni`),
  ADD UNIQUE KEY `nazev` (`nazev`,`rocnik_nastaveni`),
  ADD KEY `skupina` (`skupina`);

--
-- Indexy pro tabulku `systemove_nastaveni_log`
--
ALTER TABLE `systemove_nastaveni_log`
  ADD UNIQUE KEY `id_nastaveni_log` (`id_nastaveni_log`),
  ADD KEY `FK_systemove_nastaveni_log_to_systemove_nastaveni` (`id_nastaveni`),
  ADD KEY `FK_systemove_nastaveni_log_to_uzivatele_hodnoty` (`id_uzivatele`);

--
-- Indexy pro tabulku `texty`
--
ALTER TABLE `texty`
  ADD PRIMARY KEY (`id`);

--
-- Indexy pro tabulku `ubytovani`
--
ALTER TABLE `ubytovani`
  ADD PRIMARY KEY (`rok`,`id_uzivatele`,`den`),
  ADD KEY `id_uzivatele` (`id_uzivatele`);

--
-- Indexy pro tabulku `uzivatele_hodnoty`
--
ALTER TABLE `uzivatele_hodnoty`
  ADD PRIMARY KEY (`id_uzivatele`),
  ADD UNIQUE KEY `login_uzivatele` (`login_uzivatele`),
  ADD UNIQUE KEY `email1_uzivatele` (`email1_uzivatele`),
  ADD KEY `infopult_poznamka` (`infopult_poznamka`);

--
-- Indexy pro tabulku `uzivatele_role`
--
ALTER TABLE `uzivatele_role`
  ADD PRIMARY KEY (`id_uzivatele`,`id_role`),
  ADD KEY `posadil` (`posadil`),
  ADD KEY `FK_uzivatele_role_role_seznam` (`id_role`);

--
-- Indexy pro tabulku `uzivatele_role_log`
--
ALTER TABLE `uzivatele_role_log`
  ADD KEY `id_uzivatele` (`id_uzivatele`),
  ADD KEY `id_zidle` (`id_role`),
  ADD KEY `id_zmenil` (`id_zmenil`);

--
-- Indexy pro tabulku `uzivatele_url`
--
ALTER TABLE `uzivatele_url`
  ADD PRIMARY KEY (`url`),
  ADD UNIQUE KEY `id_url_uzivatele` (`id_url_uzivatele`),
  ADD KEY `id_uzivatele` (`id_uzivatele`);

--
-- Indexy pro tabulku `_vars`
--
ALTER TABLE `_vars`
  ADD PRIMARY KEY (`name`);

--
-- AUTO_INCREMENT pro tabulky
--

--
-- AUTO_INCREMENT pro tabulku `akce_import`
--
ALTER TABLE `akce_import`
  MODIFY `id_akce_import` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `akce_instance`
--
ALTER TABLE `akce_instance`
  MODIFY `id_instance` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `akce_lokace`
--
ALTER TABLE `akce_lokace`
  MODIFY `id_lokace` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=229;

--
-- AUTO_INCREMENT pro tabulku `akce_prihlaseni_log`
--
ALTER TABLE `akce_prihlaseni_log`
  MODIFY `id_log` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `akce_seznam`
--
ALTER TABLE `akce_seznam`
  MODIFY `id_akce` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `akce_stav`
--
ALTER TABLE `akce_stav`
  MODIFY `id_stav` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT pro tabulku `akce_stavy_log`
--
ALTER TABLE `akce_stavy_log`
  MODIFY `akce_stavy_log_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `google_api_user_tokens`
--
ALTER TABLE `google_api_user_tokens`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `google_drive_dirs`
--
ALTER TABLE `google_drive_dirs`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `hromadne_akce_log`
--
ALTER TABLE `hromadne_akce_log`
  MODIFY `id_logu` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `kategorie_sjednocenych_tagu`
--
ALTER TABLE `kategorie_sjednocenych_tagu`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=51;

--
-- AUTO_INCREMENT pro tabulku `log_udalosti`
--
ALTER TABLE `log_udalosti`
  MODIFY `id_udalosti` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `migrations`
--
ALTER TABLE `migrations`
  MODIFY `migration_id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=212;

--
-- AUTO_INCREMENT pro tabulku `mutex`
--
ALTER TABLE `mutex`
  MODIFY `id_mutex` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `novinky`
--
ALTER TABLE `novinky`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `obchod_bunky`
--
ALTER TABLE `obchod_bunky`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `obchod_mrizky`
--
ALTER TABLE `obchod_mrizky`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `platby`
--
ALTER TABLE `platby`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT COMMENT 'kvůli indexu a vícenásobným platbám';

--
-- AUTO_INCREMENT pro tabulku `reporty`
--
ALTER TABLE `reporty`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=56;

--
-- AUTO_INCREMENT pro tabulku `reporty_log_pouziti`
--
ALTER TABLE `reporty_log_pouziti`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `reporty_quick`
--
ALTER TABLE `reporty_quick`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `role_seznam`
--
ALTER TABLE `role_seznam`
  MODIFY `id_role` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;

--
-- AUTO_INCREMENT pro tabulku `r_prava_soupis`
--
ALTER TABLE `r_prava_soupis`
  MODIFY `id_prava` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1034;

--
-- AUTO_INCREMENT pro tabulku `shop_nakupy`
--
ALTER TABLE `shop_nakupy`
  MODIFY `id_nakupu` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `shop_predmety`
--
ALTER TABLE `shop_predmety`
  MODIFY `id_predmetu` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=919;

--
-- AUTO_INCREMENT pro tabulku `sjednocene_tagy`
--
ALTER TABLE `sjednocene_tagy`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12430;

--
-- AUTO_INCREMENT pro tabulku `slevy`
--
ALTER TABLE `slevy`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `stranky`
--
ALTER TABLE `stranky`
  MODIFY `id_stranky` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=167;

--
-- AUTO_INCREMENT pro tabulku `systemove_nastaveni`
--
ALTER TABLE `systemove_nastaveni`
  MODIFY `id_nastaveni` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT pro tabulku `systemove_nastaveni_log`
--
ALTER TABLE `systemove_nastaveni_log`
  MODIFY `id_nastaveni_log` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT pro tabulku `uzivatele_hodnoty`
--
ALTER TABLE `uzivatele_hodnoty`
  MODIFY `id_uzivatele` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10001;

--
-- AUTO_INCREMENT pro tabulku `uzivatele_url`
--
ALTER TABLE `uzivatele_url`
  MODIFY `id_url_uzivatele` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- Omezení pro exportované tabulky
--

--
-- Omezení pro tabulku `akce_import`
--
ALTER TABLE `akce_import`
  ADD CONSTRAINT `akce_import_ibfk_1` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE NO ACTION ON UPDATE CASCADE;

--
-- Omezení pro tabulku `akce_instance`
--
ALTER TABLE `akce_instance`
  ADD CONSTRAINT `akce_instance_ibfk_1` FOREIGN KEY (`id_hlavni_akce`) REFERENCES `akce_seznam` (`id_akce`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `akce_organizatori`
--
ALTER TABLE `akce_organizatori`
  ADD CONSTRAINT `FK_akce_organizatori_to_akce_seznam` FOREIGN KEY (`id_akce`) REFERENCES `akce_seznam` (`id_akce`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_akce_organizatori_to_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `akce_prihlaseni`
--
ALTER TABLE `akce_prihlaseni`
  ADD CONSTRAINT `FK_akce_prihlaseni_to_akce_prihlaseni_stavy` FOREIGN KEY (`id_stavu_prihlaseni`) REFERENCES `akce_prihlaseni_stavy` (`id_stavu_prihlaseni`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_akce_prihlaseni_to_akce_seznam` FOREIGN KEY (`id_akce`) REFERENCES `akce_seznam` (`id_akce`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_akce_prihlaseni_to_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON UPDATE CASCADE;

--
-- Omezení pro tabulku `akce_prihlaseni_log`
--
ALTER TABLE `akce_prihlaseni_log`
  ADD CONSTRAINT `FK_akce_prihlaseni_log_to_akce_seznam` FOREIGN KEY (`id_akce`) REFERENCES `akce_seznam` (`id_akce`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_akce_prihlaseni_log_to_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `akce_prihlaseni_spec`
--
ALTER TABLE `akce_prihlaseni_spec`
  ADD CONSTRAINT `FK_akce_prihlaseni_spec_to_akce_prihlaseni_stavy` FOREIGN KEY (`id_stavu_prihlaseni`) REFERENCES `akce_prihlaseni_stavy` (`id_stavu_prihlaseni`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_akce_prihlaseni_spec_to_akce_seznam` FOREIGN KEY (`id_akce`) REFERENCES `akce_seznam` (`id_akce`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_akce_prihlaseni_spec_to_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON UPDATE CASCADE;

--
-- Omezení pro tabulku `akce_seznam`
--
ALTER TABLE `akce_seznam`
  ADD CONSTRAINT `FK_akce_seznam_to_akce_instance` FOREIGN KEY (`patri_pod`) REFERENCES `akce_instance` (`id_instance`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_akce_seznam_to_akce_stav` FOREIGN KEY (`stav`) REFERENCES `akce_stav` (`id_stav`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_akce_seznam_to_popis` FOREIGN KEY (`popis`) REFERENCES `texty` (`id`) ON UPDATE CASCADE;

--
-- Omezení pro tabulku `akce_sjednocene_tagy`
--
ALTER TABLE `akce_sjednocene_tagy`
  ADD CONSTRAINT `FK_akce_sjednocene_tagy_to_sjednocene_tagy` FOREIGN KEY (`id_tagu`) REFERENCES `sjednocene_tagy` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `akce_stavy_log`
--
ALTER TABLE `akce_stavy_log`
  ADD CONSTRAINT `FK_akce_stavy_log_to_akce_seznam` FOREIGN KEY (`id_akce`) REFERENCES `akce_seznam` (`id_akce`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_akce_stavy_log_to_akce_stav` FOREIGN KEY (`id_stav`) REFERENCES `akce_stav` (`id_stav`) ON UPDATE CASCADE;

--
-- Omezení pro tabulku `akce_typy`
--
ALTER TABLE `akce_typy`
  ADD CONSTRAINT `FK_akce_typy_to_stranka_o` FOREIGN KEY (`stranka_o`) REFERENCES `stranky` (`id_stranky`) ON UPDATE CASCADE;

--
-- Omezení pro tabulku `google_api_user_tokens`
--
ALTER TABLE `google_api_user_tokens`
  ADD CONSTRAINT `FK_google_api_user_tokens_to_uzivatele_hodnoty` FOREIGN KEY (`user_id`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `google_drive_dirs`
--
ALTER TABLE `google_drive_dirs`
  ADD CONSTRAINT `FK_google_drive_dirs_to_uzivatele_hodnoty` FOREIGN KEY (`user_id`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `hromadne_akce_log`
--
ALTER TABLE `hromadne_akce_log`
  ADD CONSTRAINT `FK_hromadne_akce_log_to_uzivatele_hodnoty` FOREIGN KEY (`provedl`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Omezení pro tabulku `kategorie_sjednocenych_tagu`
--
ALTER TABLE `kategorie_sjednocenych_tagu`
  ADD CONSTRAINT `FK_kategorie_sjednocenych_tagu_to_kategorie_sjednocenych_tagu` FOREIGN KEY (`id_hlavni_kategorie`) REFERENCES `kategorie_sjednocenych_tagu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `log_udalosti`
--
ALTER TABLE `log_udalosti`
  ADD CONSTRAINT `FK_log_udalosti_to_uzivatele_hodnoty` FOREIGN KEY (`id_logujiciho`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `medailonky`
--
ALTER TABLE `medailonky`
  ADD CONSTRAINT `FK_medailonky_to_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `mutex`
--
ALTER TABLE `mutex`
  ADD CONSTRAINT `FK_mutex_to_uzivatele_hodnoty` FOREIGN KEY (`zamknul`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Omezení pro tabulku `novinky`
--
ALTER TABLE `novinky`
  ADD CONSTRAINT `FK_novinky_to_texty` FOREIGN KEY (`text`) REFERENCES `texty` (`id`) ON UPDATE CASCADE;

--
-- Omezení pro tabulku `obchod_bunky`
--
ALTER TABLE `obchod_bunky`
  ADD CONSTRAINT `FK_obchod_bunky_to_obchod_mrizky` FOREIGN KEY (`mrizka_id`) REFERENCES `obchod_mrizky` (`id`);

--
-- Omezení pro tabulku `platby`
--
ALTER TABLE `platby`
  ADD CONSTRAINT `FK_platby_to_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON UPDATE CASCADE;

--
-- Omezení pro tabulku `prava_role`
--
ALTER TABLE `prava_role`
  ADD CONSTRAINT `FK_prava_role_to_r_prava_soupis` FOREIGN KEY (`id_prava`) REFERENCES `r_prava_soupis` (`id_prava`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_prava_role_to_role_seznam` FOREIGN KEY (`id_role`) REFERENCES `role_seznam` (`id_role`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `reporty_log_pouziti`
--
ALTER TABLE `reporty_log_pouziti`
  ADD CONSTRAINT `FK_reporty_log_pouziti_to_reporty` FOREIGN KEY (`id_reportu`) REFERENCES `reporty` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_reporty_log_pouziti_to_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `shop_nakupy`
--
ALTER TABLE `shop_nakupy`
  ADD CONSTRAINT `FK_shop_nakupy_to_shop_predmety` FOREIGN KEY (`id_predmetu`) REFERENCES `shop_predmety` (`id_predmetu`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_shop_nakupy_to_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON UPDATE CASCADE,
  ADD CONSTRAINT `shop_nakupy_ibfk_1` FOREIGN KEY (`id_objednatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Omezení pro tabulku `shop_nakupy_zrusene`
--
ALTER TABLE `shop_nakupy_zrusene`
  ADD CONSTRAINT `FK_zrusene_objednavky_to_shop_predmety` FOREIGN KEY (`id_predmetu`) REFERENCES `shop_predmety` (`id_predmetu`) ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_zrusene_objednavky_to_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON UPDATE CASCADE;

--
-- Omezení pro tabulku `sjednocene_tagy`
--
ALTER TABLE `sjednocene_tagy`
  ADD CONSTRAINT `FK_sjednocene_tagy_to_kategorie_sjednocenych_tagu` FOREIGN KEY (`id_kategorie_tagu`) REFERENCES `kategorie_sjednocenych_tagu` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `slevy`
--
ALTER TABLE `slevy`
  ADD CONSTRAINT `FK_slevy_provedl_to_uzivatele_hodnoty` FOREIGN KEY (`provedl`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE SET NULL ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_slevy_to_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `systemove_nastaveni_log`
--
ALTER TABLE `systemove_nastaveni_log`
  ADD CONSTRAINT `FK_systemove_nastaveni_log_to_systemove_nastaveni` FOREIGN KEY (`id_nastaveni`) REFERENCES `systemove_nastaveni` (`id_nastaveni`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_systemove_nastaveni_log_to_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE SET NULL ON UPDATE CASCADE;

--
-- Omezení pro tabulku `ubytovani`
--
ALTER TABLE `ubytovani`
  ADD CONSTRAINT `FK_ubytovani_to_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `uzivatele_role`
--
ALTER TABLE `uzivatele_role`
  ADD CONSTRAINT `FK_uzivatele_role_role_seznam` FOREIGN KEY (`id_role`) REFERENCES `role_seznam` (`id_role`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `FK_uzivatele_role_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `uzivatele_role_log`
--
ALTER TABLE `uzivatele_role_log`
  ADD CONSTRAINT `FK_uzivatele_role_log_to_role_seznam` FOREIGN KEY (`id_role`) REFERENCES `role_seznam` (`id_role`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Omezení pro tabulku `uzivatele_url`
--
ALTER TABLE `uzivatele_url`
  ADD CONSTRAINT `FK_uzivatele_url_to_uzivatele_hodnoty` FOREIGN KEY (`id_uzivatele`) REFERENCES `uzivatele_hodnoty` (`id_uzivatele`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
